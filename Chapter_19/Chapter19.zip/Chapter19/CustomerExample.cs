﻿using System;

namespace Chapter19
{
  struct Customer
  {
    public int accountNo;
    public int age;
    public String name;
    public String address;
    public int loyaltyYears;
  } // End of Customer struct

  internal class CustomerExample
  {
    static void Main(string[] args)
    {
      // Create an object, myCustomer, of type struct Customer 
      Customer myCustomer;

      // Assign values to the myCustomer properties 
      myCustomer.accountNo = 123456;
      myCustomer.age = 30;
      myCustomer.name = "Gerry Byrne";
      myCustomer.address = "1 Any Street";
      myCustomer.loyaltyYears = 10;

      // Display the myCustomer struct details
      Console.WriteLine($"{"Customer account number is",-30} " +
        $"{ myCustomer.accountNo,15}");
      Console.WriteLine($"{"Customer age is",-30} " +
        $"{myCustomer.age,15}");
      Console.WriteLine($"{"Customer name is",-30} " +
        $"{myCustomer.name,15}");
      Console.WriteLine($"{"Customer address is",-30} " +
        $"{myCustomer.address,15}");
      Console.WriteLine($"{"Customer loyalty years",-30} " +
        $"{myCustomer.loyaltyYears,9} years");

    } // End of Main() method

  } // End of CustomerExample class

} // End of Chapter19 namespace
