﻿using System;

namespace Chapter19
{
  struct PolicyReadOnlyMembers
  {
    readonly private int policy_number;
    private String? policyType;
    private double monthlyPremium;
    readonly private String policyEndDate;

    public PolicyReadOnlyMembers(int policy_number,
    string policyType, double monthlyPremium,
           string policyEndDate)
    {
      this.policy_number = policy_number;
      //this.policyType = policyType;
      this.policyType = null;
      this.monthlyPremium = monthlyPremium;
      this.policyEndDate = policyEndDate;
    } // End of user constructor

    // Properties used to get and set the members
    public int Policy_number
    {
      get => policy_number;
    } // End of Policy_number property

    public string PolicyType
    {
      get => policyType;
      set => policyType = value;
    } // End of PolicyType property

    public double MonthlyPremium
    {
      get => monthlyPremium;
      set => monthlyPremium = value;
    } // End of MonthlyPremium property

    public string PolicyEndDate
    {
      get => policyEndDate;
    } // End of PolicyEndDate property
  } // End of PolicyReadOnlyMembers struct

  internal class PolicyExampleReadOnlyMember
  {
    static void Main(string[] args)
    {
      PolicyReadOnlyMembers PolicyReadOnlyMember =
        new PolicyReadOnlyMembers(123456, "Computer Hardware",
                                  9.99, "31/12/2022");

      Console.WriteLine(PolicyReadOnlyMember.Policy_number);
      Console.WriteLine(PolicyReadOnlyMember.PolicyType);
      Console.WriteLine(PolicyReadOnlyMember.MonthlyPremium);
      Console.WriteLine(PolicyReadOnlyMember.PolicyEndDate);

     // PolicyReadOnlyMember.Policy_number = 567890;
     // PolicyReadOnlyMember.PolicyEndDate = "01/01/2099";
    } // End of Main() method


  } // End of PolicyExampleReadOnlyMember class

} // End of Chapter19 namespace