﻿using System;

namespace Chapter19
{
  readonly struct Policy
  {
    readonly int policy_number;
    readonly String policyType;
    readonly double monthlyPremium;
    readonly String policyEndDate;

    public Policy(int policy_number, string policyType,
     double monthlyPremium, string policyEndDate)
    {
      this.policy_number = policy_number;
      this.policyType = policyType;
      this.monthlyPremium = monthlyPremium;
      this.policyEndDate = policyEndDate;
    } // End of user constructor

    public int Policy_number 
    { 
      get => policy_number; 
      //set => policy_number = value; 
    }
    public string PolicyType 
    { 
      get => policyType; 
      //set => policyType = value; 
    }
    public double MonthlyPremium 
    {
      get => monthlyPremium; 
      //set => monthlyPremium = value; 
    }
    public string PolicyEndDate 
    { 
      get => policyEndDate; 
      //set => policyEndDate = value; 
    }
  }// End of Policy struct
  internal class PolicyExample
  {
    static void Main(string[] args)
    {
      /*
      Using an instance without the new keyword
      •if the struct is used without the new keyword the members 
        of the  struct will remain unassigned, no values, and 
        we cannot use the struct object until we have 
        initialised all the members
        Using the code below we will see that
          - myPolicy is an instance of Policy
          - myPolicy.policy_number is unassigned but
          - doing myPolicy.policy_number = 123456 means it exists
          - same applies for all members
      */
      Policy myPolicy =
 new Policy(123456, "Computer Hardware", 9.99, "31/12/2022");

      Console.WriteLine(myPolicy.Policy_number);
      Console.WriteLine(myPolicy.PolicyType);
      Console.WriteLine(myPolicy.MonthlyPremium);
      Console.WriteLine(myPolicy.PolicyEndDate);

    } // End of Main() method

  } // End of PolicyExample class

} // End of Chapter19 namespace