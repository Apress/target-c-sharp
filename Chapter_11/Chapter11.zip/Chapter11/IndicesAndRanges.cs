﻿using System;

namespace Chapter11
{
  internal class IndicesAndRanges
  {
    static void Main(string[] args)
    {
      Console.WriteLine("**** C# 8 Indices and Ranges ****");
      Console.WriteLine("Ranges and indices provide a succinct ");
      Console.WriteLine("syntax for accessing single elements ");
      Console.WriteLine("or ranges in a sequence ");
      Console.WriteLine("*******************");

      /* 
      Declare and initialise the array of employees 
      and their salary
      */
      String[] employeeAndSalary = { "Gerry Byrne", "20000.55",
 "Peter Johnston", "30000.00", "Ryan Jones", "50000.00" };

      /* 
      Using the index from end operator ^ indicates we wish 
      to start at the end of the sequence
      Counting from the beginning means we start at 0
      Counting from the end means we start at 1
      */
      for (int counter = 0; counter < employeeAndSalary.Length;
       counter++)
      {
        Console.WriteLine($"The element positioned at " +
        $"{counter} is {^(employeeAndSalary.Length - (counter))}" +
         $" from the end of the array");
      }

      Console.WriteLine();
      Console.WriteLine("* ^ index from the end operator *");
      /* 
      Using the index feature. 
      ^ indicates we wish to start at the end 
      In the first example we use the traditional position index
      In the second example we use the index from 
      */
      Console.WriteLine($"Element index 2 is " +
        $"{employeeAndSalary[2]} and the second item from" +
        $" the end is {employeeAndSalary[4]}");

      Console.WriteLine($"Element index 2 is " +
        $"{employeeAndSalary[^4]} and the second item from" +
        $" the end is {employeeAndSalary[^2]}");
      Console.WriteLine();

      Console.WriteLine("Length and ^ index from end operator");
      /* 
      Using the index feature. ^ indicates we wish to start 
      at the end. In the first example we use the length to
      help find the last item. In the second example we use the
      indices to find the last item
      */
      Console.WriteLine($"The last item of the array is" +
        $" {employeeAndSalary[employeeAndSalary.Length - 1]}");

      Console.WriteLine($"The last item of the array " +
        $"is {employeeAndSalary[^1]}");
      Console.WriteLine();


      /* 
      Using the range feature. Range represents a sub range of 
      a sequence. A range specifies the start and end of a range.
      Ranges are exclusive, meaning the end isn't included in 
      the range. The range [0..^0] represents the entire range.
      Equally [0..sequence.Length] represents the entire range.
      In the first example we use the traditional method to find
      the length. In the second example we use the indices to 
      find the last item
      */

      Console.WriteLine("***** GetRange and ToList  ***** ");
      Console.WriteLine("Range represents a sub range " +
                                            "of a sequence");

      var employees = employeeAndSalary.ToList().GetRange(2, 4);

      foreach (var item in employees)
      {
        Console.WriteLine($"After using GetRange() " +
                                $"the array item is {item}");
      }

      Console.WriteLine();

      Console.WriteLine("********** Skip and Take  ********** ");
      /* 
      Using the skip and take features. 
      In the first example we use the traditional method to 
      find the length. In the second example we use the indices 
      to find the last item
      */

      var someemployees = employeeAndSalary.Skip(2).Take(4);

      foreach (var item in someemployees)
      {
        Console.WriteLine($"After using Skip() and " +
          $"Take() the array item is {item}");
      }
      Console.WriteLine();

      Console.WriteLine("******* Range operator .. ******* ");
      /* 
      Using the range operator .., specifies the start and end 
      of a range as its operands. A range specifies the start 
      and end of a range. Ranges are exclusive, meaning the 
      end isn't included in the range. 
      The range [0..^0] represents the entire range.
      In this example we use start at index 1 and
      stop at the element 2 from the end 
      */

      var someemployeeswithindices = employeeAndSalary[2..^2];

      foreach (var item in someemployeeswithindices)
      {
        Console.WriteLine($"Starting at index 1 and stopping" +
          $" at the element before 2 from the end the " +
          $"array item is { item }");
      }

    } // End of Main() method

  } // End of IndicesAndRanges class
} // End of Chapter11 namespace
