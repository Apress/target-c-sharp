﻿using System;

namespace Chapter11
{
  internal class ArrayErrors
  {
    static void Main(string[] args)
    {
      /*
      We will setup our variables that will be used in the 
      application. The number of entries being made will 
      determine the size of the array
      */
      int numberOfEntriesBeingMade;

      int numberOfEntriesEntered = 0;
      int arrayPositionCounter = 0;
      int odometerReadingForVehicle;

      string vehiclePolicyNumber;

      /* 
      Read the user input for the number of entries being 
      made and convert the string value to an integer data type 
      */
      Console.WriteLine("How many entries are you wishing" +
        " to make?\n");
      numberOfEntriesBeingMade =
                  Convert.ToInt32(Console.ReadLine());

      /*
      The array is going to hold the data for a number of 
      vehicles and their corresponding odometer readings. 
      Each entry will be a vehicle policy number and the 
      number of kilometres shown on the odometer. This means 
      that the size of the array will be twice the number of 
      entries being made by the repair shop.
      */
      String[] odometerReadings = 
        new String[numberOfEntriesBeingMade * 2];

      /* 
      As we are using a variable in the loop our code is 
      flexible and can be used for any number of claims.
      An ideal situation and good code.
      */
      do
      {
        Console.WriteLine("The current value of the counter" +
          " is :" + numberOfEntriesEntered + "\n");

        /* 
        Read the user input for the vehicle policy number 
        and keep it as a string 
        */
        Console.WriteLine("What is the vehicle policy number?\n");
        vehiclePolicyNumber = Console.ReadLine();

        /* 
        Write this first input value to the array and then 
        increment the value of the arrayPositionCounter by 1 
        */
        odometerReadings[arrayPositionCounter] = vehiclePolicyNumber;
        arrayPositionCounter++;

        /* Read the user input for the odometer reading */
        Console.WriteLine("What is the odometer reading?\n");
        odometerReadingForVehicle =
                          Convert.ToInt32(Console.ReadLine());

        /* 
        Write the second input value to the array and then 
        increment the value of the arrayPositionCounter by 1 
        */
        odometerReadings[arrayPositionCounter] =
                          odometerReadingForVehicle.ToString();
        arrayPositionCounter++;

        /* Increment the loop counter by 1 */
        numberOfEntriesEntered++;
      } while (numberOfEntriesEntered < numberOfEntriesBeingMade);

      foreach (String itemInTheodometerReadingsArray in
                                            odometerReadings)
      {
        Console.WriteLine("The item in the array is:" +
          "\t" + itemInTheodometerReadingsArray + "\n");
      } // End of foreach construct


    } // End of Main() method

  } // End of ArrayErrors class
} // End of Chapter11 namespace  