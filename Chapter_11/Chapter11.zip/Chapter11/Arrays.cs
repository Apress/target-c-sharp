﻿using System;

namespace Chapter11
{
  internal class Arrays
  {
    static void Main(string[] args)
    {
      /* 
      The array is going to hold the data for 2 claims. 
      Each claim has four pieces of information. The number 
      of data items is therefore 2 multiplied by 4 = 8. 
      So, we will make the array for this example of size 8. 
      Not the best way to do things, but fine for now. 
      */
      string[] repairShopClaims = new String[8];

      /*
      We will setup our variables that will be used in the 
      quote application. The details will be: 
      •	the repair shop unique id (string)
      •	the vehicle insurance policy number (string)
      •	the claim amount (double)
      •	the date of the claim (date)  
      */
      string repairShopID;
      string vehiclePolicyNumber;
      double claimAmount;
      DateTime claimDate;
      int numberOfClaimsBeingMade;
      int numberOfClaimsEntered = 0;
      int arrayPositionCounter = 0;

      /* 
      Read the user input for the number of claims being made
      and convert the string value to an integer data type
      */
      Console.WriteLine("How many claims are being made?\n");
      numberOfClaimsBeingMade = Convert.ToInt32(Console.ReadLine());

      do
      {
        Console.WriteLine("The current value of the " +
          "counter is :" + numberOfClaimsEntered + "\n");

          /* 
          Read the user input for the repair shop id and keep 
          it as a string 
          */
          Console.WriteLine("What is your repair shop id?\n");
          repairShopID = Console.ReadLine();

          /* 
          Write the first input value to the array and then 
          increment the value of the arrayPositionCounter by 1. 
          */
          repairShopClaims[arrayPositionCounter] = repairShopID;
          arrayPositionCounter++;

          /* 
          Read the user input for the vehicle policy number 
          and keep it as a string 
          */
          Console.WriteLine("What is the vehicle policy number?\n");
          vehiclePolicyNumber = Console.ReadLine();

          /* 
          Write the second input value to the array and then 
          increment the value of the arrayPositionCounter by 1 
          */
          repairShopClaims[arrayPositionCounter] = vehiclePolicyNumber;
          arrayPositionCounter++;

          /* 
          Read the user input for the repair amount and convert 
          it to a double it to the variable claimAmount 
          */
          Console.WriteLine("What is the amount being claimed " +
            "for the repair?\n");
          claimAmount = Convert.ToDouble(Console.ReadLine());

          /* 
          Write the third input value to the array and then 
          increment the value of the arrayPositionCounter by 1 
          */
          repairShopClaims[arrayPositionCounter] =
                                    claimAmount.ToString();
          arrayPositionCounter++;

          /* 
          Read the user input for the repair date and convert 
          it to a Date 
          */
          Console.WriteLine("What was the date of the repair?\n");
          claimDate = Convert.ToDateTime(Console.ReadLine());

          /*
          Write the fourth input value to the array and then 
          increment the value of the arrayPositionCounter by 1
          */
          repairShopClaims[arrayPositionCounter] =
                                    claimDate.ToString();
          arrayPositionCounter++;

          /* Increment the loop counter by 1 */
          numberOfClaimsEntered++;

        } while (numberOfClaimsEntered < numberOfClaimsBeingMade);

      foreach (var itemInTheClaimsArray in repairShopClaims)
      {
        Console.WriteLine("The item in the array is:" +
          "\t" + itemInTheClaimsArray + "\n");
      }


    } // End of Main() method

  } // End of Arrays class
} // End of Chapter11 namespace  