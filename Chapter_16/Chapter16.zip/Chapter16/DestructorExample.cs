﻿using System;

namespace Chapter16
{
  internal class DestructorExample
  {
    static void Main(string[] args)
    {
      // Call a method that creates the Policy class instance
      CreateAPolicy();

      UseStreamWriterWrite();
      UseStreamWriterWriteWithoutBraces();

      // Force the garbage collection
      GC.Collect();

      // Pause the output so we can see the destructor 
      Console.ReadLine();
    } // End of Main() method
    /*
    Method to create two instances of the class each one 
    using a different constructor each time
    */
    public static void CreateAPolicy()
    {
      //Declare and create a new Policy using default constructor
      Policy myPolicy = new Policy();

      /* 
      Display the details of Policy instance we have created,
      the member values
      */
      Console.WriteLine(myPolicy.ToString());

      /*
      Declare and create a new Policy using the
      parameterised constructor
      */
      Policy myPolicyNew =
      new Policy(123456, "Computer Hardware", 9.99, "31/12/2022");

      /* 
      Display the details of Policy instance we have created,
      using the ToString() method 
      */
      Console.WriteLine(myPolicyNew.ToString());
    } // End of CreateAPolicy() method

    static string policyDetailsFile = "usingstatement.txt";

    // Pre C#7 format for the using statement 
    public static void UseStreamWriterWrite()
    {
      using (StreamWriter myStreamWriter =
                    new StreamWriter(policyDetailsFile, true))
      {
        myStreamWriter.WriteLine("Auto insurance");
        myStreamWriter.WriteLine("ID987654");
        myStreamWriter.WriteLine("299.99");
        Console.WriteLine("The data has been written to file");
      }
    }// End of UseStreamWriterWrite() method

    // C#8 and later alternative format for the using statement 
    public static void UseStreamWriterWriteWithoutBraces()
    {
      Console.WriteLine("C# 8 - omit the open and " +
                        "close curly braces {}");
      Console.WriteLine("The object is automatically " +
                        "destroyed at the method end");

      using StreamWriter myStreamWriter =
                       new StreamWriter(policyDetailsFile, true);
      myStreamWriter.WriteLine("Home insurance");
      myStreamWriter.WriteLine("ID111222");
      myStreamWriter.WriteLine("111.11");
      Console.WriteLine("New Format data has been written to file");
    }// End of UseStreamWriterWriteWithoutBraces() method

  } //End of DestructorExample class

  class Policy
  {
    // Create the fields
    private int policy_number;
    private String policyType;
    private double monthlyPremium;
    private String policyEndDate;

    //Create an empty constructor
    public Policy()
    {
    Console.WriteLine("Policy instance using empty constructor");
    } // End of parameterless Policy() constructor

    //Create parameterised constructor to initialise field values
    public Policy(int policy_number, string policyType,
                   double monthlyPremium, string policyEndDate)
    {
      Console.WriteLine("Policy instance using paremeterised constructor");
  

      this.policy_number = policy_number;
      this.policyType = policyType;
      this.monthlyPremium = monthlyPremium;
      this.policyEndDate = policyEndDate;
    } // End of parameterised Policy() constructor

    //Create the Destructor method to kill instances of this class
    ~Policy()
    {
     Console.WriteLine("The Policy instance has been destroyed");
    } // End of Policy destructor method

    //Overridden ToString() method displaying actual field values
    public override string ToString()
    {
      return ($"The policy has been created with the details " +
        $"{this.policy_number} – { this.policyType} " +
        $"- { this.monthlyPremium} - { this.policyEndDate}\n");
    } // End of ToString() method

  } //End of Policy class

} // End of Chapter16 namespace