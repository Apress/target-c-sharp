﻿using System;
using System.IO;

namespace Chapter16
{
  internal class FileHandling
  {
    /*
    Create a variable to hold the file name. Here the file is 
    in the current directory, which in this case means it will 
    be in the Chapter 16 folder and then inside the bin folder 
    of either the Debug or Release folder depending on how we
    have run the application, Start without debugging or Start
    with debugging which means it goes into the debug folder,
    build application means it will go into the Release folder
    */
    static string policyDetailsFile = "policydetails.txt";

    static void Main(string[] args)
    {
      CheckIfTheFileExists();
      CreateTheFile();
      WriteAllTextToAFile();
      WriteAllLinesToAFile();
      WriteAllBytesToAFile();
      ReadAllTextFromAFile();
      ReadAllTextLinesFromAFile();
      ReadAllBytesFromAFile();
      CopyAFile();
      DeleteAFile();
      UseStreamWriterRead();
      UseStreamWriterWriteInUsingBlock();
      WriteCharactersAsynchronously();
      ReadAsynchronously();
      PeekWriteAndReadLineAsync();
      FileStreamSeekReadAndWrite();
    } // End of Main() method

    public static void CheckIfTheFileExists()
    {
      // Check if the file exists and display a message
      if (File.Exists(policyDetailsFile))
      {
        Console.WriteLine("Policy details file exists.");
      }
      else
      {
        Console.WriteLine("Policy details file does not exist.");
      }
    }// End of CheckIfTheFileExists() method

    public static void CreateTheFile()
    {
      // Create a file called policydetails.txt
      File.Create(policyDetailsFile).Close();
    }// End of CreateTheFile() method

    public static void WriteAllTextToAFile()
    {
      string policyDetailsMessage = "This file will hold " +
                "details of the customer policies ";
      File.WriteAllText(policyDetailsFile, policyDetailsMessage);
    }// End of WriteAllTextToAFile() method

    public static void WriteAllLinesToAFile()
    {
      string[] policyDetailsArray =
      {
        "Home insurance", "ID123456", "199.99"
      };
      File.WriteAllLines(policyDetailsFile, policyDetailsArray);
    }// End of WriteAllLinesToAFile() method

    public static void WriteAllBytesToAFile()
    {
      string policyMessage = "All policies";
      byte[] policyMessageAsData =
               System.Text.Encoding.ASCII.GetBytes(policyMessage);

      File.WriteAllBytes(policyDetailsFile, policyMessageAsData);

      Console.WriteLine("The bytes written to the file are");
      foreach (byte letterCode in policyMessageAsData)
      {
        Console.WriteLine("The byte written is – " + letterCode);
      }
    }// End of WriteAllBytesToAFile() method

    public static void ReadAllTextFromAFile()
    {
      // Open the file to be read from
      string textReadFromFile =
                        File.ReadAllText("policydetailsnew.txt");
      Console.WriteLine("The data read is \n" + textReadFromFile);
    }// End of ReadAllTextFromAFile() method

    public static void ReadAllTextLinesFromAFile()
    {
      // Open the file to be read from
      string[] textLinesReadFromFile =
                       File.ReadAllLines("policydetailsnew.txt");
      int lineCounter = 0;
      foreach (string lineReadFromFile in textLinesReadFromFile)
      {
        if(lineCounter > 0)
        {
          string policyNumber = lineReadFromFile.Substring(7);
          Console.WriteLine("The policy number is " + policyNumber);
        }
        else
        {
          Console.WriteLine(lineReadFromFile);
        }
        lineCounter++;
      }// End of foreach
    }// End of ReadAllTextLinesFromAFile() method

    public static void ReadAllBytesFromAFile()
    {
      /* 
      Open the file to read from and read all the bytes placing
      them in a byte string
      */
      byte[] bytesReadFromTheFile =
                      File.ReadAllBytes("policydetailsnew.txt");
      foreach (byte byteReadFromFile in bytesReadFromTheFile)
      {
        Console.WriteLine("The byte is " + byteReadFromFile);
      }
    }// End of ReadAllBytesFromAFile() method

    public static void CopyAFile()
    {
      // Use a try catch construct to catch any exceptions
      try
      {
        /* 
        Copy the contents of the source file policydetailsnew.txt
        to the destination file policydetailscopy.txt 
        */

        File.Copy("policydetailsnew.txt", "policydetailscopy.txt");
        Console.WriteLine("The copying process was successful.");
      } // End of try block
      catch (IOException exceptionFound)
      {
        Console.WriteLine("Copying failed with exception:");
        Console.WriteLine(exceptionFound.Message);
      } // End of catch block
    }// End of CopyAFile() method

    public static void DeleteAFile()
    {
      // Use a try catch construct to catch any exceptions
      try
      {
        // Delete the file policydetailscopy.txt 
        File.Delete("policydetailscopy.txt");
        Console.WriteLine("The file deletion was successful.");
      } // End of try block
      catch (IOException exceptionFound)
      {
        Console.WriteLine("File deletion failed with exception:");
        Console.WriteLine(exceptionFound.Message);
      } // End of catch block
    }// End of DeleteAFile() method

    public static void UseStreamWriterRead()
    {
      try
      {
        if (File.Exists(policyDetailsFile))
        {
          // Create an instance of the StreamReader class
          StreamReader myStreamReader =
                          new StreamReader(policyDetailsFile);

          /* 
          Iterate the instance of the StreamReader while there 
          is data, which means the Peek() method returns an 
          integer greater than 0
          */
          while (myStreamReader.Peek() > 0)
          {
            Console.Write(myStreamReader.Read() + "\t");
          }
          myStreamReader.Close();
        }
        else
        {
        }
      }
      catch (Exception exceptionFound)
      {
        Console.WriteLine("Process failed with the exception:");
        Console.WriteLine(exceptionFound.Message);
      }
      Console.WriteLine();
      Console.WriteLine();
      Console.WriteLine();
      Console.WriteLine();

    }// End of UseStreamWriterRead() method

    public static void UseStreamWriterWriteInUsingBlock()
    {

      using (StreamWriter myStreamWriter =
                   new StreamWriter(policyDetailsFile, true))
      {
        myStreamWriter.WriteLine("");
        myStreamWriter.WriteLine("Auto insurance");
        myStreamWriter.WriteLine("ID987654");
        myStreamWriter.WriteLine("299.99");
        Console.WriteLine("The data has been written to file");
      } // End of using block
    }// End of UseStreamWriterWriteInUsingBlock() method

    public static async void WriteCharactersAsynchronously()
    {
      using (StreamWriter myStreamWriter =
                        File.CreateText("asynctextfile.txt"))
      {
        await myStreamWriter.WriteLineAsync("Life insurance");
        await myStreamWriter.WriteLineAsync("LF123456");
        await myStreamWriter.WriteLineAsync("99.99");
      }
    }// End of WriteCharactersAsynchronously() method

    public static async void ReadAsynchronously()
    {
      string stringToRead = "LF12345699.99";

      char[] charsReadFromTheString = new char[stringToRead.Length];

      using (StringReader reader = new StringReader(stringToRead))
      {
        await reader.ReadAsync(charsReadFromTheString, 0, 8);
        Console.WriteLine(charsReadFromTheString);
      }
    }// End of ReadAsynchronously() method

    public static async void PeekWriteAndReadLineAsync()
    {
      using (StreamWriter writer =
                         new StreamWriter("asynctextfile.txt"))
      {
        await writer.WriteLineAsync("Boat insurance");
        await writer.WriteLineAsync("BO123456");
        await writer.WriteLineAsync("199.99");
      }

      using (StreamReader reader =
                         new StreamReader("asynctextfile.txt"))
      {
        while (reader.Peek() > -1)
        {
          Console.WriteLine($"Peek returned {reader.Peek()}");
          Console.WriteLine(await reader.ReadLineAsync());
        }
      }
    } // End of PeekWriteAndReadLineAsync() method

    public static void FileStreamSeekReadAndWrite()
    {
      const string claimsFileName = "claims.dat";
      int startPosition = 6;

      // Create a string and then convert it to a byte array 
      string claimantsName = "Gerry Byrne";

      byte[] claimantsByteArray =
       System.Text.Encoding.ASCII.GetBytes(claimantsName);

      Console.WriteLine("The bytes written to the file are");

      // Iterate the byte array and display each byte
      foreach (byte byteInTheArray in claimantsByteArray)
      {
        Console.WriteLine(byteInTheArray);
      } // End of foreach block

      Console.WriteLine("The bytes read from the file are");
      using (FileStream fileStream =
                new FileStream(claimsFileName, FileMode.Create))
      {
        for (int counter = 0; counter
                      < claimantsByteArray.Length; counter++)
        {
          fileStream.WriteByte(claimantsByteArray[counter]);
        } // End of for block

        // Move to new position in the file stream
        fileStream.Seek(startPosition, SeekOrigin.Begin);

        for (int counter = 0; counter
                < fileStream.Length - startPosition; counter++)
        {
          Console.WriteLine(fileStream.ReadByte());
        } // End of for block
      } // End of using block
    } // End of FileStreamSeekReadAndWrite() method

  } // End of FileHandling class
} // End of Chapter16 namespace