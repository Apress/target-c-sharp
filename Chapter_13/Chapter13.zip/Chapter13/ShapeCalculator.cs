﻿using System;

namespace Chapter13
{
  internal class ShapeCalculator
  {
    static void Main(string[] args)
    {
    // Instantiate the CircleFormulae class
    CircleFormulae myCircleFormulae = new CircleFormulae();

      myCircleFormulae.AreaOfCircle();

      RectangleFormulae myRectangleFormulae
                = new RectangleFormulae();

      myRectangleFormulae.AreaOfRectangle();
    } // End of Main() method

  } // End of ShapeCalculator class
} // End of Chapter13 namespace