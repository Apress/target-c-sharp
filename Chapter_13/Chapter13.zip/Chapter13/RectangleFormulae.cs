﻿using System;

namespace Chapter13
{
  internal class RectangleFormulae
  {
    /*
    This is a method that will ask the user to input the 
    length of the rectangle, then ask them for the breadth of 
    the rectangle, calculate the area of the rectangle and 
    display the area of the rectangle in the console window
    */
    public void AreaOfRectangle()
    {
      /*
      Create three variables of data type double to hold the 
      value of the length and breadth as input by the user and 
      the calculated area of the rectangle.
      Initialise the three variables to zero.
      */
      double lengthOfRectangle = 0;
      double breadthOfRectangle = 0;
      double areaOfRectangle = 0;

      Console.WriteLine("\nWhat is the rectangle length?\n");
      lengthOfRectangle = Convert.ToDouble(Console.ReadLine());

      Console.WriteLine("\nWhat is the rectangle breadth?\n");
      breadthOfRectangle = Convert.ToDouble(Console.ReadLine());

      // Calculate the area of the rectangle with the formula 
      areaOfRectangle = lengthOfRectangle * breadthOfRectangle;

      // Display the rectangle details
      Console.WriteLine(String.Format("\nA rectangle with " +
        "length of {0:0.#} and breadth of {1:0.#} has an area " +
        "of  {2:0.#}", lengthOfRectangle, breadthOfRectangle,
        areaOfRectangle));

      /*
      Now call the method which calculates the perimeter of the
      rectangle using the length and breadth the user has input.
      We call the method and pass the radius as a parameter
      */
      PerimeterOfRectangle(lengthOfRectangle, breadthOfRectangle);

    } // End of AreaOfRectangle method

    /*
    This is a method that will accept the values of the length 
    and breadth passed to it. Both values have been obtained in 
    the areaOfRectangle method and then the areaOfRectangle() 
    method will call this new perimeterOfRectangle() method 
    passing it the values of the length and breadth. 
    This method will then calculate the perimeter and display 
    the value in the console window
    */
    public void PerimeterOfRectangle(double lengthPassedIn,
                               double breadthPassedIn)
    {
      /* 
      Create a variable of data type double to hold the value 
      calculated for the perimeter of the rectangle. Initialise
      the variable to zero. We have the length and breadth as 
      they are passed into this method 
      */
      double perimeterOfRectangle = 0;

      //Calculate the perimeter of the rectangle with the formula
      perimeterOfRectangle = 2 * (lengthPassedIn + breadthPassedIn);

      Console.WriteLine(String.Format("\nA rectangle with " +
  "length of {0:0.##} and breadth of {1:0.##} has a" +
  " perimeter of  {2:0.##}", lengthPassedIn,
  breadthPassedIn, perimeterOfRectangle));

    } // End of PerimeterOfRectangle method


  } // End of RectangleFormulae class
} // End of Chapter13 namespace