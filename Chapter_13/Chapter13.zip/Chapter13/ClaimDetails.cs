﻿using System;

namespace Chapter13
{
  internal class ClaimDetails
  {
    int numberOfClaimsBeingMade;

    String repairShopID;
    String vehiclePolicyNumber;
    double claimAmount;
    DateTime claimDate;
    public String message = "";

    /*
    The array is going to hold the data for 2 claims. 
    Each claim has four pieces of information. 
    The number of data items is therefore
                    2 multiplied by 4 = 8
    So, we will make the array for this example of size 8.
    Not the best way to do things but fine for now. 
    */
    public String[] repairShopClaims = new String[8];
    double totalofallclaims;
    double vatamount;
    int numberOfClaimsEntered = 0;
    int arrayPositionCounter = 0;


    /*
    This is a constructor that accepts one String argument
    The value that is passed to the constructor is used to 
    set the value of the field called claimDate. 
    The constructor has the same name as the class, it has an 
    access modifier of public, it takes an argument of data 
    type String as this is the same data type as the field, 
    claimDate, that is being initialised, and it does not 
    return a value so there is no return type
    */
    public ClaimDetails(String claimDate)
    {
      this.claimDate = Convert.ToDateTime(claimDate);
    } // End of constructor that takes in a date

    /*
    This is a second constructor that accepts two String 
    arguments and the values that are passed to the constructor 
    are used to set the value of the field called claimDate 
    and the field called message. The constructor has the same 
    name as the class, it has an access modifier of public, it 
    takes two arguments of data type String as these are the 
    same data types as the fields, claimDate and message, that 
    are being initialised, and it does not return a value so 
    there is no return type. 
    As the constructor has two arguments it is different 
    from the first constructor
    */
    public ClaimDetails(String claimDate, String message)
    {
      this.claimDate = Convert.ToDateTime(claimDate);
      this.message = message;
    } // End of constructor that takes in a date and a message

    public double Totalofallclaims 
    { 
      get => totalofallclaims; 
      set => totalofallclaims = value; 
    }


    /******************* METHOD ONE ******************/
    public int HowManyClaimsAreBeingMade()
    {
      /* 
      Read the user input for the number of claims being made 
      and convert the string value to an integer data type
      */
      Console.WriteLine("How many claims are being made?\n");

      return Convert.ToInt32(Console.ReadLine());
    } // End of HowManyClaimsAreBeingMade() method

    /******************* METHOD TWO ******************/
    public void CurrentValueOfCounter()
    {
      Console.WriteLine("The current value of the counter " +
        "is :" + numberOfClaimsEntered + "\n");
    } // End of CurrentValueOfCounter() method

    /******************* METHOD THREE ******************/
    public string ReadTheRepairShopId()
    {
      Console.WriteLine("What is your repair shop id?\n");
      return Console.ReadLine();
    }// End of ReadTheRepairShopId() method

    /******************* METHOD FOUR ******************/
    public void WriteRepairShopIdToTheArray()
    {
      repairShopClaims[arrayPositionCounter] = repairShopID;
      arrayPositionCounter++;
    } // End of WriteRepairShopIdToTheArray() method

    /******************* METHOD FIVE ******************/
    public string ReadTheVehiclePolicyNumber()
    {
      Console.WriteLine("What is the vehicle policy number?\n");
      return Console.ReadLine();
    } // End of ReadTheVehiclePolicyNumber() method

    /******************* METHOD SIX ******************/
    public void WriteVehiclePolicyNumberToTheArray()
    {
      repairShopClaims[arrayPositionCounter] = vehiclePolicyNumber;
      arrayPositionCounter++;
    } // End of WriteVehiclePolicyNumberToTheArray() method

    /******************* METHOD SEVEN ******************/
    public double ReadTheAmountBeingClaimed()
    {
      Console.WriteLine("What is the amount being " +
        "claimed for the repair?\n");
      double claimAmountFromUser
                      = Convert.ToDouble(Console.ReadLine());
      AccumulateClaimAmount(claimAmountFromUser);

      return claimAmountFromUser;
    } // End of ReadTheAmountBeingClaimed() method

    /******************* METHOD EIGHT ******************/
    public void WriteClaimAmountToTheArray()
    {
      repairShopClaims[arrayPositionCounter]
                  = claimAmount.ToString();
      arrayPositionCounter++;
    }// End of WriteClaimAmountToTheArray() method

    /******************* METHOD NINE ******************/
    public DateTime ReadTheRepairDate()
    {
      Console.WriteLine("What was the date of the repair?\n");
      return Convert.ToDateTime(Console.ReadLine());
    }// End of method ReadTheRepairDate() method

    /******************* METHOD TEN ******************/
    public void WriteRepairDateToTheArray()
    {
      repairShopClaims[arrayPositionCounter]
                  = claimDate.ToString();
      arrayPositionCounter++;
    }// End of method WriteRepairDateToTheArray() method

    /******************* METHOD ELEVEN ******************/
    public void DisplayAllItemsInTheArray()
    {
      foreach (var itemInTheClaimsArray in repairShopClaims)
      {
        Console.WriteLine("The item in the array " +
          "is:\t" + itemInTheClaimsArray + "\n");
      }
    } // End of method DisplayAllItemsInTheArray() method

    /******************* METHOD TWELVE ******************/
    public double AccumulateClaimAmount(double
    claimamountpassedin)
    {
      totalofallclaims = totalofallclaims + claimamountpassedin;
      return totalofallclaims;
    }// End of method AccumulateClaimAmount()

    /******************* METHOD THIRTEEN ******************/
    public double CalculateVATAmount(double
                                 totalvalueofclaimspassedin)
    {
      vatamount = totalvalueofclaimspassedin -
        (totalvalueofclaimspassedin / 1.20);
      return vatamount;
    } // End of method CalculateVATAmount()

    /******************* METHOD FOURTEEN ******************/
    public void DisplayInvoiceReceipt(double
           totalvalueofclaimspassedin, double vatPassedIn)
    {
      Console.WriteLine("\nInvoice for vehicle repairs\n");
      Console.WriteLine("Nett claim\t" +
        (totalofallclaims - vatamount) + "\n");
      Console.WriteLine("VAT amount\t" + vatamount + "\n");
      Console.WriteLine("Total amount\t" +
        totalofallclaims + "\n");
      Console.WriteLine(message);
    } // End of method DisplayInvoiceReceipt()

    /******************* METHOD FIFTEEN ******************/
    //public void DisplayInvoiceReceipt(double
    //totalvalueofclaimspassedin, double vatPassedIn, String
    //messagePassedIn)
    //{

    //  Console.WriteLine("********************************");
    //  Console.WriteLine("\nInvoice for vehicle repairs\n");
    //  Console.WriteLine("Nett claim\t" + (totalofallclaims - vatamount) + "\n");
    //  Console.WriteLine("VAT amount\t" + vatamount + "\n");
    //  Console.WriteLine("Total amount\t" + totalofallclaims + "\n");
    //  Console.WriteLine(messagePassedIn);

    //  Console.WriteLine("********************************");
    //} // End of method DisplayInvoiceReceipt


  }  // End of ClaimDetails class 
}  // End of Chapter13 namespace