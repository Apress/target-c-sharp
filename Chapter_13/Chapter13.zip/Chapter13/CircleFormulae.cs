﻿using System;

namespace Chapter13
{
  internal class CircleFormulae
  {
    /* 
    This is a method that will ask the user to input the length
    of the radius of the circle, calculate the area of the circle 
    and display the area of the circle in the console window
    */
    public void AreaOfCircle()
    {
      /*
      Create two variables of data type double to hold the 
      value of the radius input by the user and the calculated 
      area of the circle, initialise the two variables to zero
      */
      double radiusLength = 0;

      double areaOfCircle = 0;

      // Read the user input for the size of the radius
      Console.WriteLine("What size is the radius?\n");

      radiusLength = Convert.ToDouble(Console.ReadLine());

      // Calculate the area of the circle with the formula
      areaOfCircle = Math.PI * radiusLength * radiusLength;

      Console.WriteLine(String.Format("\nA circle with " +
        "radius {0:0.#} has an area of  {1:0.##}",
        radiusLength, areaOfCircle));

      /*
      Now call the method which calculates the circumference 
      of the circle using the radius the user has input.
      We call the method and pass the radius as a parameter.
      */
      CircumferenceOfCircle(radiusLength);
    } //End of AreaOfCircle method

    /*
    This is a method that will accept the value of the radius 
    passed to it. The radius has been obtained in the 
    areaOfCircle method and then the areaOfCircle() method 
    will call this new circumferenceOfCircle() method passing 
    it the value of the radius. This method will then calculate 
    the circumference and display the value in the console window
    */
    public void CircumferenceOfCircle(double radiusPassedIn)
    {
      /*
      Create a variable of data type double to hold the value 
      calculated for the circumference of the circle. 
      Initialise the variable to zero.
      We have the radius as it is passed into this method.
      */
      double circumferenceOfCircle = 0;

      //Calculate the circumference with the formula
      circumferenceOfCircle = 2 * Math.PI * radiusPassedIn;

      Console.WriteLine(String.Format("\nA circle with " +
        "radius {0:0.#} has a circumference of {1:0.##}",
        radiusPassedIn, circumferenceOfCircle));

    } // End of CircumferenceOfCircle method

  } // End of CircleFormulae class
} // End of Chapter13 namespace