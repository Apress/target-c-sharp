﻿using System;

namespace Chapter13
{
  internal class ClaimApplication
  {
    static void Main(string[] args)
    {
      int numberOfClaimsEntered = 0;
      double vatamount;

      // Read the date from the computer clock
      DateTime localDate = DateTime.Now;
      String myDateString = localDate.ToString();

     ClaimDetails myClaimDetailsInstance
        = new ClaimDetails(myDateString, "\tThank you for" +
        " your claims \n\tthey will be processed today");

     //ClaimDetails myClaimDetailsInstance = new
      //                  ClaimDetails(myDateString);

      int numberOfClaimsBeingMade
        = myClaimDetailsInstance.HowManyClaimsAreBeingMade();

      /*
      As we are using a variable in the loop our code is 
      flexible and can be used for any number of claims. 
      An ideal situation and good code.
      */
      do
      {
        // Call the methods as required
        myClaimDetailsInstance.ReadTheRepairShopId();
        myClaimDetailsInstance.WriteRepairShopIdToTheArray();

        myClaimDetailsInstance.ReadTheVehiclePolicyNumber();
        myClaimDetailsInstance.WriteVehiclePolicyNumberToTheArray();

        myClaimDetailsInstance.ReadTheAmountBeingClaimed();
        myClaimDetailsInstance.WriteClaimAmountToTheArray();

        // myClaimDetailsInstance.ReadTheRepairDate();
        myClaimDetailsInstance.WriteRepairDateToTheArray();

        /* Increment the loop counter by 1 */
        numberOfClaimsEntered++;

      } while (numberOfClaimsEntered < numberOfClaimsBeingMade);

      foreach (String item in myClaimDetailsInstance.repairShopClaims)
      {
        Console.WriteLine("Array item is: " + item);
      }

      vatamount = myClaimDetailsInstance.CalculateVATAmount(myClaimDetailsInstance.Totalofallclaims);

      // myClaimDetailsInstance.DisplayInvoiceReceipt(myClaimDetailsInstance.Totalofallclaims, vatamount, "\tThank you for your claims \n\tthey will be processed today");

      myClaimDetailsInstance.DisplayInvoiceReceipt(myClaimDetailsInstance.Totalofallclaims, vatamount);

    } // End of Main() method

  } // End of ClaimApplication class
} // End of Chapter13 namespace