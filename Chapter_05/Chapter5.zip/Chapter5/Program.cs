﻿// Program:	A simple C# program to output text and read input
// Author:	Gerry Byrne
// Date of creation:	01/10/2023

using System;

/*
C# programming namespaces are commonly used in two ways:

1. C#, or more precisely .NET,  uses namespaces to organise the 
many classes it contains (remember classes contain methods and 
variables)
2. C# allows us as developers to create our own namespaces. 
We can use the namespace keyword to declare a namespace 
e.g. namespace Chapter5
A namespace can have the same name as the project but it can 
also be any name we wish. The name is independent of the 
Project name
*/

namespace Chapter5
{
  // This is our only class and it will contain the Main method
  public class Program
  {
    /*
    We now have our main method which will contain all our code.
    As we become a better developer, we will not have all our 
    code contained within the main method. 
    This would be seen as poor code and not fitting in with the 
    design principle of modular code.
    */

    public static void Main(string[] args)
    {
      Console.WriteLine();
      Console.WriteLine("------- Build your C# skills -------");
      Console.WriteLine("------- Learn To Code With C# -------");
      Console.WriteLine();
      Console.WriteLine("Press any keyboard letter to continue");
      Console.ReadLine();// This line waits for the user to input 
      Console.WriteLine("Goodbye");
      Console.ReadLine();
    } // End of Main() method

  } // End of Program class
} // End of Chapter5 namespace