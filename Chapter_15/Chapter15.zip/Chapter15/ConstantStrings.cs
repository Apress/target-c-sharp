﻿using System;

namespace Chapter15
{
  internal class ConstantStrings
  {
    static void Main(string[] args)
    {
      /* 
      Prior to C# 10 we could have const strings and we 
      had to concatenate them using the + 
      */
      const string thankYou = "Thank you for purchasing " +
                                      "insurance with us.\n";

      const string offerMessageHome = "As a thank you we are " +
        "offering you 10% of your next Home insurance \n";

      const string offerMessageBuilding = "As a thank you we " +
        "are offering you 5% of your next Building insurance \n";

      const string redeemMessage = "Simply call us and we " +
        "have this offer associated with your account\n ";

      // Concatenation using +
      const string homeMessage = thankYou + offerMessageHome
                    + redeemMessage;
      Console.WriteLine(homeMessage);

      const string buildingMessage = thankYou +
  offerMessageBuilding + redeemMessage;
      Console.WriteLine(buildingMessage);

      /* 
      From C# 10 we are allowed to concatenate const strings 
      with the string interpolation $
      */
      const string homeMessageConst =
               ($"{thankYou}{offerMessageHome}{redeemMessage}");

      Console.WriteLine(homeMessageConst);

      const string buildingMessageConst =
         $"{thankYou}{offerMessageBuilding}{redeemMessage}";

      Console.WriteLine(buildingMessageConst);

    } // End of Main() method

  } // End of ConstantStrings class

} // End of Chapter15 namespace