﻿using System;

namespace Chapter15
{
  internal class Strings
  {
    static void Main(string[] args)
    {
      String myVehicleRegistration = "ZER 7890";

      /* 
      Use the Substring() method to find the first string  
      characters of the myVehicleRegistration string, starting
      at position 4 and reading to the end of the string.
      */
      Console.WriteLine("The characters from position 4 are: "
        + myVehicleRegistration.Substring(4));

      /* 
      Use the Substring() method to find the first 3 characters 
      of the myVehicleRegistration string.
      Remember substring is inclusive of the char at the first 
      position but exclusive of the char at the end position we 
      say it is inclusive/exclusive
      */
      Console.WriteLine("The first 3 characters are: "
        + myVehicleRegistration.Substring(0, 3));

      /* 
      Use the Length property from the String class to find the
      number of characters in the myVehicleRegistration object.
      */
      Console.WriteLine("The number of characters is: "
        + myVehicleRegistration.Length);

      // Create an array of String objects
      String[] myVehicleRegistrations = new String[]
                   { "ZER 7890", "ZAC 7124", "ARC 3330" };

      foreach (String registration in myVehicleRegistrations)
      {
        if (registration.StartsWith("Z"))
        {
          Console.WriteLine(String.Format("\nThe registration" +
            " {0} starts with the letter Z", registration));
        } // End of if block
        else
        {
          Console.WriteLine(String.Format("\nThe registration " +
           "{0} does not start with the letter Z", registration));
        } // End of else block
      } // End of for each iteration

      // Iterate the array and split the items as they are read
      foreach (String registration in myVehicleRegistrations)
      {
        // Array to hold the 2 parts of the vehicle registration
        String[] splitRegistration = new String[2];

        // Split the array at the space
        splitRegistration = registration.Split(' ');

        Console.WriteLine(String.Format("\nPart 0 is {0}", splitRegistration[0]));
        Console.WriteLine(String.Format("\nPart 1 is {0}", splitRegistration[1]));
      } // End of iteration for splitting at the space character

      // Create a new array of String objects
      String[] myMixedVehicleRegistrations = new String[]
      { "ZER 7890", "ZAC_7124", "ARC,3330" };

      // Iterate the array and split the items as they are read     
      foreach (String mixedRegistrationPart in
                                       myMixedVehicleRegistrations)
      {
        // Array to hold the 2 parts of the vehicle registration
        String[] splitMixedRegistration = new String[2];

        // Split the array at the underscore, space or ,
        splitMixedRegistration
           = mixedRegistrationPart.Split(new char[] { ' ', ',', '_' });

        Console.WriteLine(String.Format("\nPart 0 is {0}" +
           " is ", splitMixedRegistration[0]));
        Console.WriteLine(String.Format("\nPart 1 is {0}" +
           " is ", splitMixedRegistration[1]));
      } // End of for each iteration

      // Create a new array of String objects
      String[] myDuplicateVehicleRegistrations = new String[]
      { "ZER 7890", "ZAC_7124", "ARC,3330", "ZER 7890",
        "ARC,3330", "zer 7890", " zac_7124" };

      // Iterate the array and split the items as they are read     
      for (int counter = 0; counter <
             myDuplicateVehicleRegistrations.Length; counter++)
      {
        for (int innercounter = counter + 1; innercounter <
           myDuplicateVehicleRegistrations.Length; innercounter++)
        {
          if (myDuplicateVehicleRegistrations[counter].CompareTo(myDuplicateVehicleRegistrations[innercounter]) == 0)
          {
            Console.WriteLine(String.Format("\n{0} at index" +
              " {1} is the same String as array index {2} {3}",
              myDuplicateVehicleRegistrations[counter],counter, 
              innercounter,myDuplicateVehicleRegistrations[innercounter]));
          } // End of the if selection block
        } // End of for inner loop iteration
      } // End of for each outer loop iteration

      // Iterate the array and split the items as they are read     
      for (int counter = 0; counter <
        myDuplicateVehicleRegistrations.Length; counter++)
      {
        for (int innercounter = counter + 1; innercounter <
                myDuplicateVehicleRegistrations.Length; innercounter++)
        {
          if (myDuplicateVehicleRegistrations[counter].
           CompareTo(myDuplicateVehicleRegistrations[innercounter]) == 1)
          {
            Console.WriteLine(String.Format("\nString {0} comes " +
              "after String {1} using unicode ",
            myDuplicateVehicleRegistrations[counter],
            myDuplicateVehicleRegistrations[innercounter]));
          } // End of if block
        } // End of for inner loop iteration
      } // End of for each outer loop iteration


    /* 
    Iterate the array and compare the items, changing to 
    upper case, as they are read
    */
      for (int counter = 0; counter <
              myDuplicateVehicleRegistrations.Length; counter++)
      {
        for (int innercounter = counter + 1; innercounter <
                myDuplicateVehicleRegistrations.Length; innercounter++)
        {
          if (myDuplicateVehicleRegistrations[counter].ToUpper().
      CompareTo(myDuplicateVehicleRegistrations[innercounter].ToUpper()) == 0)
          {
            Console.WriteLine("With upper case {0} at index {1} is " +
            "the \nsame String as {3} at index {2}\n",
            myDuplicateVehicleRegistrations[counter], counter,
            innercounter, myDuplicateVehicleRegistrations[innercounter]);
          }
        } // End of inner for iteration
      } // End of outer for each iteration

      String insuredPerson = " Gerry Byrne,";
      String welcome = "thank you for taking out insurance with us.";
      String insuranceType = "Home Insurance";
      String myOfferDetails = string.Concat(insuredPerson, " ",
             welcome, "\n", "You now have full ", insuranceType, ". ");

      Console.WriteLine(String.Format("{0}", myOfferDetails));

      String trimmedMyOfferDetails = myOfferDetails.Trim();
      Console.WriteLine(String.Format("\n{0}", trimmedMyOfferDetails));

      String name = "Gerry Byrne";
      String newName = name.Replace('e', 'E');
      Console.WriteLine(String.Format("\n{0}", newName));

      String newCapitalName = name.Replace("Gerry", "GERARD");
      Console.WriteLine(String.Format("\n{0}", newCapitalName));

      Console.WriteLine("What type of insurance do you require?\n");
      String clientInsuranceType = Console.ReadLine();

      if (clientInsuranceType.Contains("Home"))
      {
        Console.WriteLine("Home Insurance types are");
        Console.WriteLine("1. Building Only");
        Console.WriteLine("2. Content Only");
        Console.WriteLine("3. Building and Content Only");
      }
      else
      {
        Console.WriteLine("You have not chosen Home Insurance");
      }

      Console.WriteLine("Please enter your email address?\n");
      string emailAddress = Console.ReadLine();
      int intPosition = emailAddress.IndexOf("@");
      if (intPosition == -1)
      {
        Console.WriteLine("Not a valid email address - retype your email address");
      }
      else
      {
        Console.WriteLine("Valid email address with the @ at position "
          + intPosition);
      }

      Console.WriteLine("What is your account number?\n");
      string accountNumber = Console.ReadLine();

      int intPositionG = accountNumber.IndexOf("G");
      int intPositionB = accountNumber.IndexOf("B");

      if (intPositionG == 0 && intPositionB == 1)
      {
        Console.WriteLine("Valid account number\n" +
                "Character G was found at location " + intPositionG +
                "\nCharacter B was found at location " + intPositionB);
      } // End of if section
      else
      {
        Console.WriteLine("Not a valid account number");
        accountNumber = accountNumber.Insert(0, "GB");
        Console.WriteLine("The account number is " + accountNumber);
      } // End of else section

      // Format the number to 2 decimal places giving 99.97
      Console.WriteLine(String.Format("Decimal: {0:0.00}", 99.9687));

     // Format to scientific format 9.99E+002
     // (E+002 is 10 to the power of 2 or 100)
     Console.WriteLine(String.Format("Scientific: {0:E}", 999));

      // Format to local currency format e.g. 2 decimal places
      // and a £ symbol £99.97
      Console.WriteLine(String.Format("Currency:{0:C}", 99.9687654));

      // Format to percent 99 multiplied by 100 is 9900%.     
      Console.WriteLine(String.Format("Percent: {0:P}", 99));

      DateTime localDate = DateTime.Now;

      // Format the string as a short time 
      Console.WriteLine(String.Format("Short date:{0:t}", localDate));

      // Format the string as a long time 
      Console.WriteLine(String.Format("Long date: {0:F}", localDate));

      // Format  to 2 decimal places giving 99.97
      Console.WriteLine($"Decimal: {99.9687:0.00}");

      // Format to scientific format giving 9.99E+002
      // E+002 is 10 to the power of 2 or 100)
      Console.WriteLine($"Scientific: {999:E}");

      // Format to local currency format e.g. 2 decimal places
      // and a £ symbol £99.97
      Console.WriteLine($"Currency: {99.9687654:C}");

      // Format to percent 99 multiplied by 100 is 9900%
      Console.WriteLine($"Percent: {99:P}");

      DateTime localDate2 = DateTime.Now;

      // Format the string as a short time 
      Console.WriteLine($"Short date: {localDate2:t}");

      // Format the string as a long time 
      Console.WriteLine($"Long date: {localDate2:F}");

      Console.WriteLine($"Decimal: {99.9687654:0.00} " +
     $"Scientific: {999:E} Currency: {99.9687654:C}");

      Console.WriteLine($"The Short date is {localDate:t} " +
        $"while the long date is {localDate:F}");

      /*
      Spacing is achieved using - for left and + for right alignment
      In this example we have the first string right aligned in its
      20 spaces, the second string left aligned in its 25 spaces, 
      */
      Console.WriteLine($"The Short date is {localDate:t} " +
        $"while the long date is {localDate:F}");

      Console.WriteLine($"{"The Short date is",20} {localDate:t} " +
        $"{"while the long date is",-25}{ localDate: F}");


      /* 
      Escape sequences
      In this example we use the backslash in front of the \n which 
      is the escape sequence for a new line
      */
      Console.WriteLine("Two character pair for a new line is \\n");

      /* 
      Escape sequences
      In this example we use the backslash in front of the starting 
      double quote " to indicate that we wish the " to be displayed
      We then use the backslash in front of the \n which is the 
      escape sequence for a new line and we are saying we want this
      \n to be displayed and finally we use the backslash in front 
      of the ending double quote " to indicate that we wish 
      the " to be displayed
      */
      Console.WriteLine("Two character pair for new line is \"\\n\" ");

      /*
      @ Verbatim
      There is an alternative way to the \\ when we wish to display 
      or use a \
      The alternative is to use a verbatim string which means we use
      a regular string but we put a @ symbol before the opening 
      double quotes. The verbatim now treats all characters in a 
      literal way, just as they appear
      */
      Console.WriteLine(@"Two character pair for a new line is \n");

      /*
      There is an exception when using the verbatim and that is when
      we are wanting to display the double quote character ".
      As the " indicates the start and the end of the verbatim string
      how can we add them if we want to actually display them?
      We might think use the backslash \. But no, we use another 
      double quote in front of the double quote to be displayed as 
      shown in this example.
      */
      Console.WriteLine(@"Two character pair for a new line is ""\n""");



      Console.WriteLine($@"Two character pair for a new line is ""\n""");
      Console.WriteLine(@$"Two character pair for a new line is ""\n""");

    } // End of Main() method

  } // End of Strings class
} // End of Chapter15 namespace