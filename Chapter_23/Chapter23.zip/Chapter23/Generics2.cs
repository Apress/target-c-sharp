﻿using System;

namespace Chapter23
{
  class Generics2
  {
    static void Main(string[] args)
    {
      // Instantiate the PolicyMatcherGeneric class
      PolicyMatcherGeneric<int> myPolicyMatcher = new PolicyMatcherGeneric<int>();

      /* 
      Call the add method passing it the two policy values
      with the correct data type
      */
      Console.WriteLine(myPolicyMatcher.checkIfTheSame(10000, 20000));

      // Instantiate the PolicyMatcher class for strings
      PolicyMatcherGeneric<string> myPolicyMatcherString =
        new PolicyMatcherGeneric<string>();

      /*
      Call the add method passing it the two policy values 
      with the correct data type
      */
      Console.WriteLine(myPolicyMatcherString.checkIfTheSame("PL123456", "PL123456"));

      /* 
      Call the new method passing it the two policy values
      with the correct data type
      */
      Console.WriteLine(myPolicyMatcher.checkIfTheSame("PL123456", 123456, 9.99));

      // Instantiate the RenewalMatcher class
      RenewalMatcher myRenewalMatcher = new RenewalMatcher();

      // Call the checkIfRenewalDateOrPremiumIncrease three times
      Console.WriteLine(myRenewalMatcher.checkIfRenewalDateOrPremiumIncrease("01/05/2022", "Life Insurance"));
      Console.WriteLine(myRenewalMatcher.checkIfRenewalDateOrPremiumIncrease("01/06/2022", "Home Insurance"));
      Console.WriteLine(myRenewalMatcher.checkIfRenewalDateOrPremiumIncrease(9.99, 10));

    } // End of Main() method

  } // End of Generics2 class

  class PolicyMatcherGeneric<T>
  {
    /*
    A method which is not generic because it has specifies 
    the parameter data types. The method cannot be used 
    when passing floats etc. It is specific not generic.
    */
    public string checkIfTheSame(T itemOne, T itemTwo)
    {
      if (itemOne.Equals(itemTwo))
      {
        return ($"The {itemOne.GetType()} values {itemOne} " +
          $"and {itemTwo} are equal");
      }
      else
      {
        return ($"The {itemOne.GetType()} values {itemOne}" +
          $" and {itemTwo} are not equal");
      }
    }// End of checkIfTheSame() method

    /*
      A method which is generic because both parameters are 
      of type T specifies the parameter data types.
      The method can be used when passing floats, strings etc. 
      It is generic.
      */
    public string checkIfTheSame(string itemOne, T itemTwo,
                                 double premium)
    {
      if (itemOne.Contains(itemTwo.ToString()))
      {
        return ($"The policy value {itemOne} " +
          $"corresponds with the value {itemTwo} " +
          $"and the premium is { premium }");
      }
      else
      {
        return ($"The policy {itemOne} " +
          $"does not correspond with the value " +
          $"{itemTwo} and the premium is { premium }");

      }
    }// End of second checkIfTheSame() method

  } // End of PolicyMatcherGeneric class

  // Declare the class
  class RenewalMatcher
  {
    /*
    A method which is generic because of the <T>
    The method has parameters of type T.
    The method can be used when passing floats, strings etc. 
    It is generic.
    */
    public string checkIfRenewalDateOrPremiumIncrease<T>(T
      itemOne, T itemTwo)
    {
      /*
      The is operator checks if the result of an expression 
      is compatible with a given type
      */
      if (itemOne is string)
      {
        DateTime renewalDate = Convert.ToDateTime(itemOne);
        if (renewalDate.Month == DateTime.Now.Month)
        {
          return ($"The customers {itemTwo} " +
            $"policy is due for renewal this month ");
        }
        else
        {
          return ($"The customers {itemTwo} policy is not " +
            $"due for renewal until month {renewalDate.Month}");
        }
      }
      else
      {
        double monthlyPremium = Convert.ToDouble(itemOne.ToString());
        double premiumIncrease = Convert.ToDouble(itemTwo.ToString());
        double newMonthlyPremium = monthlyPremium
                + (monthlyPremium * premiumIncrease / 100);

        return ($"The new monthly premium is {newMonthlyPremium:0.00}");
      }

    }// End of checkIfRenewalDateOrPremiumIncrease() method
  } // End of RenewalMatcher class


} // End of Chapter23 namespace 