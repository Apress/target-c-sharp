﻿using System;

namespace Chapter23
{
  class Generics1
  {
    static void Main(string[] args)
    {
      // Instantiate the PolicyMatcher class
      PolicyMatcher myPolicyMatcher = new PolicyMatcher();

      /* 
      Call the add method passing it the two policy values
      with the correct data type
      */
      Console.WriteLine(myPolicyMatcher.checkIfTheSame(10000, 20000));

    } // End of Main() method

  } // End of Generics1 class

  class PolicyMatcher
  {
    /*
    A method which is not generic because it has specifies 
    the parameter data types. The method cannot be used 
    when passing floats etc. It is specific not generic.
    */
    public string checkIfTheSame(int itemOne, int itemTwo)
    {
      if (itemOne.Equals(itemTwo))
      {
        return ($"The {itemOne.GetType()} values {itemOne} " +
          $"and {itemTwo} are equal");
      }
      else
      {
        return ($"The {itemOne.GetType()} values {itemOne}" +
          $" and {itemTwo} are not equal");
      }
    }// End of checkIfTheSame() method
  } // End of PolicyMatcher class

} // End of Chapter23 namespace 