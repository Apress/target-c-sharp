﻿using System;

namespace Chapter12
{
  internal class MethodsVoid
  {
    /* 
    The array is going to hold the data for 2 claims. 
    Each claim has four pieces of information. The number of 
    data items is therefore 2 multiplied by 4 = 8. 
    So, we will make the array for this example of size 8.
    Not the best way to do things but fine for now. 
    */
    static String[] repairShopClaims = new String[8];

    /*
    We will setup our variables that will be used in the 
    quote application. The details will be: 
    •	the repair shop unique id (string)
    •	the vehicle insurance policy number (string)
    •	the claim amount (double)
    •	the date of the claim (date)  
    */
    static string repairShopID;
    static string vehiclePolicyNumber;
    static double claimAmount;
    static DateTime claimDate;
    static int numberOfClaimsBeingMade;
    static int numberOfClaimsEntered = 0;
    static int arrayPositionCounter = 0;


    static void Main(string[] args)
    {
      double answer = Math.Sqrt(9.00);

      // Call the method that asks how many claims will be entered
      HowManyClaimsAreBeingMade();

      do
      {
        // Call the methods as required
        CurrentValueOfCounter();
        ReadTheRepairShopId();
        WriteRepairShopIdToTheArray();
        ReadTheVehiclePolicyNumber();
        WriteVehiclePolicyNumberToTheArray();
        ReadTheAmountBeingClaimed();
        WriteClaimAmountToTheArray();
        ReadTheRepairDate();
        WriteRepairDateToTheArray();

        /* Increment the loop counter by 1 */
        numberOfClaimsEntered++;
      } while (numberOfClaimsEntered < numberOfClaimsBeingMade);

      DisplayAllItemsInTheArray();

    } // End of Main() method

    /*****************************************************
      All the methods will be located here. 
      They are outside the main but inside the class 
      *****************************************************/
    /******************* METHOD ONE ******************/
    public static void HowManyClaimsAreBeingMade()
    {
      /* 
      Read the user input for the number of claims being made 
      and convert the string value to an integer data type
      */
      Console.WriteLine("How many claims are being made?\n");
      numberOfClaimsBeingMade = Convert.ToInt32(Console.ReadLine());
    } // End of HowManyClaimsAreBeingMade() method

    /******************* METHOD TWO ******************/
    public static void CurrentValueOfCounter()
    {
      Console.WriteLine("The current value of the counter " +
        "is :" + numberOfClaimsEntered + "\n");
    } // End of CurrentValueOfCounter() method

    /******************* METHOD THREE ******************/
    public static void ReadTheRepairShopId()
    {
      Console.WriteLine("What is your repair shop id?\n");
      repairShopID = Console.ReadLine();
    }// End of ReadTheRepairShopId() method


    /******************* METHOD FOUR ******************/
    public static void WriteRepairShopIdToTheArray()
    {
      repairShopClaims[arrayPositionCounter] = repairShopID;
      arrayPositionCounter++;
    } // End of WriteRepairShopIdToTheArray() method

    /******************* METHOD FIVE ******************/
    public static void ReadTheVehiclePolicyNumber()
    {
      Console.WriteLine("What is the vehicle policy number?\n");
      vehiclePolicyNumber = Console.ReadLine();
    } // End of ReadTheVehiclePolicyNumber() method


    /******************* METHOD SIX ******************/
    public static void WriteVehiclePolicyNumberToTheArray()
    {
      repairShopClaims[arrayPositionCounter] = vehiclePolicyNumber;
      arrayPositionCounter++;
    } // End of WriteVehiclePolicyNumberToTheArray() method

    /******************* METHOD SEVEN ******************/
    public static void ReadTheAmountBeingClaimed()
    {
      Console.WriteLine("What is the amount being " +
        "claimed for the repair?\n");
      claimAmount = Convert.ToDouble(Console.ReadLine());
    } // End of ReadTheAmountBeingClaimed() method


    /******************* METHOD EIGHT ******************/
    public static void WriteClaimAmountToTheArray()
    {
      repairShopClaims[arrayPositionCounter]
                  = claimAmount.ToString();
      arrayPositionCounter++;
    }// End of WriteClaimAmountToTheArray() method

    /******************* METHOD NINE ******************/
    public static void ReadTheRepairDate()
    {
      Console.WriteLine("What was the date of the repair?\n");
      claimDate = Convert.ToDateTime(Console.ReadLine());
    }// End of method ReadTheRepairDate() method


    /******************* METHOD TEN ******************/
    public static void WriteRepairDateToTheArray()
    {
      repairShopClaims[arrayPositionCounter]
                  = claimDate.ToString();
      arrayPositionCounter++;
    }// End of method WriteRepairDateToTheArray() method


    /******************* METHOD ELEVEN ******************/
    public static void DisplayAllItemsInTheArray()
    {
      foreach (var itemInTheClaimsArray in repairShopClaims)
      {
        Console.WriteLine("The item in the array " +
          "is:\t" + itemInTheClaimsArray + "\n");
      }
    } // End of method DisplayAllItemsInTheArray() method







  } // End of MethodsVoid class
} // End of Chapter12 namespace  