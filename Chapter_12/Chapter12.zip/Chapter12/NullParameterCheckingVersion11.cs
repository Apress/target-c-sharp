﻿using System;

namespace Chapter12
{
  internal class NullParameterCheckingVersion11
  {
    static void Main(string[] args)
    {
      //string vehicleRegistration = null;

     // DisplayInvoice(vehicleRegistration, 10000, 2000);
    } // End of Main() method

    //public static void DisplayInvoice(string vehicleRegistration!!, double repairTotal, double vatAmount)
    //{
    //  Console.WriteLine("\nInvoice for vehicle repairs\n");
    //  Console.WriteLine("Vehicle registration\t" + vehicleRegistration + "\n");
    //  Console.WriteLine("Repair amount\t\t$" + repairTotal + "\n");
    //  Console.WriteLine("VAT amount\t\t$" + vatAmount + "\n");

    //} // End of DisplayInvoice() method
  } // End of NullParameterCheckingVersion11 class
} // End of Chapter12 namespace  