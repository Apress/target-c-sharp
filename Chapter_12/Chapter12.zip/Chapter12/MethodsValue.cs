﻿using System;

namespace Chapter12
{
  internal class MethodsValue
  {
    /* 
    The array is going to hold the data for 2 claims. 
    Each claim has four pieces of information. The number of 
    data items is therefore 2 multiplied by 4 = 8. 
    So, we will make the array for this example of size 8.
    Not the best way to do things but fine for now. 
    */
    static String[] repairShopClaims = new String[8];

    /*
    We will setup our variables that will be used in the 
    quote application. The details will be: 
    •	the repair shop unique id (string)
    •	the vehicle insurance policy number (string)
    •	the claim amount (double)
    •	the date of the claim (date)  
    */
    static string repairShopID;
    static string vehiclePolicyNumber;
    static double claimAmount;
    static DateTime claimDate;
    static int numberOfClaimsBeingMade;
    static int numberOfClaimsEntered = 0;
    static int arrayPositionCounter = 0;
    static double totalofallclaims;
    static double vatamount;

    static void Main(string[] args)
    {
      // Call the method that asks how many claims will be entered
      numberOfClaimsBeingMade = HowManyClaimsAreBeingMade();

      do
      {
        // Call the methods as required
        CurrentValueOfCounter();

        repairShopID = ReadTheRepairShopId();
        WriteRepairShopIdToTheArray();

        vehiclePolicyNumber = ReadTheVehiclePolicyNumber();
        WriteVehiclePolicyNumberToTheArray();

        claimAmount = ReadTheAmountBeingClaimed();
        WriteClaimAmountToTheArray();

        claimDate = ReadTheRepairDate();
        WriteRepairDateToTheArray();

        /* Increment the loop counter by 1 */
        numberOfClaimsEntered++;
      } while (numberOfClaimsEntered < numberOfClaimsBeingMade);

      vatamount = CalculateVATAmount(totalofallclaims);

      DisplayAllItemsInTheArray();
      Console.WriteLine("The total amount claimed " +
  "is:\t" + totalofallclaims);

      DisplayInvoiceReceipt(totalofallclaims, vatamount);

      DisplayInvoiceReceipt(totalofallclaims, vatamount, "\t" +
 "Thank you for your claims\n\tthey will be processed today");

    } // End of Main() method

    /*****************************************************
      All the methods will be located here. 
      They are outside the main but inside the class 
      *****************************************************/
    /******************* METHOD ONE ******************/
    public static int HowManyClaimsAreBeingMade()
    {
      /* 
      Read the user input for the number of claims being made 
      and convert the string value to an integer data type
      */
      Console.WriteLine("How many claims are being made?\n");

      return Convert.ToInt32(Console.ReadLine());
    } // End of HowManyClaimsAreBeingMade() method

    /******************* METHOD TWO ******************/
    public static void CurrentValueOfCounter()
    {
      Console.WriteLine("The current value of the counter " +
        "is :" + numberOfClaimsEntered + "\n");
    } // End of CurrentValueOfCounter() method

    /******************* METHOD THREE ******************/
    public static string ReadTheRepairShopId()
    {
      Console.WriteLine("What is your repair shop id?\n");
      return Console.ReadLine();
    }// End of ReadTheRepairShopId() method


    /******************* METHOD FOUR ******************/
    public static void WriteRepairShopIdToTheArray()
    {
      repairShopClaims[arrayPositionCounter] = repairShopID;
      arrayPositionCounter++;
    } // End of WriteRepairShopIdToTheArray() method

    /******************* METHOD FIVE ******************/
    public static string ReadTheVehiclePolicyNumber()
    {
      Console.WriteLine("What is the vehicle policy number?\n");
      return Console.ReadLine();
    } // End of ReadTheVehiclePolicyNumber() method


    /******************* METHOD SIX ******************/
    public static void WriteVehiclePolicyNumberToTheArray()
    {
      repairShopClaims[arrayPositionCounter] = vehiclePolicyNumber;
      arrayPositionCounter++;
    } // End of WriteVehiclePolicyNumberToTheArray() method

    /******************* METHOD SEVEN ******************/
    public static double ReadTheAmountBeingClaimed()
    {
      Console.WriteLine("What is the amount being " +
        "claimed for the repair?\n");
      double claimAmountFromUser
                      = Convert.ToDouble(Console.ReadLine());

      AccumulateClaimAmount(claimAmountFromUser);

      return claimAmountFromUser;

    } // End of ReadTheAmountBeingClaimed() method


    /******************* METHOD EIGHT ******************/
    public static void WriteClaimAmountToTheArray()
    {
      repairShopClaims[arrayPositionCounter]
                  = claimAmount.ToString();
      arrayPositionCounter++;
    }// End of WriteClaimAmountToTheArray() method

    /******************* METHOD NINE ******************/
    public static DateTime ReadTheRepairDate()
    {
      Console.WriteLine("What was the date of the repair?\n");
      return Convert.ToDateTime(Console.ReadLine());
    }// End of method ReadTheRepairDate() method


    /******************* METHOD TEN ******************/
    public static void WriteRepairDateToTheArray()
    {
      repairShopClaims[arrayPositionCounter]
                  = claimDate.ToString();
      arrayPositionCounter++;
    }// End of method WriteRepairDateToTheArray() method


    /******************* METHOD ELEVEN ******************/
    public static void DisplayAllItemsInTheArray()
    {
      foreach (var itemInTheClaimsArray in repairShopClaims)
      {
        Console.WriteLine("The item in the array " +
          "is:\t" + itemInTheClaimsArray + "\n");
      }
    } // End of method DisplayAllItemsInTheArray() method

    /******************* METHOD TWELVE ******************/
    public static double AccumulateClaimAmount(double
    claimamountpassedin)
    {
      totalofallclaims = totalofallclaims + claimamountpassedin;
      return totalofallclaims;
    }// End of method AccumulateClaimAmount()


    /******************* METHOD THIRTEEN ******************/
    public static double CalculateVATAmount(double
                                 totalvalueofclaimspassedin)
    {
      vatamount = totalvalueofclaimspassedin - 
        (totalvalueofclaimspassedin / 1.20);
      return vatamount;
    } // End of method CalculateVATAmount()

    /******************* METHOD FOURTEEN ******************/
    public static void DisplayInvoiceReceipt(double
           totalvalueofclaimspassedin, double vatPassedIn)
    {
      Console.WriteLine("\nInvoice for vehicle repairs\n");
      Console.WriteLine("Nett claim\t" + 
        (totalofallclaims - vatamount) + "\n");
      Console.WriteLine("VAT amount\t" + vatamount + "\n");
      Console.WriteLine("Total amount\t" + 
        totalofallclaims + "\n");
    } // End of method DisplayInvoiceReceipt()

    /******************* METHOD FIFTEEN ******************/
    public static void DisplayInvoiceReceipt(double
    totalvalueofclaimspassedin, double vatPassedIn, String
    messagePassedIn)
    {

      Console.WriteLine("********************************");
      Console.WriteLine("\nInvoice for vehicle repairs\n");
      Console.WriteLine("Nett claim\t" + (totalofallclaims - vatamount) + "\n");
      Console.WriteLine("VAT amount\t" + vatamount + "\n");
      Console.WriteLine("Total amount\t" + totalofallclaims + "\n");
      Console.WriteLine(messagePassedIn);

      Console.WriteLine("********************************");
    } // End of method DisplayInvoiceReceipt


  } // End of MethodsValue class
} // End of Chapter12 namespace  