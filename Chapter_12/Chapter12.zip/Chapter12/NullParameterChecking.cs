﻿using System;

namespace Chapter12
{
  internal class NullParameterChecking
  {
    static void Main(string[] args)
    {
      // string vehicleRegistration = "ABC 1234";
      string vehicleRegistration = null;
      DisplayInvoice(vehicleRegistration, 10000, 2000);

    } // End of Main() method

    public static void DisplayInvoice(string vehicleRegistration,
      double repairTotal, double vatAmount)
    {
      if (vehicleRegistration == null)
      {
       // Console.WriteLine("\nNull value error message\n");
        ArgumentNullException.ThrowIfNull(vehicleRegistration);

      } // End of if block
      else
      {
        Console.WriteLine("\nInvoice for vehicle repairs\n");
        Console.WriteLine("Vehicle registration\t" +
                            vehicleRegistration + "\n");
        Console.WriteLine("Repair amount\t\t$" +
                                    repairTotal + "\n");
        Console.WriteLine("VAT amount\t\t$" +
                                  vatAmount + "\n");
      } // End of else block
    } // End of DisplayInvoice() method

  } // End of NullParameterChecking class
} // End of Chapter12 namespace  