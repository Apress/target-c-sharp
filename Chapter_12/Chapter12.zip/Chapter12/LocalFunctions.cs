﻿using System;

namespace Chapter12
{
  internal class LocalFunctions
  {
    static void Main(string[] args)
    {
      double costOfRepair = 350.00;
      double vatRate = 20;
      VATCalculations myVATCalculations = new VATCalculations();

      double costOfRepairWithVAT =
myVATCalculations.CalculateRepairCostIncludingVAT(costOfRepair);

      Console.WriteLine($"For a repair costing " +
  $"${costOfRepair:0.00} the cost including VAT at" +
  $" { vatRate}% will be ${ costOfRepairWithVAT: 0.00}");

    }// End of Main() method

  } // End of LocalFunctions class

  /**NEW CLASS INSIDE NAMESPACE**/
  public class VATCalculations
  {
    /* 
    Method that takes in the pre-VAT amount and calculates 
    the post VAT amount 
    */
    public double CalculateRepairCostIncludingVAT(double
repairAmountPassedIn)
    {
      return repairAmountPassedIn + CalculateVATAmount(repairAmountPassedIn);

      /* 
      FUNCTION that takes in the pre-VAT amount and 
      calculates the VAT amount. This is a local function, a
      function within a method.
      */
      double CalculateVATAmount(double repairAmount)
      {
        double vatamount = repairAmount * 20 / 100;
        return vatamount;
      } // End of local function CalculateVATAmount

    } // End of calculateRepairCostIncludingVAT method

  } // End of VATCalculations class

} // End of Chapter12 namespace  