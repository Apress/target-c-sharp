﻿using System;

namespace Chapter20
{
  internal class MonthExample
  {
    //enum Month
    //{
    //  Jan, Feb, Mar, Apr, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
    //};

    enum Month
    {
      Jan, Feb, Mar, Apr = 4, May, Jun, Jul, Aug, Sep, Oct, Nov, Dec
    };

    static void Main(string[] args)
    {
      Month month = Month.Jan;

      Console.WriteLine("Using an iteration based on the" +
      " enum Length from GetNames");

      int enumMonthLength = Enum.GetNames(typeof(Month)).Length;

      for (int counter = 0; counter < enumMonthLength; counter++)
      {
        Console.Write($" {month++} \t");
      } //End of iteration

      Console.WriteLine();

      Console.WriteLine("Using a foreach iteration which" +
                        " handles the length for us");

      // Returns a String[] array so type is String
      foreach (String valueFound in Enum.GetNames(typeof(Month)))
      {
        Console.Write($" {valueFound} \t");
      }
      Console.WriteLine();

      // Using GetName() to find name of the value
      for (int counter = 0; counter < enumMonthLength; counter++)
      {
        Console.WriteLine(Enum.GetName(typeof(Month), counter));
      } //End of iteration

      Console.WriteLine();

      Console.WriteLine("Using a foreach iteration to " +
  "display the Month values");

      foreach (int integerFound in Enum.GetValues(typeof(Month)))
      {
        Console.Write($" {integerFound} \t");
      }

      Console.WriteLine();

      Console.WriteLine();

      Console.WriteLine("Get the enumeration name from the value");
      foreach (int integerFound in Enum.GetValues(typeof(Month)))
      {
        Console.WriteLine($"The integer value of " +
          $"{integerFound} is the value " +
          $"{Enum.GetName(typeof(Month), integerFound)}");
      }

      Console.WriteLine();

    } //End of Main() method


  } // End of MonthExample class
} // End of Chapter20 namespace