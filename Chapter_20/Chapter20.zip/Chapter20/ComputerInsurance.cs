﻿using System;

namespace Chapter20
{
  enum HardwareType
  {
    Laptop, Large_Screen, Desktop, Printer, Small_Screen
  };

  enum PolicyType
  {
    Gold, Silver, Bronze
  };

  enum Factors
  {
    Zero, One, Two, Three, Four, Five
  };

  internal class ComputerInsurance
  {
    static double hardwareValue, monthlyPremiumAmount,
                  hardwareValueFactor;
    static int hardwareType, policyType, hardwareTypeFactor,
               policyTypeFactor;


    static void Main(string[] args)
    {
      acceptUserInput();

      hardwareTypeFactor = calculateHardwareTypeFactor();
      policyTypeFactor = calculatePolicyTypeFactor();
      hardwareValueFactor = calculateValueFactor();

      calculateMonthlyPremium(hardwareTypeFactor, policyTypeFactor,
           hardwareValueFactor);

    } //End of Main() method

    public static void acceptUserInput()
    {
      Console.WriteLine("0. Laptop");
      Console.WriteLine("1. Large_Screen");
      Console.WriteLine("2. Desktop ");
      Console.WriteLine("3. Printer ");
      Console.WriteLine("4. Small_Screen");
      Console.WriteLine("What is the int value of the hardware type?");
      hardwareType = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("0. Gold");
      Console.WriteLine("1. Silver");
      Console.WriteLine("2. Bronze");
      Console.WriteLine("What policy type is required?");
      policyType = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("What is the estimated value of the hardware?");
      hardwareValue = Convert.ToDouble(Console.ReadLine());

    }  // End of acceptUserInput method

    public static int calculateHardwareTypeFactor()
    {
      switch (hardwareType)
      {
        case 0:
          return (int)Factors.Five;
        case 1:
          return (int)Factors.Five;
        case 2:
          return (int)Factors.Four;
        case 3:
          return (int)Factors.Three;
        case 4:
          return (int)Factors.Two;
        default:
          return 0;
      } // End of switch statement

    }// End of calculateHardwareTypeFactor method

    public static int calculatePolicyTypeFactor()
    {
      switch (policyType)
      {
        case 0:
          return (int)Factors.Five;
        case 1:
          return (int)Factors.Three;
        case 2:
          return (int)Factors.Two;
        default:
          return 0;
      } // End of switch statement
    }// End of calculatePolicyTypeFactor method

    public static double calculateValueFactor()
    {
      return hardwareValue / 5000;
    }// End of calculatePolicyTypeFactor method

    public static void calculateMonthlyPremium(int
                       hardwareTypeFactor,
      int policyTypeFactor, double hardwareValueFactor)
    {
      if (hardwareTypeFactor == 0 || policyTypeFactor == 0)
      {
        Console.WriteLine("Hardware or policy type incorrect");
      }
      else
      {
        monthlyPremiumAmount = monthlyPremiumAmount = hardwareTypeFactor * policyTypeFactor * hardwareValueFactor;

        Console.WriteLine($"Monthly premium for a " +
          $"{Enum.GetName(typeof(HardwareType), hardwareType)}" +
          $"({hardwareType}) " +
          $"{Enum.GetName(typeof(PolicyType), policyType)}" +
          $"({policyType}) policy is ${ monthlyPremiumAmount: 0.00}");


        Console.WriteLine($"HardwareType enumeration at" +
          $" position {hardwareType} is " +
          $"{Enum.GetName(typeof(HardwareType), hardwareType)}");

        Console.WriteLine($"PolicyType enumeration at " +
          $"position {policyType} is " +
          $"{Enum.GetName(typeof(PolicyType), policyType)}");

        Console.WriteLine("*****Casting the enumeration VALUE " +
   "to the enumeration NAME");

        Console.WriteLine($"HardwareType enumeration at position" +
             $" {hardwareType} is { (HardwareType)hardwareType}");

        Console.WriteLine($"PolicyType enumeration at position" +
          $" {policyType} is { (PolicyType)policyType}");

      }
    }// End of calculateMonthlyPremium method

  } // End of ComputerInsurance class
} // End of Chapter20 namespace