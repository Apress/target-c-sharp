﻿using System;

namespace Chapter17
{
  internal class ExceptionHandling
  {
    static void Main(string[] args)
    {
      try
      {
        GetHardwareValue();
      }
      catch (Exception ex)
      {
        Console.WriteLine(ex.Message);
      }


      //CheckIfQuoteCanBeMade();

      try
      {
        int hardwareTypeValue = 10;
        double premium = 100 / hardwareTypeValue;
        Console.WriteLine(premium);

        //StreamReader myStreamReader = new
        //           StreamReader("policydetailsXXX.txt");

        //while (myStreamReader.Peek() > 0)
        //{
        //  Console.Write(myStreamReader.Read() + "\t");
        //}
        //myStreamReader.Close();

      } // End of try block
      catch (DivideByZeroException)
      {
        Console.WriteLine($"Divide By Zero Exception message");
      }  // End of try block
      catch (FileNotFoundException exNoFile)
      {
        // Write the 'whole' exception
        Console.WriteLine(exNoFile.StackTrace);
      }// End of FileNotFoundException catch block
      catch (Exception ex)
      {
        Console.WriteLine($"Exception message is - {ex.Message}");
      }  // End of catch block
      finally
      {
        Console.WriteLine("Try catch blocks ended, tidying up");       
      }
    } //End of Main() method

    public static void CheckIfQuoteCanBeMade()
    {
      Console.WriteLine("What is the value of the hardware to be insured?");

      double hardwareValue = Convert.ToDouble(Console.ReadLine());
      try
      {
        if (hardwareValue > 0 && hardwareValue < 10000)
        {
          Console.WriteLine("Quote will be available");
        }
        else
        {
          throw new HardwareValueException("HardwareValueException - value too high");
        }
      } // End of try block
      catch (HardwareValueException ourException)
      {
        Console.WriteLine(ourException.Message.ToString());
      } // End of  catch block

    }// End of CheckIfQuoteCanBeMade method

    public static void GetHardwareValue()
    {
      double hardwareValue;

      try
      {
        Console.WriteLine("What is the hardware replacement value?");
        hardwareValue = Convert.ToDouble(Console.ReadLine());
      }
      catch (Exception ex)
      {
        throw;
      }
    } // End of GetHardwareValue() method

  } // End of ExceptionHandling class

  //  Our custom exception for a value which is too high
  public class HardwareValueException : Exception
  {
    public HardwareValueException(string errormessage) :
                                        base(errormessage)
    {
     
    } // End of HardwareValueException constructor
  } // End of HardwareValueException class

} // End of Chapter17 namespace