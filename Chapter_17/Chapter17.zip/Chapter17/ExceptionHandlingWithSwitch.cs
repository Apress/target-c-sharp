﻿using System;

namespace Chapter17
{
  internal class ExceptionHandlingWithSwitch
  {
    static void Main(string[] args)
    {
      try
      {
        // Testing FileNotFoundException
        //using (var fileStream = 
        //  new FileStream(@"NoFileExists.txt", FileMode.Open))
        //{
        //  // Logic for reading file would go here
        //}

        // Testing DivideByZeroException
        //int hardwareTypeValue = 0;
        //double premium = 100 / hardwareTypeValue;

        // Testing OverflowException
        Console.WriteLine("How many claims are being made?");
        int claimValue = Convert.ToByte(Console.ReadLine());

      } // End of try block
      catch (Exception ex)
      {
        switch (ex)
        {
          case FileNotFoundException:
            Console.WriteLine("File not found Exception!");
            break;
          case DivideByZeroException:
            Console.WriteLine("Divide By Zero Exception");
            break;
          case OverflowException:
            Console.WriteLine("Overflow Exception");
            break;
        } // End of switch block
      } // End of catch block
      finally
      {
        Console.WriteLine("Try catch blocks ended, tidying up");
      } // End of finally block

    } //End of Main() method
  } // End of ExceptionHandlingWithSwitch class
} // End of Chapter17 namespace