﻿using System;

namespace Chapter9
{
  internal class Ternary
  {
    static void Main(string[] args)
    {
      /* 
      We will setup our variables that will be used in 
      the quote application  
      */
      int yearsOfNoClaims;

      /* Read the user input and convert it to an int */
      Console.WriteLine("How many full years of no claims" +
        " does the driver have?\n");
      yearsOfNoClaims = Convert.ToInt32(Console.ReadLine());

      // Assign the result of the ternary to a string variable
      string message = yearsOfNoClaims > 10 ?
                "Years of no claims is more than 10" :
                "Years of no claims is less than or equal to 10";

      // Display the result of the ternary condition
      Console.WriteLine(message);

      // Assign the result of the ternary to a string variable
      string newMessage = yearsOfNoClaims > 10 ?
              "Years of no claims is more than 10" :
              yearsOfNoClaims > 8 ?
              "Years of no claims is either 9 or 10" :
              yearsOfNoClaims > 6 ?
              "Years of no claims is either 7 or 8" :
              yearsOfNoClaims > 4 ?
              "Years of no claims is either 5 or 6" :
              yearsOfNoClaims > 2 ?
              "Years of no claims is either 3 or 4" :
              "Years of no claims is 2, 1, 0 \n " +
              "or indeed a negative number of years \n " +
              "because of a penalty being enforced on our policy";

      // Display the result of the new ternary condition
      Console.WriteLine(newMessage);

    } // End of Main() method

  } // End of Ternary class
} // End of Chapter9 namespace  