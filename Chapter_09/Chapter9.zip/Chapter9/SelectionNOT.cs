﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
  internal class SelectionNOT
  {
    static void Main(string[] args)
    {
      /* 
      We will setup our variables that will be used in 
      the quote application 
      */
      int yearsOfNoClaims;
      int ageOfDriver;

      /* Read the user input and convert it to an int */
      Console.WriteLine("How many full years of no claims " +
        "does the driver have?\n");

      yearsOfNoClaims = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("What is the current age of " +
  "the driver?\n");

      ageOfDriver = Convert.ToInt32(Console.ReadLine());

      /* 
      Now we will check if the years of no claims is greater 
      than 10 OR if the age of the driver is greater than 40. 
      If both are TRUE we have the Boolean expression 
      TRUE AND TRUE which equates to TRUE or if one of them 
      is TRUE we have the Boolean expression TRUE OR FALSE 
      or FALSE OR TRUE which equates to TRUE and we then we 
      execute some lines of code which exist between the curly 
      braces of the code block, otherwise the program moves 
      to the else code block and executes some lines of code
      in this code block 
      */

      if (!(yearsOfNoClaims > 10 && ageOfDriver > 40))
      {
        /*
          This block of code will be executed if both
          parts of the condition are TRUE
        */
        Console.WriteLine("This quote is eligible for " +
          "a 10% discount");
      } // End of true part
      else
      {
        /*
        This block of code will be executed if the one
        part of the condition is FALSE
        */
        Console.WriteLine("This quote is ineligible for " +
          "a discount");
      } // End of false part

    } // End of Main() method

  } // End of SelectionNOT class
} // End of Chapter9 namespace