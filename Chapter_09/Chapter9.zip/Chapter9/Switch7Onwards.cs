﻿using System;

namespace Chapter9
{
  internal class Switch7Onwards
  {
    static void Main(string[] args)
    {
      /* 
      We will setup our variables that will be used in 
      the quote application  
      */
      int yearsOfNoClaims;

      /* Read the user input and convert it to an int */
      Console.WriteLine("How many full years of no claims " +
        "does the driver have?\n");
      yearsOfNoClaims = Convert.ToInt32(Console.ReadLine());

      /* 
      Now we will check if the years of no claims is greater 
      than 10
      * if it is true then we execute some lines of code 
        which exist between the curly braces, else the program 
        just moves to the next code line which is to read a key
      */
      switch (yearsOfNoClaims)
      {
        case int numberOfYearsEntered when (yearsOfNoClaims > 10):
          /*
          This block of code will be executed if the 
          yearsofnoclaims is more than 10
          */
          Console.WriteLine("Years of no claims is more than 10");
          break;

        case int numberOfYearsEntered when (yearsOfNoClaims > 8):
          /* 
          This block of code will be executed if the 
          yearsofnoclaims is more than 8 which means 9, 10, 11, 
          12 etc. However if yearsofnoclaims is 11, 12 etc it 
          will have been detected in the case above where the 
          condition  yearsofnoclaims > 10is used. 
          */
          Console.WriteLine("Years of no claims is either 9 or 10");
          break;

        case int numberOfYearsEntered when (yearsOfNoClaims > 6):
          /* 
          This block of code will be executed if the 
          yearsofnoclaims is more than 6 which means 7, 8, 9, 
          10 etc. However if yearsofnoclaims is 9, 10 etc it will
          have been detected in the case above where the condition 
          yearsofnoclaims > 8 is used. 
          */
          Console.WriteLine("Years of no claims is either 7 or 8");
          break;

        case int numberOfYearsEntered when (yearsOfNoClaims > 4):
          /* 
          This block of code will be executed if the 
            yearsofnoclaims is more than 4 which means 5, 6, 7, 
            8 etc. However if yearsofnoclaims is 7, 8 etc it will 
            have been detected in the case above where the condition 
            yearsofnoclaims > 4 is used. 
            */
          Console.WriteLine("Years of no claims is either 5 or 6");
          break;

        case int numberOfYearsEntered when (yearsOfNoClaims > 2):
          /* 
          This block of code will be executed if the 
          yearsofnoclaims is more than 2 which means 3, 4, 5, 
          6 etc.. However if yearsofnoclaims is 5, 6 etc it will 
          have been detected in the case above where the condition 
          yearsofnoclaims > 2 is used. 
          */
          Console.WriteLine("Years of no claims is either 3 or 4");
          break;

        default:
          /*
          This block of code will be executed if the 
          yearsofnoclaims is not more than 2. For this block of 
          code to be executed none of the conditions above must 
          have been true (and none of the blocks of code were 
          executed*/
          Console.WriteLine("Years of no claims is 2, 1, 0 \n" +
            "or indeed a negative number of years \nbecause of a " +
            "penalty being enforced on our policy");
          break;
      } // End of switch

    } // End of Main() method

  } // End of Switch7Onwards class
} // End of Chapter9 namespace  