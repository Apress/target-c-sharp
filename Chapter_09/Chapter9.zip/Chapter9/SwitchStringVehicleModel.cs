﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter9
{
  internal class SwitchStringVehicleModel
  {
    static void Main(string[] args)
    {
      /* 
      In this section we declare the two variables of data type  
      string that we will use throughout the program code. 
      */
      string vehicleModel;
      string vehicleManufacturer;

      Console.WriteLine();
      Console.WriteLine("What is the model of the vehicle?\n");

      /* 
      In this section we read the user input from the console.  
      The console input is by default a string data type which
      means we can directly assign the value to the string 
      variable called vehicleModel. */
      vehicleModel = Console.ReadLine();

      /* 
      In this section we use the string variable called
      vehicleModel in the case statement to decide which block 
      of code will be executed. The blocks of code therefore 
      will be based on the model of the vehicle and the code will
      set the value of the variable called vehicleManufacturer. 
      */
      switch (vehicleModel.ToUpper())
      {
        case "Edge":
        case "Fiesta":
        case "Focus":
        case "Kuga":
        case "Mondeo":
        case "Mustang":
          vehicleManufacturer = "Ford";
          break;
        case "Astra":
        case "Corsa":
        case "Insignia":
        case "Viva":
          vehicleManufacturer = "Vauxhall";
          break;
        case "Altima":
        case "Juke":
        case "Sentra":
          vehicleManufacturer = "Nissan";
          break;
        case "C-Class":
        case "E-Class":
        case "S-Class":
        case "GLA":
        case "GLC":
        case "GLE":
          vehicleManufacturer = "Mercedes Benz";
          break;
        default:
          vehicleManufacturer = "unknown";
          break;
      }
      /* 
      Here we will write the same message to the console in two
      different ways so we can use a new technique 
      */

      /* 
      In this statement we are writing data to the console in 
      our normal way with a concatenated (joined) string and 
      this works fine
      */
      Console.WriteLine("\nThe " + vehicleModel + " " +
        "manufacturer is " + vehicleManufacturer);

      /* 
      In this statement we are writing data to the console in a 
      different way using a string which has placeholders {}. 
      Each place holder has a number and this number represents
      the position of the variable name which is in the comma
      separated list at the end of the statement. The variables
      are numbered starting with a 0 then a 1 etc (zero indexed)
      and are at the end of the statement.
      The example below effectively means 
      Console.WriteLine("\nThe vehicleModel manufacturer is 
      vehicleManufacturer ");
      This new format is very neat and means we do not have to 
      keep opening and closing the double quotes and having the 
      concatenation + symbol. 
      */
      Console.WriteLine("\nThe {0} manufacturer is {1} ",
        vehicleModel.ToUpper(), vehicleManufacturer);

    } // End of Main() method

  } // End of SwitchStringVehicleModel class
} // End of Chapter9 namespace  