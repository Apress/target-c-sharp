﻿using System;

namespace Chapter24
{
  /*
  An Insertion Sort is similar to a Bubble sort, however, it is
  a more efficient sort. We should think about using the 
  Insertion sort when we have a small number of elements to sort.
  Larger data sets will take more time.
  */
  internal class InsertionSort
  {
    static void Main(string[] args)
    {
      // Declare and create the array of claim values
      int[] claimValues = 
        {6000, 9000, 3000, 4000, 8000, 1000, 2000, 5000, 7000 };

      /* 
       Pass the array of claim values to the 
      method insertionSortTheArray()
      */
      InsertionSortOfTheArray(claimValues);

      // Pass the array to the method DisplayArrayElements()
      DisplayArrayElements(claimValues);


    } // End of Main() method

    /* Method to sort array using an insertion sort*/
    static void InsertionSortOfTheArray(int[] claimValuesPassedIn)
    {
      for (int counter = 1; counter < claimValuesPassedIn.Length; ++counter)
      {
        int currentKeyValue = claimValuesPassedIn[counter];
        int previousValue = counter - 1;

        /* Move elements that are greater than the currentArrayValue
           to one position in front of their current position */
        while (previousValue >= 0 && claimValuesPassedIn[previousValue] > currentKeyValue)
        {
          Console.WriteLine($"Comparing { claimValuesPassedIn[previousValue]} and { currentKeyValue}");

          claimValuesPassedIn[previousValue + 1] = claimValuesPassedIn[previousValue];
          previousValue = previousValue - 1;
        }
        claimValuesPassedIn[previousValue + 1] = currentKeyValue;
        // This line is used to display the values being compared, remove when completed
        //DisplayArrayElements(claimValuesPassedIn);
      } // End of Iteration of the array
    } // End of insertionSortOfTheArray


    /* Prints the array */
    static void DisplayArrayElements(int[] claimValuesPassedIn)
    {
      for (int counter = 0; counter < claimValuesPassedIn.Length; ++counter)
      {
        Console.WriteLine($"{claimValuesPassedIn[counter]}");
      }
    } // End of DisplayArrayElements() method


  } // End of Insertion class
} // End of Chapter24 namespace