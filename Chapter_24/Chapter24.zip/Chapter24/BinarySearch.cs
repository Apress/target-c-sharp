﻿using System;

namespace Chapter24
{
  /*
  With a binary search we must first ensure the array is sorted. 
  The binary search starts with the whole array and checks if
  the value of our search key is less than the item in the
  middle of the array. 
    If it is, the search is narrowed to the lower 
    (left) half of the array. 
    If it is not, then we use the upper (right) half. 
  We repeat the process until the value is found or there 
  are elements left to half.
  */

  internal class BinarySearch
  {
    static void Main(string[] args)
    {
      // Declare and create the array of claim values
      int[] claimValues = 
        {6000, 9000, 3000, 4000, 8000, 1000, 2000, 5000, 7000};

      // Value to be located using binary search
      int valueToBeLocated = 6000;

      // Sort the array as this is essential for a Binary search
      Array.Sort(claimValues);

      // Display the elements of the array 
      DisplayArrayElements(claimValues);

      /*
      Call the binary search method passing it the array and the 
      value to be located and store the returned value in a 
      variable called returnedValue
      */
      int returnedValue = 
        PerformBinarySearch(claimValues, valueToBeLocated);

      // Display the appropriate message (located or not)
      if (returnedValue == -1)
      {
        Console.WriteLine("The value is not present in array");
      }
      else
      {
        // Using an interpolated string
        Console.WriteLine($"The value was located at index " +
          $"{returnedValue} (position { returnedValue + 1})");
       } // End of if else construct

    } // End of Main() method 

    public static int PerformBinarySearch(int[] arrayPassedIn, 
      int numberToBeFound)
    {
      int firstPosition = 0;
      int lastPosition = arrayPassedIn.Length - 1;
      int middlePosition = (firstPosition + lastPosition) / 2;

      while (firstPosition <= lastPosition)
      {
        if (arrayPassedIn[middlePosition] < numberToBeFound)
        {
          firstPosition = middlePosition + 1;
        }
        else if (arrayPassedIn[middlePosition] == numberToBeFound)
        {
          break;
        }
        else
        {
          lastPosition = middlePosition - 1;
        }
        middlePosition = (firstPosition + lastPosition) / 2;
      } // End of while iteration

      if (firstPosition > lastPosition)
      {
        middlePosition = -1;
      }
      return middlePosition;
    } // End of PerformBinarySearch() method

    /* Prints the array */
    static void DisplayArrayElements(int[] claimValuesPassedIn)
    {
      for (int counter = 0; counter < claimValuesPassedIn.Length; ++counter)
      {
        Console.WriteLine($"{claimValuesPassedIn[counter]}");
      }
    } // End of DisplayArrayElements

  } // End of BinarySearch class

} // End of Chapter24 namespace