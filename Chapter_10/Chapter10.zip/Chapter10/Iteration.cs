﻿using System;

namespace Chapter10
{
  internal class Iteration
  {
    static void Main(string[] args)
    {
    /*
    Set up the variables to be used in the quote application
    The details will be:
    - the repair shop unique id            (String)
    - the vehicle insurance policy number  (String)
    - the claim amount and                 (double)
    - the date of the claim                (date)
    */
      String repairShopID;
      String vehiclePolicyNumber;
      String claimDate;
      double claimAmount;
      /* 
      Set up a variable called numberOfClaimsBeingMade 
      of data type int and assign the variable the value 2
      */
      int numberOfClaimsBeingMade;//int numberOfClaimsBeingMade=2;

      int maximumNumberOfClaims = 5;

      /* 
      Read the user input for the number of claims being 
      made and convert the string value to an integer data type
      */
      Console.WriteLine("How many claims are being made?\n");
      numberOfClaimsBeingMade = Convert.ToInt32(Console.ReadLine());

      for (int claimsCounter = 0; claimsCounter 
        < numberOfClaimsBeingMade; claimsCounter++)
      {
        Console.WriteLine("The current value of the counter " +
  "is :" + claimsCounter + "\n");

        /* 
        We will use the if statement to perform a boolean test 
        and if the test produces a true value we will break out 
        of the loop. There is no else part to the if statement 
        so if the boolean test produces a false value the loop 
        simply continues executing the block of code 
        */
        if (claimsCounter == maximumNumberOfClaims)
        {
          /* 
          We have reached the maximum number of claims allowed
          in one session so we will break out of the loop early 
          */
          Console.WriteLine("Breaking out of the loop?\n");
          break;
        } // End of if section

        /* 
        We will use the if statement to perform a boolean test 
        and if the test produces a true value we continue with
        the loop but will skip out of this current iteration. 
        In this example we will check if the value of the 
        counter is even (when we divide by 2 the remainder is 0).
        If it is an even number we will skip the rest of this 
        iteration by using the continue statement. There is 
        no else part to the if statement so if the boolean test
        produces a false value the loop carries on executing 
        the block of code 
        */
        if (claimsCounter % 2 == 0)
        {
          /* 
          We have reached the maximum number of claims allowed 
          in one session so we will break out of the loop early 
          */
          continue;
        }


        /* 
        Read the user input for the repair shop id and 
        keep it as a string 
        */
        Console.WriteLine("What is your repair shop id?\n");
        repairShopID = Console.ReadLine();

        /* 
        Read the user input for the vehicle policy number 
        and keep it as a string 
        */
        Console.WriteLine("What is the vehicle policy number?\n");
        vehiclePolicyNumber = Console.ReadLine();

        /* 
        Read the user input for the repair amount and 
        convert it to a double 
        */
        Console.WriteLine("What is the amount being claimed" +
          " for the repair?\n");
        claimAmount = Convert.ToDouble(Console.ReadLine());

        /* 
        Read the user input for the repair date and 
        convert it to a Date 
        */
        Console.WriteLine("What was the date of the repair?\n");
        claimDate = Console.ReadLine();

        Console.WriteLine("The details entered for repair "
          + (claimsCounter + 1) + " are");
        Console.WriteLine("Repair shop id:\t" + repairShopID);
        Console.WriteLine("Policy number:\t" + vehiclePolicyNumber);
        Console.WriteLine("Claim amount:\t" + claimAmount);
        Console.WriteLine("Claim date:\t" + claimDate);


      } // End of for loop

      Console.WriteLine("End of program\n");


    } // End of Main() method

  } // End of Iteration class
} // End of Chapter10 namespace  