﻿using System;

namespace Chapter10
{
  internal class DoWhileIteration
  {
    static void Main(string[] args)
    {
    /*
    Set up the variables to be used in the quote application
    The details will be:
    - the repair shop unique id            (String)
    - the vehicle insurance policy number  (String)
    - the claim amount and                 (double)
    - the date of the claim                (date)
    */
      String repairShopID;
      String vehiclePolicyNumber;
      DateTime claimDate;
      double claimAmount;
      int numberOfClaimsBeingMade;

      /* 
      This variable will be used to maintain a count for the 
      number of claims that have been entered by the user
      */
      int numberOfClaimsEntered = 0;
      int maximumNumberOfClaims = 5;
      /* 
      Read the user input for the number of claims being made 
      and convert the string value to an integer data type
      */
      Console.WriteLine("How many claims are you wishing" +
        " to make?\n");
      numberOfClaimsBeingMade = Convert.ToInt32(Console.ReadLine());

      /*    
      Here we use the do iteration which means at least one 
      iteration will be performed. The do iteration uses a 
      Boolean test after iteration one to see if the number of 
      claims entered by the user so far is less than the number 
      of claims being made. If the comparison equates to true 
      then the do loop block of code is executed again. If the 
      comparison equates to false then the do loop block of 
      code is not executed. As we are using a variable in the
      loop our code is flexible and can be used for any 
      number of claims. An ideal situation and good code.
      */

      do
      {
        Console.WriteLine("The current value of the counter" +
          " is :" + numberOfClaimsEntered + "\n");

        /*
        We will use the if statement to perform a boolean 
        test and if the test produces a true value we will 
        break out of the loop. If the boolean test produces 
        a false value the loop simply continues executing the
        block of code
        */
        if (numberOfClaimsEntered == maximumNumberOfClaims)
        {
          /*
          We have reached the maximum number of claims allowed 
          in one session so we will break out of the loop early
          */
          break;
        }

        /* 
        We will use the if statement to perform a boolean test 
        and if the test produces a true value we will continue 
        with the loop but will skip out of this current 
        iteration. In this example we will check if the value 
        of the counter is even (when we divide by 2 the 
        remainder is 0). If it is an even number we will skip 
        the rest of this iteration by using the continue 
        statement. There is no else part to the if statement so 
        if the boolean test produces a false value the loop 
        carries on executing the block of code 
        */
        if (numberOfClaimsEntered % 2 == 0)
        {
          /*
          We have reached the maximum number of claims allowed 
          in one session so we will break out of the loop early.
          Increment the loop counter by 1 
          */
          numberOfClaimsEntered++;
          continue;
        }


        /* 
        Read the user input for the repair shop id and 
        keep it as a string 
        */
        Console.WriteLine("What is your repair shop id?\n");
        repairShopID = Console.ReadLine();

        /* 
        Read the user input for the vehicle policy number 
        and keep it as a string 
        */
        Console.WriteLine("What is the vehicle policy number?\n");
        vehiclePolicyNumber = Console.ReadLine();

        /* 
        Read the user input for the repair amount and 
        convert it to a double 
        */
        Console.WriteLine("What is the amount being " +
          "claimed for the repair?\n");
        claimAmount = Convert.ToDouble(Console.ReadLine());

        /* 
        Read the user input for the repair date and 
        convert it to a Date 
        */
        Console.WriteLine("What was the date of the repair?\n");
        claimDate = Convert.ToDateTime(Console.ReadLine());

        Console.WriteLine("The details entered for " +
"repair " + (numberOfClaimsEntered + 1) + " are");

        Console.WriteLine("Repair shop id:\t" + repairShopID);
        Console.WriteLine("Policy number:\t" + vehiclePolicyNumber);
        Console.WriteLine("Claim amount:\t" + claimAmount);
        Console.WriteLine("Claim date:\t" + claimDate);

        /* Increment the loop counter by 1 */
        numberOfClaimsEntered++;
      } while (numberOfClaimsEntered < numberOfClaimsBeingMade);


    } // End of Main() method

  } // End of DoWhileIteration class
} // End of Chapter10 namespace