﻿// Program:	A simple C# program to output text and read input
// Author:	Gerry Byrne
// Date of creation:	01/10/2023

using System;

/*
C# programming namespaces are commonly used in two ways:

1. C#, or more precisely .NET,  uses namespaces to organise the 
many classes it contains (remember classes contain methods and 
variables)
2. C# allows us as developers to create our own namespaces. 
We can use the namespace keyword to declare a namespace 
e.g. namespace Chapter5
A namespace can have the same name as the project but it can 
also be any name we wish. The name is independent of the 
Project name
*/

namespace Chapter6
{
  // This is our only class and it will contain the Main method
  public class Program
  {


    public static void Main(string[] args)
    {
      /*
      In this section we will add the variables we will use 
      throughout the program code. These are variables that are 
      going to be of a specific data type. Once we declare a 
      variable and have said what its data type is, we cannot 
      change the variables data type.

      The data type is immutable, it cannot be changed over time.
      First we will add a variable called vehicleManufacturer of
      data type string.
      */
      string vehicleManufacturer;
      string vehicleModel;
      string vehicleColour;
      int vehicleAgeInYears;
      double vehicleEstimatedCurrentPrice;
      int vehicleCurrentMileage;
      DateTime dateOfBirthOfMainDriver;

      Console.WriteLine();
      Console.WriteLine("---- Car Quotation Application ----");
      Console.WriteLine("\tCar\tInsurance\tApplication\n");
      Console.WriteLine();
      Console.WriteLine("Type the vehicle manufacturer");
      Console.WriteLine("and press the Enter key");
      Console.WriteLine();

      /*
      The next line of code tells the program to wait for the 
      user to input something. When the user presses the Enter 
      key this will indicate that the input has been completed.
      We have also said that we want the data entered at the 
      console to be assigned to the variable vehicleManufacturer 
      which we set up earlier with a data type of String. 
      We can now see that the data entered through the console
      is going to be held in the program as data type String. 
      */
      vehicleManufacturer = Console.ReadLine();

      Console.WriteLine();

      /* 
      The next line of code tells the program to display the text
      between the double quotes ''" and to add on to this text 
      (indicated by the +) the value of the variable called 
      vehicleManufacturer which has been assigned the value 
      typed in by the user at the console (Ford). The + means to 
      concatenate the text and the variable, in other words 
      join them
      */
      Console.WriteLine("Your car manufacturer is recorded as "
        + vehicleManufacturer);

      /* 
      In the next three lines we display a question for the user,
      read whatever data the user inputs at the console, assign 
      this data to the variable called vehicleModel and write 
      out the concatenated text  
      */
      Console.WriteLine("What is the model of the vehicle?\n");

      vehicleModel = Console.ReadLine();

      Console.WriteLine("You have told us that the vehicle " + 
        "model is " + vehicleModel);

      Console.WriteLine("What is the colour of the vehicle?\n");
      vehicleColour = Console.ReadLine();

      Console.WriteLine("You have told us that the vehicle " +
  "colour is " + vehicleColour);

      Console.WriteLine("What is the age, in full years, of " +
        "the vehicle? \n");
      vehicleAgeInYears = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("You have told us that the vehicle " +
  "age is " + vehicleAgeInYears);

      Console.WriteLine("What is the estimated current value " +
  "of the vehicle?\n");
      vehicleEstimatedCurrentPrice =
        Convert.ToDouble(Console.ReadLine());

      Console.WriteLine("You have told us that the estimated " +
  "vehicle price is £ " + vehicleEstimatedCurrentPrice);

      Console.WriteLine("What is the current mileage (in km) " +
        "of the vehicle?\n");
      vehicleCurrentMileage = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("You have told us that the vehicle " +
        "mileage is " + vehicleCurrentMileage + " km");

      Console.WriteLine("What is the date of birth " +
  "(dd/mm/yyyy) of the main driver of the vehicle?\n");

      dateOfBirthOfMainDriver =
        Convert.ToDateTime(Console.ReadLine());

      Console.WriteLine("You have told us that the main " +
  "driver was born on " + dateOfBirthOfMainDriver);

      Console.WriteLine("You have told us that the main " +
        "driver was born on "
        + dateOfBirthOfMainDriver.ToShortDateString());


    } // End of Main() method

  } // End of Program class
} // End of Chapter6 namespace