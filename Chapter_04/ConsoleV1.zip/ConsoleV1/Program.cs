﻿using System;

namespace ConsoleV1
{
  internal class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine();
      Console.WriteLine("------- Build your C# skills -------");
      Console.WriteLine("------- Learn To Code With C# -------");
      Console.WriteLine();
      Console.WriteLine("Press any keyboard letter to continue");

      Console.ReadLine();
      Console.WriteLine("Goodbye");
      Console.ReadLine();

    } // End of Main() method
  } // End of Program class
} // End of ConsoleV1 namespace