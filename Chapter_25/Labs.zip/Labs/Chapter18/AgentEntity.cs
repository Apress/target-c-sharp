﻿using System;

namespace Labs.Chapter18
{
  [Serializable]
  internal class AgentEntity 
  {
  /* 
  Members of the class are private as we have getters and 
  setters and we have two [NonSerialized] members as we do 
  not want them to be serialised 
  */
    private int agentNumber;
    private int agentYearsOfService;
    private String agentFullName;
    [NonSerialized] private String agentDOB;
    [NonSerialized] private double agentCapitalInvestment;

    public AgentEntity(int agentNumber, int agentYearsOfService, 
      string agentFullName, string agentDOB, 
      double agentCapitalInvestment)
    {
      this.agentNumber = agentNumber;
      this.agentYearsOfService = agentYearsOfService;
      this.agentFullName = agentFullName;
      this.agentDOB = agentDOB;
      this.agentCapitalInvestment = agentCapitalInvestment;
    } // End of AgentEntity constructor

    public int AgentNumber
    {
      get => agentNumber;
      set => agentNumber = value;
    }
    public int AgentYearsOfService
    {
      get => agentYearsOfService;
      set => agentYearsOfService = value;
    } // End of AgentYearsOfService property
    public string AgentFullName
    {
      get => agentFullName;
      set => agentFullName = value;
    } // End of AgentFullName property
    public string AgentDOB
    {
      get => agentDOB;
      set => agentDOB = value;
    } // End of AgentDOB property
    public double AgentCapitalInvestment
    {
      get => agentCapitalInvestment;
      set => agentCapitalInvestment = value;
    } // End of AgentCapitalInvestment property


  }// End of class AgentEntity
} // End of namespace Labs.Chapter18