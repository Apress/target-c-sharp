﻿using System;
using System.Runtime.Serialization.Formatters.Binary;

namespace Labs.Chapter18
{
  internal class AgentDeSerialization
  {
    static void Main(string[] args)
    {
      DeSerialiseTheAgentObject();
    } // End of Main() method

    static void DeSerialiseTheAgentObject()
    {
      AgentEntity myAgent = null;

      BinaryFormatter binaryFormatterForTheClass = 
        new BinaryFormatter();

      FileStream fileStreamToHoldTheData = 
        new FileStream("AgentSerializedData.ser",FileMode.Open,
        FileAccess.Read);

      try
      {
        using (fileStreamToHoldTheData)
        {
          myAgent = 
          (AgentEntity)binaryFormatterForTheClass.Deserialize(fileStreamToHoldTheData);

          Console.WriteLine("Agent Details");

          Console.WriteLine($"{"Agent No:",-25} " +
            $"{myAgent.AgentNumber,-10}");

          Console.WriteLine($"{"Years of service:",-25} " +
            $"{myAgent.AgentYearsOfService,-10}");

          Console.WriteLine($"{"Full Name:",-25} " +
            $"{myAgent.AgentFullName,-10}");

          Console.WriteLine($"{"DOB:",-25} {myAgent.AgentDOB,-10}");

          Console.WriteLine($"{"Capital Investment:",-25}" +
            $" {myAgent.AgentCapitalInvestment,-10}");
        }// End of the using block
      } // End of the try block
      catch
      {
        Console.WriteLine("Error creating the Agent from the serialised file");
      }// End of the catch block;

    } // End of DeSerialiseTheAgentObject() method

  } // End of class AgentDeSerialization
} // End of namespace Labs.Chapter18