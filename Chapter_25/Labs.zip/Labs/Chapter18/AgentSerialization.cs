﻿using System;
using System.Runtime.Serialization.Formatters.Binary;

namespace Labs.Chapter18
{
  internal class AgentSerialization
  {
    static void Main(string[] args)
    {
      SerializeTheAgentObject();
    } // End of Main() method

    static void SerializeTheAgentObject()
    {
      AgentEntity myAgentObject = 
      new AgentEntity(202391,25,"Gerry Byrne","01/01/1970",50000.00);

      BinaryFormatter formatterForTheClass = new BinaryFormatter();

      Stream streamToHoldTheData = 
        new FileStream("AgentSerializedData.ser",
        FileMode.Create, FileAccess.Write);

      formatterForTheClass.Serialize(streamToHoldTheData, myAgentObject);
      streamToHoldTheData.Close();
    } // End of SerialiseTheAgentObject() method

  } // End of class AgentSerialization
} // End of namespace Labs.Chapter18