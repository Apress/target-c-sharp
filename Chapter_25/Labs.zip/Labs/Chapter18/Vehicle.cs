﻿using System;

namespace Labs.Chapter18
{
  [Serializable]
  internal class Vehicle
  {
    // Members of the class.
    // [NonSerialized] members are not serialised    
    private string vehicleManufacturer;
    private string vehicleType;

    // Example for [NonSerialized]
    [NonSerialized] private String vehicleChasisNumber;

    public Vehicle(string vehicleManufacturer, string vehicleType, string vehicleChasisNumber)
    {
      this.vehicleManufacturer = vehicleManufacturer;
      this.vehicleType = vehicleType;
      this.vehicleChasisNumber = vehicleChasisNumber;
    } // End of constructor

    public string VehicleManufacturer
    {
      get => vehicleManufacturer;
      set => vehicleManufacturer = value;
    } // End of VehicleManufacturer property

    public string VehicleType
    {
      get => vehicleType;
      set => vehicleType = value;
    } // End of VehicleType property

    public string VehicleChasisNumber
    {
      get => vehicleChasisNumber;
      set => vehicleChasisNumber = value;
    } // End of VehicleChasisNumber property

  } // End of Vehicle class

} // End of namespace Labs.Chapter18