﻿using System;
using System.Runtime.Serialization.Formatters.Binary;

namespace Labs.Chapter18
{
  internal class VehicleSerialization
  {
    static void Main(string[] args)
    {
      SerializeTheVehicleObject();
      deSerializeTheVehicleObject();
    } // End of Main() method 

    static void SerializeTheVehicleObject()
    {
      Vehicle myVehicleObject = 
        new Vehicle("Ford", "Mondeo", "VIN 1234567890");

      BinaryFormatter formatterForTheClass = new BinaryFormatter();

      Stream streamToHoldTheData = 
        new FileStream("VehicleSerialisedData.ser",
        FileMode.Create, FileAccess.Write);

      formatterForTheClass.Serialize(streamToHoldTheData, myVehicleObject);
      streamToHoldTheData.Close();

    } // End of SerialiseTheVehicleObject() method

    static void deSerializeTheVehicleObject()
    {
      Vehicle myVehicle = null;

      BinaryFormatter binaryFormatterForTheClass = new BinaryFormatter();

      FileStream fileStreamToHoldTheData = 
        new FileStream("VehicleSerialisedData.ser",
        FileMode.Open, FileAccess.Read);

      try
      {
        using (fileStreamToHoldTheData)
        {
          myVehicle = 
          (Vehicle)binaryFormatterForTheClass.Deserialize(fileStreamToHoldTheData);

          Console.WriteLine("Vehicle Details");
          Console.WriteLine($"{"Vehicle Maufacturer:",-25} " +
            $"{ myVehicle.VehicleManufacturer,-10}");

          Console.WriteLine($"{"Vehicle Type:",-25} " +
            $"{myVehicle.VehicleType,-10}");

          Console.WriteLine($"{"Chasis No:",-25}" +
            $" {myVehicle.VehicleChasisNumber,-10}");

        }// End of the using block
      } // End of the try block
      catch
      {
       Console.WriteLine("Error creating Vehicle from serialised file");
      }// End of the catch block
    } // End of deSerialiseTheVehicleObject() method

  } // End of VehicleSerialization class

} // End of namespace Labs.Chapter18
