﻿using System;

namespace Labs.Chapter19
{
  internal class AutoInsurance
  {
    struct Vehicle
    {
      //Variables   
      string vehicleManufacturer;
      string vehicleChasisNumber;
      string vehicleColor;
      int vehicleEngineCapacity;

      // Custom constructor
      public Vehicle(string vehicleManufacturer,
        string vehicleChasisNumber, string vehicleColor,
        int vehicleEngineCapacity)
      {
        this.vehicleManufacturer = vehicleManufacturer;
        this.vehicleChasisNumber = vehicleChasisNumber;
        this.vehicleColor = vehicleColor;
        this.vehicleEngineCapacity = vehicleEngineCapacity;
      }

      //Properties for the struct variable - getters and setters
      public string VehicleManufacturer
      {
        get => vehicleManufacturer;
        set => vehicleManufacturer = value;
      }
      public string VehicleChasisNumber
      {
        get => vehicleChasisNumber;
        set => vehicleChasisNumber = value;
      }
      public string VehicleColor
      {
        get => vehicleColor;
        set => vehicleColor = value;
      }
      public int VehicleEngineCapacity
      {
        get => vehicleEngineCapacity;
        set => vehicleEngineCapacity = value;
      }

      // Methods of the struct
      public void DisplayManufacturerName()
      {
        Console.WriteLine($"The vehicle manufacturer is {vehicleManufacturer}");
      } // End of DisplayManufacturerName() method

      public void DisplayEngineCapacity()
      {
        Console.WriteLine($"The engine capacity is {vehicleEngineCapacity}");
      } // End of DisplayEngineCapacity() method

    } // End of the Vehicle struct

    // Main method code for the AutoInsurance class
    static void Main(string[] args)
    {
      Vehicle myVehicle =
        new Vehicle("Ford", "VIN 1234567890", "Blue", 1600);

      myVehicle.DisplayManufacturerName();
      myVehicle.DisplayEngineCapacity();
    } // End of Main() method

  } // End of class AutoInsurance
} // End of namespace Labs.Chapter19