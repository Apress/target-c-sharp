﻿using System;

namespace Labs.Chapter19
{
  internal class PropertyInsurance
  {
    public struct Apartment
    {
      int numberOfRooms;
      int floorArea;
      double estimatedValue;

      // Members are initialized using the constructor
      public Apartment(int numberOfRooms, int floorArea, 
        double estimatedValue)
      {
        this.numberOfRooms = numberOfRooms;
        this.floorArea = floorArea;
        this.estimatedValue = estimatedValue;
      } // End of the first constructor

      // A second constructor to initialize 1 member that has not
      // been given a value in this form of the constructor
      public Apartment(int numberOfRooms, int floorArea)
      {
        this.numberOfRooms = numberOfRooms;
        this.floorArea = floorArea;
        this.estimatedValue = 1000000.00;
      } // End of the second constructor

      public void DisplayValues()
      {
        Console.WriteLine($"The apartment has" +
          $" {this.numberOfRooms.ToString()} rooms");

        Console.WriteLine($"The floor area of the apartment " +
          $"is {this.floorArea.ToString()} square metres");

        Console.WriteLine($"The estimated value of the " +
          $"apartment is {this.estimatedValue.ToString()}");

        Console.WriteLine();
      } // End of the DisplayValues() method

    } // End of the struct Apartment

    static void Main(string[] args)
    {
      Apartment studioOne = new Apartment(2, 50, 120000.00);
      Apartment studioTwo = new Apartment(3, 60 );

      studioOne.DisplayValues();

      Console.WriteLine();
      Console.WriteLine("This apartment was not been given an " +
        "estimated value\n" +
        "so the constructor that has been used has set the \n" +
        "value as 1000000");
      Console.WriteLine();
      studioTwo.DisplayValues();
    }  // End of the Main() method

  } // End of the class PropertyInsurance
} // End of the namespace Labs.Chapter19