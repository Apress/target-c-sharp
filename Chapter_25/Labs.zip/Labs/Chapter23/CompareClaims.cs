﻿using System;
using System.Collections;

namespace Labs.Chapter23
{
  internal class CompareClaims
  {
    static void Main(string[] args)
    {
      ClaimLogic myCalculatorLogic = new ClaimLogic();

      myCalculatorLogic.createArrayListOfValues();

    } // End of Main() method 
  } // End of Calculator class

  public class ClaimLogic
  {

    public void createArrayListOfValues()
    {
      ArrayList repairClaimsAmounts = new ArrayList();
      repairClaimsAmounts.Add("POL1234");
      repairClaimsAmounts.Add(2000.99);
      repairClaimsAmounts.Add("POL1235");
      repairClaimsAmounts.Add(3000.01);
      repairClaimsAmounts.Add("POL1236");
      repairClaimsAmounts.Add(599.99);
      repairClaimsAmounts.Add("POL1237");
      repairClaimsAmounts.Add(399.01);
      repairClaimsAmounts.Add("POL1238");
      repairClaimsAmounts.Add(9000);
      repairClaimsAmounts.Add("POL1239");


      validateAndTotal(repairClaimsAmounts);
    }

    public void validateAndTotal(ArrayList repairClaimsAmounts)
    {
      double totalOfClaims = 0.00;
      int validClaims = 0, policyIds =0 ;

      for (int i = 0; i < repairClaimsAmounts.Count; i++)
      {
        if (Calculate(repairClaimsAmounts[i]))
        {
          totalOfClaims += Convert.ToDouble(repairClaimsAmounts[i]);
          validClaims++;
        } // End of the if selection construct
        else
        {
          policyIds++;
        }
      } // End of the for iteration construct

      Console.WriteLine($"There were {validClaims} claims");
      Console.WriteLine($"Claims total is {totalOfClaims}");
      Console.WriteLine($"There were {policyIds} policies");
    } // End of validateAndTotal() method


    //Now this method can accept any data type
    public static bool Calculate<T>(T value)
    {
      switch (value)
      {
        case int i:
          return true;

        case double d:
          return true;

        default:
          return false;
      }

    } // End of Calculate() method
  } // End of CalculatorLogic class

} // End of namespace Labs.Chapter23