﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labs.Chapter23
{
  internal class GenerateListsCopy
  {
    static List<string> passwordListOfStrings = new List<string>();
    static List<int> passwordListOfIntegers = new List<int>();
    public static void Main()
    {
      // Use the generic method.
      // ... Specifying the type parameter is optional here.
      // ... Then print the results.
      // List<string> passwordList;
      //List<T> passwordList = new List<T>;

      //for (int i = 0; i < 5; i++)
      //{
      //  passwordList.Add(GeneratePassword());
      //}

      // List<string> list2 = GetInitializedList<string>("Perls", 3);



      //foreach (string value in passwordList)
      //{
      //  Console.WriteLine(value);
      //}

     // GetInitializedList<string>(GenerateStrngPassword());


    } // End of Main() method


    static List<T> GetInitializedList<T>(T value)
    {
      // This generic method returns a List with ten elements initialized.
      // ... It uses a type parameter.
      // ... It uses the "open type" T.
      List<T> list = new List<T>();
      for (int i = 0; i < 3; i++)
      {
        //list.Add(GenerateStrngPassword());
      }
      return list;
    }



    public static List<string> GeneratePassword<T>()
      {
      // Creating an instance of the Random class
      Random myInstanceOfRandomClass = new Random();

      int randValue;
      string theGeneratedPassword = "";
      char singleLetterOfPassword;

      // Generating the size of password from 8 to 15
      int myRandomPasswordLength = 
        myInstanceOfRandomClass.Next(8, 16);

      for (int i = 0; i < myRandomPasswordLength; i++)
      {
        // Generating a random number including 0 not 26
        randValue = myInstanceOfRandomClass.Next(0, 26);

        // Generating random character by converting
        // the random number into character.
        singleLetterOfPassword = Convert.ToChar(randValue + 65);

        // Appending the letter to string.
        theGeneratedPassword = theGeneratedPassword + singleLetterOfPassword;
      }
      Console.Write("Random String:" + theGeneratedPassword);

      
      passwordListOfStrings.Add(theGeneratedPassword);

      return passwordListOfStrings;
    } // End of GeneratePassword()t method

  } // End of class GenerateLists




} // End of namespace Labs.Chapter23