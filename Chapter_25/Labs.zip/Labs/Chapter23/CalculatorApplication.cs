﻿using System;

namespace Labs.Chapter23
{
  internal class CalculatorApplication
  {
    static void Main(string[] args)
    {
      Calculator<int> integerCalculator = new Calculator<int>();
      Console.WriteLine($"Using integers: " +
        $"{integerCalculator.AddTwoValues(80, 20)}");


      Calculator<string> stringCalculator = new Calculator<string>();
      Console.WriteLine($"Using strings: " +
        $"{stringCalculator.AddTwoValues("Gerry", "Byrne")}");

      Calculator<float> floatCalculator = new Calculator<float>();
      Console.WriteLine($"Using floats: " +
        $"{floatCalculator.AddTwoValues(3.5F, 100.0F)}");

      Calculator<double> doubleCalculator = new Calculator<double>();
      Console.WriteLine($"Using doubles: " +
        $"{doubleCalculator.AddTwoValues(8.99, 1.02)}");

    } // End of Main() method
  } // End of CalculatorApplication class


  // Create a generic class
  public class Calculator<T>   
  {
    public T answer; 
    public T AddTwoValues(T valueOne, T valueTwo) 
    {
      /*
      In C# we have a dynamic type which is used avoid 
      compile-time type checking of the variable. 
      Instead the compiler gets the type at the run time and 
      this suits this example well as we are using generic types.
      */
      dynamic numberOne = valueOne;
      dynamic numberTwo = valueTwo;

      answer = numberOne + numberTwo;
      return answer;
    } //End of AddTwoValues() method
  } // End of Calculator class

} // End of namespace Labs.Chapter23