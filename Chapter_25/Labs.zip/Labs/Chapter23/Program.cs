﻿using System;

namespace Labs.Chapter23
{
  public class DisplayClass<T>
  {
    public void DisplayMethod(T passwordGenerated)
    {
      Console.WriteLine(passwordGenerated);
    }
  }

  public class Program
  {
    public static void Main(string[] args)
    {
      Console.WriteLine("How many passwords are required?");
      int numberOfPasswords = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("Do you want strings or integers?");
      Console.WriteLine("Type s for strings?");
      Console.WriteLine("Type i for integers?");

      string typeOfPassword = Console.ReadLine();

      switch (typeOfPassword.ToUpper())
      {
        case "S":
          Console.WriteLine("Printing String Password");
          GenerateStringPassword(numberOfPasswords);
          break;
        case "I":
          Console.WriteLine("Printing Integer Password");
          GenerateIntegerPassword(numberOfPasswords);
          break;
      } // End of switch construct

    } // End of Main() method

    public static void GenerateStringPassword(int numberOfPasswords)
    {
      DisplayClass<string> gen = new DisplayClass<string>();

      for (int counter = 0; counter < numberOfPasswords; counter++)
      {
        // Creating an instance of the Random class
        Random myInstanceOfRandomClass = new Random();

        int randValue;
        string theGeneratedPassword = "";
        char singleLetterOfPassword;

        // Generating the size of password from 8 to 15
        int myRandomPasswordLength =
          myInstanceOfRandomClass.Next(8, 16);

        for (int i = 0; i < myRandomPasswordLength; i++)
        {
          // Generating a random number including 0 not 26
          randValue = myInstanceOfRandomClass.Next(0, 26);

          // Generating random character by converting
          // the random number into character.
          singleLetterOfPassword = Convert.ToChar(randValue + 65);

          // Appending the letter to string.
          theGeneratedPassword = theGeneratedPassword + singleLetterOfPassword;
        }
        Console.Write($"Random string passsword of length " +
          $"{myRandomPasswordLength} is: {theGeneratedPassword}");

     gen.DisplayMethod(theGeneratedPassword);
      }
    } // End of GenerateStringPassword() method

    public static void GenerateIntegerPassword(int numberOfPasswords)
    {
      DisplayClass<long> gen = new DisplayClass<long>();

      for (int counter = 0; counter < numberOfPasswords; counter++)
      {
        // Creating an instance of the Random class
        Random myInstanceOfRandomClass = new Random();

        long randValue;
        string theGeneratedPassword = "";
        char singleDigitOfPassword;

        // Generating the size of password from 8 to 15
        int myRandomPasswordLength =
          myInstanceOfRandomClass.Next(8, 16);

        for (int i = 0; i < myRandomPasswordLength; i++)
        {
          // Generating a random number including 0 not 10
          randValue = myInstanceOfRandomClass.Next(0, 10);

          // Generating random character by converting
          // the random number into character.
          singleDigitOfPassword = Convert.ToChar(randValue + 48);

          // Appending the letter to string.
          theGeneratedPassword = theGeneratedPassword + singleDigitOfPassword;
        } // End of for iteration re number of characters

        Console.Write($"Random integer passsword of length" +
          $" {myRandomPasswordLength} is: {theGeneratedPassword}");
      
        gen.DisplayMethod(long.Parse(theGeneratedPassword));

      } // End of for iteration re number of passwords

    } // End ofGenerateIntegerPassword() method
  } // End of namespace Labs.Chapter23

} // End of GenerateIntegerPassword() method




