﻿using System;

namespace Labs.Chapter09
{
  internal class Lab2
  {
    static void Main(string[] args)
    {
      String grade = null;
      Console.WriteLine("Enter the examination mark: ");
      int mark = Convert.ToInt32(Console.ReadLine());

      if (mark > 0 && mark <= 100)
      {
        if (mark >= 90)
        {
          grade = "Distinction";
        }
        else if (mark >= 75)
        {
          grade = "pass";
        }
        else
        {
          grade = "unsuccessful";
        }
        Console.WriteLine($"{mark} marks is a {grade} grade ");
      }
      else
      {
        Console.WriteLine("Mark must be between 1 and 100");
      }

    } // End of Main() method    
  } // End of Lab2 class
} //End of Labs.Chapter09 namespace 