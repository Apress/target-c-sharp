﻿using System;

namespace Labs.Chapter09
{
  internal class Lab1
  {
    static void Main(string[] args)
    {
      int month, daysInMonth = 0;
      Console.WriteLine("Enter the numeric number of the month");
      month = Convert.ToInt32(Console.ReadLine());
      switch (month)
      {
        case 1:
        case 3:
        case 5:
        case 7:
        case 8:
        case 10:
        case 12:
          daysInMonth = 31;
          break;
        case 4:
        case 6:
        case 9:
        case 11:
          daysInMonth = 30;
          break;
        case 2:
          daysInMonth = 28;
          break;
        default:
          Console.WriteLine("Invalid month!");
          break;
      }
      Console.WriteLine($"Month {month} has {daysInMonth} days");

    } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter09 namespace 