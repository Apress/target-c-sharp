﻿using System;

namespace Labs.Chapter09
{
  internal class Lab3
  {
    static void Main(string[] args)
    {
      String userInputLanguage = null;

      Console.WriteLine("Enter the programming language: ");
      userInputLanguage = Console.ReadLine();

      if (userInputLanguage.Equals("C#"))
      {
        Console.WriteLine("C# is a modern, object-oriented, and"
        + "\n" + "type-safe programming language. C# enables "
        + "\n" + "developers to build many types of application"
        + "\n" + "that run in the .NET ecosystem.");
      }
      else if (userInputLanguage.Equals("Java"))
      {
        Console.WriteLine("Java is a programming language"
                + "\n" + "released by Sun Microsystems in 1995."
                + "\n" + "There are lots of applications and "
                + "\n" + "websites that will not work unless"
                + "\n" + "Java is installed");

      }
      else if (userInputLanguage.Equals("Python"))
      {
        Console.WriteLine("Python is an interpreted and "
                + "\n" + "object-oriented programming language");
      }
      else
      {
      Console.WriteLine("Sorry, this is not one of our languages");
      }
      } // End of Main() method    
    } // End of Lab3 class
} //End of Labs.Chapter09 namespace