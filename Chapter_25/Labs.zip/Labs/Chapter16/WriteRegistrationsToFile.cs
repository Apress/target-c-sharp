﻿using System;

namespace Labs.Chapter16
{
  internal class WriteRegistrationsToFile
  {
    static string vehicleRegistration;

    // Assign the name of the file to be used to a variable.
    static string filePath = "vehicleregistrations.txt";

    static void Main(string[] args)
    {
      /*
      Create a loop to iterate 5 times asking the user
      to input a vehicle registration each time.
      */
      for (int counter = 1; counter < 6; counter++)
      {
       Console.WriteLine($"Enter registration number {counter}");
       vehicleRegistration = Console.ReadLine();

       WriteRegistrationToTextFile(vehicleRegistration);
      } // Enter of iteration

    }  // End of Main() method  

    public static void WriteRegistrationToTextFile(String vehicleRegistration)
    {
      // Enclose the code in a try catch to handle errors
      try
      {
        // Create a FileStream with mode CreateNew  
        FileStream stream = new FileStream(filePath, FileMode.Append);

        // Create a StreamWriter from FileStream  
        using (StreamWriter writer = new StreamWriter(stream))
        {
          writer.WriteLine(vehicleRegistration);
        }
      } // End of try block
      catch (Exception ex)
      {
        Console.WriteLine($"Error writing file {filePath}" +
          $" error was {ex}");
      } // End of the catch section of the error handling  
    } // End of the writeRegistrationToTextFile() method  

  } // End of WriteRegistrationsToFile class
} //End of Labs.Chapter16 namespace 