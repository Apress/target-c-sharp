﻿using System;

namespace Labs.Chapter16
{
  internal class ReadRegistrationsFromFile
  {
    // Assign the name of the file to be used to a variable.
    static string filePath = "vehicleregistrations.txt";

    // Declare and create an array to hold the 5 registrations
    static string[] vehicleRegistrations = new string[5];

    static void Main(string[] args)
    {
      readRegistrationFromTextFile();
      displayArrayItems();
    }// End of Main() method 

    public static void readRegistrationFromTextFile()
    {
      // Set up a string variable to hold the lines read
      string line = null;
      int lineCountValue = 0;

      // Create a StreamReader from a FileStream  
      using (StreamReader reader = 
        new StreamReader(new FileStream(filePath,FileMode.Open)))
      {
        // Read line by line  
        while ((line = reader.ReadLine()) != null)
        {
          vehicleRegistrations[lineCountValue] = line;
          lineCountValue++;
        }
      } // End of using block
    } // End of the readRegistrationFromTextFile() method  

    public static void displayArrayItems()
    {
      // Iterate the sorted array using the foreach construct
      foreach (string vehicleRegistrations in vehicleRegistrations)
      {
        Console.WriteLine(vehicleRegistrations);
      }
    } // End of displayArrayItems() method

  } // End of ReadRegistrationsFromFile class
} //End of Labs.Chapter16 namespace 