﻿using System;

namespace Labs.Chapter14
{
  internal interface ICustomerAccount
  {
    void AddFunds(double amountIn, DateTime transactionDate);
    void WithdrawFunds(double amountOut, DateTime transactionDate);
  } // End of interface ICustomerAccount

} // End of namespace Labs.Chapter14