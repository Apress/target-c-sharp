﻿using System;

namespace Labs.Chapter14
{
  internal class CustomerAccount : ICustomerAccount
  {
    string customerName;
    double currentBalance;
    public void AddFunds(double amountIn, DateTime transactionDate)
    {
      currentBalance += amountIn;
    } // End of AddFunds() method

    public void WithdrawFunds(double amountOut, DateTime transactionDate)
    {
      currentBalance -= amountOut;
    } // End of WithdrawFunds() method

    public void OpenAccount(string customerName, double openingBalance)
    {
      this.customerName = customerName;
      this.currentBalance = openingBalance;
    } // End of OpenAccount() method

    public void DisplayAccountDetails()
    {
      Console.WriteLine($"{"Customer name is:",-25} {customerName,-20}");
      Console.WriteLine($"{"Account balance is:",-25} {currentBalance,-20}");
    }
  } // End of class CustomerAccount

} // End of namespace Labs.Chapter14
