﻿using System;

namespace Labs.Chapter14
{
  internal interface IVehicleInsuranceQuote
  {
    void AskForDriverAge();
    void AskForVehicleValue();
    double CalculateQuote(int ageOfDriver, double vehicleValue);
  } // End of interface IVehicleInsuranceQuote

} // End of namespace Labs.Chapter14