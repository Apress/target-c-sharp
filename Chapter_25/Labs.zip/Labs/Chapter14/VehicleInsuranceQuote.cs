﻿using System;

namespace Labs.Chapter14
{
  internal class VehicleInsuranceQuote : IVehicleInsuranceQuote
  {
    public int ageOfDriver;
    public double vehicleValue;
    public double monthlyPremium;

    public void AskForDriverAge()
    {
      Console.WriteLine("What is the age of the driver?");
      ageOfDriver = Convert.ToInt32(Console.ReadLine());
    } // End of AskForDriverAge() method

    public void AskForVehicleValue()
    {
      Console.WriteLine("What is the value of the vehicle?");
      vehicleValue = Convert.ToDouble(Console.ReadLine());
    } // End of AskForVehicleValue() method

    public double CalculateQuote(int ageOfDriver, double vehicleValue)
    {
     monthlyPremium = (60 / ageOfDriver) * (vehicleValue / 5000) * 10;

      return monthlyPremium;
    } // End of CalculateQuote() method

    public void DisplayQuote()
    {
      Console.WriteLine($"{"Driver age is:",-20} {ageOfDriver, -20}");
      Console.WriteLine($"{"Vehicle value is:",-20} {vehicleValue,-20}");
      Console.WriteLine($"{"Monthly premium is:",-20} {monthlyPremium,-20}");
    }
  } // End of class VehicleInsuranceQuote
} // End of namespace Labs.Chapter14
