﻿using System;

namespace Labs.Chapter14
{
  internal class QuoteCalculator
  {
    static void Main(string[] args)
    {
      VehicleInsuranceQuote myQuote = new VehicleInsuranceQuote();

      myQuote.AskForDriverAge();
      myQuote.AskForVehicleValue();

      myQuote.CalculateQuote(myQuote.ageOfDriver, myQuote.vehicleValue);
      myQuote.DisplayQuote();

    }// End of Main() method
  } // End of class QuoteCalculator
} // End of namespace Labs.Chapter14