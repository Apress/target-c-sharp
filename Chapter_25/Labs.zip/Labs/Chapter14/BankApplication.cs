﻿using System;

namespace Labs.Chapter14
{
  internal class BankApplication
  {
    static void Main(string[] args)
    {
      CustomerAccount myAccount = new CustomerAccount();

      myAccount.OpenAccount("Gerry Byrne", 1000);

      DateTime transactionDate = new DateTime(2023, 12, 1);
      myAccount.AddFunds(100, transactionDate);

      myAccount.WithdrawFunds(600, transactionDate);

      myAccount.DisplayAccountDetails();
    } // End of Main() method 

  } // End of class BankApplication

} // End of namespace Labs.Chapter14
