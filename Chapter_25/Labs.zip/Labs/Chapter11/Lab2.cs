﻿using System;

namespace Labs.Chapter11
{
  internal class Lab2
  {
    static void Main(string[] args)
    {
      String[] EmployeeNames = new string[4];

      for (int employeenumber = 0; employeenumber < 4; employeenumber++)
      {
        // Ask the user to input the employee name
        Console.WriteLine($"What is the name of employee" +
          $" {employeenumber + 1}? ");

        EmployeeNames[employeenumber] = Console.ReadLine();
      }

      foreach (String name in EmployeeNames)
      {
        Console.WriteLine(name);
      }

    } // End of Main() method    
  } // End of Lab2 class
} //End of Labs.Chapter11 namespace 