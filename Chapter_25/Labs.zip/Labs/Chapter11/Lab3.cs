﻿using System;

namespace Labs.Chapter11
{
  internal class Lab3
  {
    static void Main(string[] args)
    {
      // Declare and initialise the array of employees and salary
      String[] employeeAndSalary = { "Gerry Byrne", "20000.00", 
        "Peter Johnston", "30000.00", "Ryan Jones", "50000.00" };

      // Declare an array of employees and their new salary
      String[] employeeAndSalaryWithIncrease = 
        new String[employeeAndSalary.Length];

      // Iterate the array and find every 2nd value, the salary
      for (int counter = 0; counter < employeeAndSalary.Length; counter += 2)
      {
        employeeAndSalaryWithIncrease[counter] = 
          employeeAndSalary[counter];

        // Create a variable of type Double (wrapper class)
        Double newSalary = 
        Convert.ToDouble(employeeAndSalary[counter + 1]) * 1.10;

        // Write the employee name to the new array
        employeeAndSalaryWithIncrease[counter] = 
          employeeAndSalary[counter];

        // Write the Double to the array converting it to String
        employeeAndSalaryWithIncrease[counter + 1] =
          newSalary.ToString("#.00");
      } // End of for block

      Console.WriteLine($"{"Employee name",-20} " +
        $"{"New Salary",-15}\n");

      // Compare all the other numbers to the maximum
      for (int counter = 0; counter < employeeAndSalaryWithIncrease.Length; counter += 2)
      {
        // Display the Employee name and their new salary
        Console.WriteLine($"" +
          $"{employeeAndSalaryWithIncrease[counter],-15} " +
          $"{employeeAndSalaryWithIncrease[counter + 1],15}");
      } // End of for block

    } // End of Main() method    
  } // End of Lab3 class
} //End of Labs.Chapter11 namespace 