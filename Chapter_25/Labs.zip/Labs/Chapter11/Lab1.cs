﻿using System;

namespace Labs.Chapter11
{
  internal class Lab1
  {
    static void Main(string[] args)
    {
      // Declare the variables to be used 
      double maximumValueOfClaims, minimumValueOfClaims;
      double totalValueOfClaims, averageValueOfClaims;

      // Declare and initialise the array of claim values
      double[] claimValues = {1000.00, 4000.00, 3000.00, 2000.00};

      /* Set up a variable for the total of the claim values
         and initialise its value to 0; */
      totalValueOfClaims = 0;

      // Iterate the array and accumulate the claim values
      for (int counter = 0; counter < claimValues.Length; counter++)
      {
       totalValueOfClaims = totalValueOfClaims + claimValues[counter];
      } // End of for block

      // Calculate the average using real arithmetic
      averageValueOfClaims = totalValueOfClaims / claimValues.Length;

      // Display the total and average 
      Console.WriteLine($"The total of the claims is " +
        $"£{totalValueOfClaims:0.00}\n");

      Console.WriteLine($"The average claim value is" +
        $" £{averageValueOfClaims:0.00}\n");

      // Find the maximum value - we assume first value
      // is the maximum value
      maximumValueOfClaims = claimValues[0];

      // Compare all the other numbers to the maximum
      for (int counter = 1; counter < claimValues.Length; counter++)
      {
        // If the next number is greater than the maximum,
        // update the maximum
        if (claimValues[counter] > maximumValueOfClaims)
        {
          maximumValueOfClaims = claimValues[counter];
        }
      } // End of for block

      // Display the maximum claim value
      Console.WriteLine($"The maximum claim value is " +
        $"£{maximumValueOfClaims:0.00}\n");

      // Find the minimum value- we assume the first number
      // is the minimum value
       minimumValueOfClaims = claimValues[0];

      // Compare all the other numbers to the minimum
      for (int counter = 1; counter < claimValues.Length; counter++)
      {
        // If the next number is smaller than the minimum,
        // update the minimum 
        if (claimValues[counter] < minimumValueOfClaims)
        {
          minimumValueOfClaims = claimValues[counter];
        }
      } // End of for block

      // Display the minimum claim value
      Console.WriteLine($"The minimum claim value is " +
        $"£{minimumValueOfClaims:0.00}\n");

    } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter11 namespace 