﻿using System;

namespace Labs.Chapter13
{
  internal class CalculatedValues
  {
    // Declare and initialise the array of claim
    // values at the class level
    static double[] claimValues = {1000.00,4000.00,3000.00,2000.00};

    /*****************************************************
     CREATE THE METHODS OUTSIDE THE MAIN METHOD 
     BUT INSIDE THE CLASS
     *****************************************************/
    public double totalOfClaimValues()
    {
      double totalOfClaims = 0.00;
      // Iterate the array and accumulate the claim values
      for (int counter = 0; counter < claimValues.Length; counter++)
      {
        totalOfClaims = totalOfClaims + claimValues[counter];
      }
      return totalOfClaims;
    } // End of totalOfClaimValues() method

    public double averageOfClaimValues()
    {
      double averageOfClaims = 0.00;
      // Calculate the average using real arithmetic
      averageOfClaims = totalOfClaimValues() / claimValues.Length;
      return averageOfClaims;
    }

    public double maximumClaimValue()
    {
      // Find the maximum value - we assume first
      // value is the maximum value
      double maximumOfClaims = claimValues[0];

      // Compare all the other numbers to the maximum
      for (int counter = 1; counter < claimValues.Length; counter++)
      {
        // If the next number is greater than the maximum,
        // update the maximum
        if (claimValues[counter] > maximumOfClaims)
        {
          maximumOfClaims = claimValues[counter];
        }
      }
      return maximumOfClaims;
    } // End of maximumClaimValue() method

    public double minimumClaimValue()
    {
      // Find the minimum value- we assume the first number
      // is the minimum value
      double minimumOfClaims = claimValues[0];

      // Compare all the other numbers to the minimum
      for (int counter = 1; counter < claimValues.Length; counter++)
      {
        // If the next number is smaller than the minimum,
        // update the minimum 
        if (claimValues[counter] < minimumOfClaims)
        {
          minimumOfClaims = claimValues[counter];
        }
      }
      return minimumOfClaims;
    } // End of minimumClaimValue() method 

    public void displayTheCalculatedValues(
      double totalValueOfClaimsPassedIn, 
      double averageValueOfClaimsPassedIn, 
      double maximumValueOfClaimsPassedIn, 
      double minimumValueOfClaimsPassedIn)
    {
      // Display the total of the claim values
      Console.WriteLine($"The total of the claims is" +
        $" £{totalValueOfClaimsPassedIn:0.00}\n");

      // Display the average of the claim values
      Console.WriteLine($"The average claim value is " +
        $"£{ averageValueOfClaimsPassedIn:0.00}\n");

            // Display the maximum claim value
            Console.WriteLine($"The maximum claim value is " +
              $"£{ maximumValueOfClaimsPassedIn:0.00}\n");

            // Display the minimum claim value
            Console.WriteLine($"The minimum claim value is " +
              $"£{ minimumValueOfClaimsPassedIn:0.00}\n");
        }  // End of displayTheCalculatedValues() method 

  } // End of CalculatedValues class
} //End of Labs.Chapter13 namespace 