﻿using System;

namespace Labs.Chapter13
{
  internal class QuoteMethodsClass
  {
    string customerName;
    int ageOfVehicle;
    double engineCapacity,quoteAmount;

    public void AcceptUserName()
    {
      Console.WriteLine("What is the name of the customer?");
      customerName = Console.ReadLine();
    } // End of AcceptUserName() method

    public void AcceptAgeOfVehicle()
    {
      Console.WriteLine("What is the age of the vehicle?");
      ageOfVehicle = Convert.ToInt32(Console.ReadLine());
    } // End of AcceptAgeOfVehicle() method

    public void AcceptEngineCapacityOfVehicle()
    {
      Console.WriteLine("What is the engine capacity?");
      engineCapacity = Convert.ToInt32(Console.ReadLine());
    } // End of AcceptEngineCapacityOfVehicle() method


    public void CalculateQuoteAmount()
    {
     quoteAmount = 100 * (engineCapacity/1000) * (10/ageOfVehicle);
    } // End of CalculateQuoteAmount() method


    public void DisplayQuote()
    {
      Console.WriteLine($"The vehicle to be insured for " +
        $"customer {customerName:0.00} is {ageOfVehicle} " +
        $"years old and has an engine capacity of" +
        $" {engineCapacity}");
      
      Console.WriteLine($"The quote estimate is" +
        $" £{quoteAmount:0.00}");
    } // End of DisplayQuote() method

  } //End of class QuoteMethodsClass
} // End of namespace Labs.Chapter13