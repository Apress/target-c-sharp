﻿using System;

namespace Labs.Chapter13
{
  internal class QuoteCalculatorClass
  {
    static void Main(string[] args)
    {
      QuoteMethodsClass myQuote = new QuoteMethodsClass();

      myQuote.AcceptUserName();
      myQuote.AcceptAgeOfVehicle();
      myQuote.AcceptEngineCapacityOfVehicle();
      myQuote.CalculateQuoteAmount();
      myQuote.DisplayQuote();
    } // End of Main() method    

  } //End of class QuoteCalculatorClass
} // End of namespace Labs.Chapter13