﻿using System;

namespace Labs.Chapter13
{
  internal class ClaimCalculator
  {
    static void Main(string[] args)
    {
    /* 
    Set up the variables at the class level.   
    */
      double maximumValueOfClaims, minimumValueOfClaims;
      double totalValueOfClaims, averageValueOfClaims;

      // Instantiate the CalculatedValues class
      CalculatedValues myCalculatedValues = new CalculatedValues();

      // Call each method and assign each to a value
      totalValueOfClaims = myCalculatedValues.totalOfClaimValues();
      averageValueOfClaims = myCalculatedValues.averageOfClaimValues();
      maximumValueOfClaims = myCalculatedValues.maximumClaimValue();
      minimumValueOfClaims = myCalculatedValues.minimumClaimValue();

      // Pass each value to the display method
      myCalculatedValues.displayTheCalculatedValues(
        totalValueOfClaims, averageValueOfClaims, 
        maximumValueOfClaims, minimumValueOfClaims);


    } // End of Main() method    
  } // End of ClaimCalculator class
} //End of Labs.Chapter13 namespace 