﻿using System;

namespace Labs.Chapter04
{
  internal class Lab1
  {
    static void Main(string[] args)
    {
      Console.WriteLine("*******");
      Console.WriteLine("*");
      Console.WriteLine("*");
      Console.WriteLine("*******");
      Console.WriteLine("*");
      Console.WriteLine("*");
      Console.WriteLine("*******");

    } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter04 namespace 