﻿using System;

namespace Labs.Chapter04
{
  internal class Lab4
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Mr Gerard Byrne");
      Console.Write("Press any key to continue");
      Console.ReadLine();
      Console.WriteLine("1 Any Street");
      Console.Write("Press any key to continue");
      Console.ReadLine();
      Console.WriteLine("Any Road");
      Console.Write("Press any key to continue");
      Console.ReadLine();
      Console.WriteLine("Belfast");
      Console.Write("Press any key to continue");
      Console.ReadLine();
      Console.WriteLine("BT1 1AN");

    } // End of Main() method    
  } // End of Lab4 class
} //End of Labs.Chapter04 namespace