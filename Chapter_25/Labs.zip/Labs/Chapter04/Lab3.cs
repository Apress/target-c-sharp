﻿using System;

namespace Labs.Chapter04
{
  internal class Lab3
  {
    static void Main(string[] args)
    {
      Console.WriteLine("Mr Gerard Byrne");
      Console.WriteLine("1 Any Street");
      Console.WriteLine("Any Road");
      Console.WriteLine("Belfast");
      Console.WriteLine("BT1 1AN");

    } // End of Main() method    
  } // End of Lab3 class
} //End of Labs.Chapter04 namespace 