﻿using System;

namespace Labs.Chapter04
{
  internal class Lab2
  {
    static void Main(string[] args)
    {
      Console.WriteLine("      *");
      Console.WriteLine("     * *");
      Console.WriteLine("    *   *");
      Console.WriteLine("   *******");
      Console.WriteLine("  *       *");
      Console.WriteLine(" *         *");
      Console.WriteLine("*           *");

    } // End of Main() method    
  } // End of Lab2 class
} //End of Labs.Chapter04 namespace 