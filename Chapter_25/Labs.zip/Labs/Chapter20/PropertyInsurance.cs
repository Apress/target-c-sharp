﻿using System;

namespace Labs.Chapter20
{
  internal class PropertyInsurance
  {
    public enum InsuranceRiskEnum
    {
      Low = 1,
      Medium = 10,
      High = 20,
    }

    public enum LocationFactorEnum
    {
      NotNearRiver = 1,
      NearRiver = 10,
    }

    public enum PropertyTypeEnum
    {
      Bungalow,
      House,
      Apartment
    }
    static void Main(string[] args)
    {
      int propertyType = AskForPropertyType();
      string isNearARiver = AskForPropertyLocation();
      double estimatedValue = AskForPropertyValue();

      QuoteAmount(propertyType, isNearARiver, estimatedValue);
    } // End of Main() method


    public static int AskForPropertyType()
    {
      Console.WriteLine("What is the property type, 1 2 or 3?");
      Console.WriteLine("1. Bungalow ");
      Console.WriteLine("2. House");
      Console.WriteLine("3. Apartment");
      int  propertyType = Convert.ToInt32(Console.ReadLine());
      return propertyType;
    } // End of PropertyType() method

    public static string AskForPropertyLocation()
    {
      Console.WriteLine("Is the property within 50 metres " +
        "of a river?");

      string nearARiver = Console.ReadLine();
      return nearARiver;
    } // End of PropertyLocation() method

    public static double AskForPropertyValue()
    {
      Console.WriteLine("What is the estimated value of " +
        "the property?");

      double estimatedValue = Convert.ToDouble(Console.ReadLine());
      return estimatedValue;
    } // End of PropertyValue() method

    public static void QuoteAmount(int propertyType, 
      string isPropertyNearARiver, double propertyValue)
    {
      int propertyTypeRiskFactor, locationFactor;
      switch (propertyType)
      {
        case 1:
          propertyTypeRiskFactor = (int)InsuranceRiskEnum.High;
          break;
        case 2:
          propertyTypeRiskFactor = (int)InsuranceRiskEnum.Medium;
          break;
        case 3:
          propertyTypeRiskFactor = (int)InsuranceRiskEnum.Low;
          break;
        default:
          propertyTypeRiskFactor = 9999;
          break;
      }

      if (isPropertyNearARiver.Equals("Y"))
      {
        locationFactor = (int)LocationFactorEnum.NearRiver;
      }
      else
      {
        locationFactor = (int)LocationFactorEnum.NotNearRiver;
      }

      double quoteAmount = (propertyTypeRiskFactor 
           * (propertyValue / 10000) * locationFactor);

      DisplayQuote(propertyType, isPropertyNearARiver,
        propertyValue, quoteAmount);
    } // End of QuoteAmount() method

    public static void DisplayQuote(int propertyType,
      string isPropertyNearARiver, double propertyValue,
      double quoteAmount)
    {
      if (isPropertyNearARiver.Equals("Y"))
      {
        isPropertyNearARiver = "Yes";
      }
      else
      {
        isPropertyNearARiver = "No";
      }
      Console.WriteLine("Quote Details");
      Console.WriteLine($"{"Property Type is:", -30} " +
        $"{Enum.GetName(typeof(PropertyTypeEnum),propertyType-1), -20}");

      Console.WriteLine($"{"Property Near River:",-30} " +
        $"{isPropertyNearARiver,-20}");

      Console.WriteLine($"{"Property Value is:",-30} " +
        $"{propertyValue,-20}");

      Console.WriteLine();
      Console.WriteLine($"{"Quote amount is:",-30} " +
        $"{quoteAmount,-20}");

    } // End of DisplayQuote() method

  } // End of class PropertyInsurance
} // End of namespace Labs.Chapter20
