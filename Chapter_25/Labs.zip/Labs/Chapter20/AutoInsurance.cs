﻿using System;

namespace Labs.Chapter20
{
  internal class AutoInsurance
  {
    public enum Manufacturer
    {
      Ford,
      Chevrolet,
      Jeep,
      Honda
    }

    public enum Color
    {
      Red,
      Blue,
      Green
    }

    struct Vehicle
    {
      //Variables   
      Manufacturer vehicleManufacturer;
      Color vehicleColor;

      // Custom constructor
      public Vehicle(Manufacturer vehicleManufacturer, Color vehicleColor)
      {
        this.vehicleManufacturer = vehicleManufacturer;
        this.vehicleColor = vehicleColor;
      }

      // Methods of the struct
      public void DisplayVehiclerDetails()
      {
        Console.WriteLine($"The vehicle manufacturer is {vehicleManufacturer}");
        Console.WriteLine($"The vehicle color is {vehicleColor}");
      } // End of DisplayVehiclerDetails() method

    } // End of the Vehicle struct

    // Main method code for the AutoInsurance class
    static void Main(string[] args)
    {
      Vehicle myVehicleOne =
        new Vehicle(Manufacturer.Ford,Color.Blue);

      myVehicleOne.DisplayVehiclerDetails();

      Console.WriteLine();
      Vehicle myVehicleTwo = 
        new Vehicle(Manufacturer.Jeep, Color.Green);

      myVehicleTwo.DisplayVehiclerDetails();
    } // End of Main() method

  } // End of class AutoInsurance
} // End of namespace Labs.Chapter20