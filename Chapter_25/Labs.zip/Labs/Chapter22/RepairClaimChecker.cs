﻿using System;

namespace Labs.Chapter22
{

  /*
  A DELEGATE is a type which defines a method signature and
  holds a reference for a method whose signature will match the
  delegate. Therefore delegates are used to reference a method.

  An EVENT is a 'notification' which is raised by an object 
  to signify the occurrence of some action. Our delegate is then
  associated with the event and holds a reference to a 
  method which will be called when the event is raised.

  An event is associated with an Event Handler using a Delegate.
  When the Event is raised it sends a signal to delegates 
  and the delegate executes the correct matching function.

  The steps to use events are:

  1: Define the Delegate
  2: Define the Event with same the same name as the Delegate.
  3: Define the Event Handler that responds when event is raised.

  */
  // Subscriber class
  public class RepairClaimChecker
  {
    static void Main(string[] args)
    {
      RepairClaimCheckerLogic myRepairClaimCheckerLogic = 
        new RepairClaimCheckerLogic();

      myRepairClaimCheckerLogic.GetRepairClaimData();

      /* 
      Event is bound with the delegate
      Here we are creating a delegate, a pointer, to the method 
      called OverLimitMessage and adding it to the list of
      Event Handlers
      */
      myRepairClaimCheckerLogic.overLimit 
        += new RepairClaimCheckerLogic.RepairClaimCheckerDelegate(OverLimitMessage);
     
      myRepairClaimCheckerLogic.ReadAndCheckRepairClaims();
    }

    /* 
    Delegates call this method when the event is raised.
    This is the code that executes when overLimit is fired
    */
    static void OverLimitMessage(int claimNumber, double value)
    {
      Console.WriteLine($"*** Claim {claimNumber} for {value} needs to be verified***");
    }
  } // End of the class RepairClaimChecker

  // Publisher class
  public class RepairClaimCheckerLogic
  {
    /* 
    Declare the delegate. This delegate can be used to point
    to any method which is a void method and accepts an int 
    followed by a double as its parameters
    */
    public delegate void RepairClaimCheckerDelegate(int claimNumber, double claimValue);

    /* 
    Declare the event. This event can cause any method that 
    matches the RepairClaimCheckerDelegate to be called
    */
    public event RepairClaimCheckerDelegate overLimit;

    double[] repairClaimsAmounts = new double[3];

    public void GetRepairClaimData()
    {
      for (int i = 0; i < 3; i++)
      {
        Console.WriteLine("What is the repair claim amount?");

        double claimAmount = Convert.ToDouble(Console.ReadLine());
        repairClaimsAmounts[i] = claimAmount;
      } // End of the for iteration construct

    } // End of GetRepairClaimData() method

    public void ReadAndCheckRepairClaims()
    {
      for (int i = 0; i < 3; i++)
      {
        if (repairClaimsAmounts[i] > 5000)
        {
          /* 
          Here we are raising the event and this evennt is linked
          to the method called  OverLimitMessage() which accepts
          the two values and displays a message
          */
          overLimit(i, repairClaimsAmounts[i]); // Raised event
        } // End of the if selection construct
      } // End of the for iteration construct

    } // End of the ReadAndCheckRepairClaims() method

  } // End of the class RepairClaimCheckerLogic

} // End of namespace Labs.Chapter22
