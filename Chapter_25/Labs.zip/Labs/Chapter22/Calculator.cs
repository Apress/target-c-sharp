﻿using System;

namespace Labs.Chapter22
{
  // Subscriber class
  public class CalculatorApplication
  {
    static void Main(string[] args)
    {
      Calculator myCalculator = new Calculator();

      /* 
      Event is bound with the delegate
      Here we are creating a delegate, a pointer, to the method 
      called EventMessage and adding it to the list of
      Event Handlers
      */
      myCalculator.numberGreaterThanNine += 
        new Calculator.CalculatorDelegate(EventMessage);

      // Call the Add method in the Calculator class
      myCalculator.Add(8,2);
    }

    /* 
    Delegates call this method when the event is raised.
    This is the code that executes when numberGreaterThanNine
    is fired
    */
    static void EventMessage()
    {
      Console.WriteLine("* Number greater than 10 detected *");
    }
  } // End of the class CalculatorApplication

  // Publisher class
  public class Calculator
  {
    /* 
    Declare the delegate. This delegate can be used to point to
    any method which is a void method and accepts no parameters
    */
    public delegate void CalculatorDelegate();

    /* 
    Declare the event. This event can cause any method that 
    matches the CalculatorDelegate to be called
    */
    public event CalculatorDelegate numberGreaterThanNine;
    
   
    public void Add(int numberOne, int numberTwo)
    {
      int answer = numberOne + numberTwo;
      if(answer > 9)
      {
        /* 
        Here we are raising the event and this evennt is linked
        to the method called EventMessage() which accepts
        no values and displays a message
        */
        numberGreaterThanNine(); // Raised event
      }
      Console.WriteLine($"The total of {numberOne} and " +
        $"{numberTwo}, is {numberOne + numberTwo} ");
    } 

  } // End of the class Calculator
} // End of namespace Labs.Chapter22
