﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labs.Chapter06
{
  /*
  The class holds members (fields) and methods. 
  In this example there will only be a main method. 
  This is where the application will start running. 
  */

  internal class Lab4
  {
    /* 
    The Main method is where we will add all our variables and 
    write our code. This is only suitable as we are learning to
    program but as we develop our skills we will modularise our
    code i.e. we will break the code up into small methods each
    having only one role. We might not want to declare all our 
    variables in the Main method, we may want them to be 
    declared inside the smaller methods (chapters). This is where
    we will begin to understand about the scope of variables. 
    */
    static void Main(string[] args)
    {
    /* 
    A credit card will have a 16-digit number on the front. We 
    may wish to include hyphens or spaces between each set of 4 
    digits. For this reason, we are making the data type string.
    */
      string creditCardNumber;

    /* 
    The month in which the credit card will expire will be 
    entered as a number which will be from 0 -12 based on the 
    calendar months. This means we can use a byte or sbyte data 
    type as it is a small value. The sbyte data type has a 
    minimum value of -128 and a maximum value of 127. The byte 
    type has a minimum value of 0 and a maximum value of 255.
    A month cannot be a negative, so we use a byte data type. 
    */
      byte expiryMonth;

    /* 
    The year of expiry only requires the last two digits of the 
    year, it will not require the two digits of the century.  
    We should use a byte data type as 0 – 255 will be an
    acceptable range for the year. 
    */
      byte expiryYear;

    /* 
    The card issue number is a one or two digit number on the 
    front of the card. Some credit cards will not have an issue 
    number. For this example we should expect the user to enter 
    a 0 if there is no issue number. 
    */
      byte issueNumber;

    /* 
    A card verification code (CVC) is also known as the card 
    verification value (CVV) and is a security feature used when 
    the user is not present to make the payment and present the 
    card. It is aimed at reducing fraud. 
    */
      int threeDigitCode;

    /* 
    A credit card will have a name imprinted on it. This must be 
    the exact name used when making a transaction. The name will
    be treated as a string input. 
    */
      string nameOnCard;

    //Enter the card holder name as it appears on the card
      Console.WriteLine("Enter your name as it appears " +
        "on your Credit Card");
      nameOnCard = Console.ReadLine();

    /* 
    Ask the user to enter the 16-digit credit card number as it 
    appears on the credit card and insert hyphens (-) between 
    each set of 4 digits. Then use the ReadLine() method to read 
    the data input at the console. The input data will be a 
    string, so no conversion is necessary as we are assigning 
    the value to a variable we declared as data type string. 
    */
      Console.WriteLine("Enter the 16 digit credit card number");
      Console.WriteLine("Use hyphens as shown in this " +
        "example to separate each ");
      Console.WriteLine("set of 4 digits  1234-5678-1234-7890");
      creditCardNumber = Console.ReadLine();

    /* 
    Ask the user to enter the value of the expiry month. Then use
    the ReadLine() method to read the data input at the console.
    The input data will be a string, so a conversion is necessary
    as we are assigning the value to a variable declared as data
    type byte. We therefore have to use the Convert class and the
    ToByte() method to convert the data read from the console. 
    */
      Console.WriteLine("Enter the expiry month number");
      expiryMonth = Convert.ToByte(Console.ReadLine());

    /* 
    Ask the user to enter the value of the expiry year. Then use
    the ReadLine() method to read the data input at the console. 
    */
      Console.WriteLine("Enter the expiry year number");
      expiryYear = Convert.ToByte(Console.ReadLine());

    /* 
    Ask the user to enter the value for the issue number.
    Then use the ReadLine() method to read the data input at the
    console. The input data will be a string so a conversion is 
    necessary as we are assigning the value to a variable we 
    declared as data type byte. We therefore have to use the 
    Convert class and the ToByte() method to convert the data 
    read from the console.
    */
      Console.WriteLine("Enter the value for the issue mumber " +
        "\n(enter 0 if there is no issue number on our card)");
      issueNumber = Convert.ToByte(Console.ReadLine());

    /* 
    Ask the user to enter the value of the 3-digit security code
    that appears on the back of the card. Then use the ReadLine()
    method to read the data input at the console. The input data
    will be a string so a conversion is necessary to assign the 
    value to a variable we declared as data type int. We 
    therefore have to use the Convert class and the ToInt32() 
    method to convert the data read from the console. 
    */
     Console.WriteLine("Enter the 3 digit security number " +
      "from the back of the card");
    threeDigitCode = Convert.ToInt32(Console.ReadLine());

    /* 
    Now we will display the data we have accepted from the user. 
    We use the WriteLine() method from the Console class to 
    display the data. The information we have between the 
    brackets () of the WriteLine() is a concatenation of a string
    of text between the double quotes "" and a variable. We 
    have also used the escape sequence \n (new line) and the 
    \t (tab) in an attempt to format the display. 
    */
    Console.WriteLine("We have entered the following details\n");
    Console.WriteLine("*************************************\n");
    Console.WriteLine($"Cardholder name:\t {nameOnCard}");
    Console.WriteLine($"Card number:\t\t {creditCardNumber}");
    Console.WriteLine($"Card expiry month:\t {expiryMonth}");
    Console.WriteLine($"Card expiry year:\t {expiryYear}");
    Console.WriteLine($"Card issue number:\t {issueNumber}");
    Console.WriteLine($"Card security code:\t {threeDigitCode}");
    Console.WriteLine("*************************************\n");

    } // End of Main() method    
  } // End of Lab4 class
} //End of Labs.Chapter06 namespace 