﻿using System;

namespace Labs.Chapter06
{
  internal class Lab1
  {
    static void Main(string[] args)
    {
      int length;
      int breadth;
      int area;

      length = 20;
      breadth = 10;

      area = length * breadth;

      Console.WriteLine();
      Console.WriteLine($"The area of the rectangle is {area} square centimetres");
      Console.WriteLine();

    } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter06 namespace 