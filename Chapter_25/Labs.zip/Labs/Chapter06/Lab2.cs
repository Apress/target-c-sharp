﻿using System;

namespace Labs.Chapter06
{
  internal class Lab2
  {
    static void Main(string[] args)
    {
      int length;
      int breadth;
      int area;

      Console.WriteLine("What is the length of the rectangle in centimteres");
      length = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("What is the breadth of the rectangle in centimteres");
      breadth = Convert.ToInt32(Console.ReadLine());

      area = length * breadth;

      Console.WriteLine();
      Console.WriteLine($"The area of the rectangle is {area } square centimetres");
      Console.WriteLine();

    } // End of Main() method    
  } // End of Lab2 class
} //End of Labs.Chapter06 namespace 