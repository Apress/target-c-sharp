﻿using System;

namespace Labs.Chapter06
{
  internal class Lab3
  {
    static void Main(string[] args)
    {
      int length;
      int breadth;
      int height;
      int volume;

      Console.WriteLine("What is the length of the rectangle in centimteres");
      length = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("What is the breadth of the rectangle in centimteres");
      breadth = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("What is the height of the cuboid in centimteres");
      height = Convert.ToInt32(Console.ReadLine());

      volume = length * breadth * height;

      Console.WriteLine();
      Console.WriteLine($"The volume of the cuboid is {volume} cubic centimetres");
      Console.WriteLine();

    } // End of Main() method    
  } // End of Lab3 class
} //End of Labs.Chapter06 namespace 