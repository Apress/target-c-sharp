﻿using System;

namespace Labs.Chapter08
{
  internal class Lab1
  {
    static void Main(string[] args)
    {
      // Declare variables required
      int hoursWorked;
      double hourlyRate, nettPay, grossPay;
      double nationalInsuranceDeductions, incomeTaxDeductions;
      double nationalInsuranceRate = 0.05, incomeTaxRate = 0.2;

      // Input Hours Worked
      Console.WriteLine("Enter the number of hours worked: ");
      hoursWorked = Convert.ToInt32(Console.ReadLine());

      // Input Hourly Rate
      Console.WriteLine("Enter Hourly Rate: ");
      hourlyRate = Convert.ToDouble(Console.ReadLine());

      // Process - calculate the nett pay
      grossPay = hoursWorked * hourlyRate;

      nationalInsuranceDeductions = 
            grossPay * nationalInsuranceRate;

      incomeTaxDeductions = 
        (grossPay - nationalInsuranceDeductions) * incomeTaxRate;

      nettPay = grossPay - nationalInsuranceDeductions
        - incomeTaxDeductions;

      // Output simple payslip
      Console.WriteLine($"{"PAYSLIP",22}");
      Console.WriteLine($"===============================");
      Console.WriteLine($"{"Hours Worked",-20} {hoursWorked,10}");
      Console.WriteLine($"{"Hourly Rate",-20} {hourlyRate,10:0.00}");
      Console.WriteLine($"{"Gross Pay",-20} {grossPay,10:0.00}");
      Console.WriteLine($"{"National Insurance",-20} { nationalInsuranceDeductions,10:0.00}");
            Console.WriteLine($"{"Income Tax",-20} {incomeTaxDeductions,10:0.00}");
      Console.WriteLine($"{"=======",31} \n");
      Console.WriteLine($"{"Nett Pay",-20} {nettPay,10:0.00}");
      Console.WriteLine($"{"=======",31} \n");

    } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter08 namespace