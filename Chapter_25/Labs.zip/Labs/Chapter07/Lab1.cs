﻿using System;

namespace Labs.Chapter07
{
  internal class Lab1
  {
   static void Main(string[] args)
   {
    // Declare the variables 
    int numberOfGamesWon, numberOfGamesDrawn, numberOfGamesLost;
    int numberOfGamesPlayed, numberOfPointsAccumulated;

    // Input - accept user input
    Console.WriteLine("How many games were won this season? ");
    numberOfGamesWon = Convert.ToInt32(Console.ReadLine());

    Console.WriteLine("How many games were drawn this season? ");
    numberOfGamesDrawn = Convert.ToInt32(Console.ReadLine());

    Console.WriteLine("How many games were lost this season? ");
    numberOfGamesLost = Convert.ToInt32(Console.ReadLine());

    // Process - total the number of games played
    numberOfGamesPlayed = numberOfGamesWon + 
        numberOfGamesDrawn + numberOfGamesLost;

   /* 
    Calculate the number of points based on 3 points for a win
   1 point for a draw and 0 points for a lost game
   */
   numberOfPointsAccumulated = (3 * numberOfGamesWon)
        + numberOfGamesDrawn;

   // Output the details
   Console.WriteLine();
   Console.WriteLine($"The number of games this season " +
     $"was {numberOfGamesPlayed}\n");
   Console.WriteLine($"The number of points achieved " +
     $"was {numberOfPointsAccumulated}");

   } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter07 namespace 