﻿using System;

namespace Labs.Chapter07
{
  internal class Lab2
  {
    static void Main(string[] args)
    {
      int scoreInTestOne, scoreInTestTwo, totalScoreForTwoTests;
      double averageOfTheTwoScores;

      // Input - accept user input for test score one
      Console.WriteLine("What was the score for test one? ");
      scoreInTestOne = Convert.ToInt32(Console.ReadLine());

      Console.WriteLine("What was the score for test two? ");
      scoreInTestTwo = Convert.ToInt32(Console.ReadLine());

      // Process - calculate the total the number of games played
      totalScoreForTwoTests = scoreInTestOne + scoreInTestTwo;
      
      // Process - calculate the average the two scores 
      averageOfTheTwoScores = totalScoreForTwoTests / 2.0;

      // Output the details
      Console.WriteLine("");
      Console.WriteLine($"The total of the two scores " +
        $"is {totalScoreForTwoTests}");
      Console.WriteLine($"The average mark for the two" +
        $" tests is { averageOfTheTwoScores}");

    } // End of Main() method    
  } // End of Lab2 class
} //End of Labs.Chapter07 namespace 