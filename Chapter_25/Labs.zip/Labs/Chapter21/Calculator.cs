﻿using System;

namespace Labs.Chapter21
{
  /*
  Define the delegates
  We have an access modifier, a return type and the 
  parameters of the delegate. This essentially defines the
  methods that can be associated with the delegate, the methods
  must have the same attributes
  This is step 1. define the delegate, of 3 steps

  A delegate can be declared in the class and therefore 
  it is available only to that class's members
  It can be declared in the namespace and therefore it is 
  available to all namespace classes and outside the namespace
  */
  public delegate void CalculatorDelegate(int firstNumber, int secondNumber);
 
  internal class Calculator
  {
    /* 
    Define the methods we will use. Here we will use one
    non static and one static method
    */
    public void Add(int numberOne, int numberTwo)
    {
      Console.WriteLine($"The total of {numberOne} and " +
        $"{numberTwo}, is {numberOne + numberTwo} ");
    }

    public static void Subtract(int numberOne, int numberTwo)
    {
      Console.WriteLine($"The difference between {numberOne} " +
        $"and {numberTwo}, is {numberOne - numberTwo} ");
    }
  } // End of the class Calculator

  internal class CalculatorApplication
  {
    static void Main(string[] args)
    {
      /*
       The steps to use when dealing with delegates are
        1. define the delegate
        2. instantiate the delegate
        3. invoke the delegate
      */
      // Instantiate the Calculator class
      Calculator myCalculator = new Calculator();

      /*
      Instantiate delegate by passing the name of the 
      target function as its argument. In this case we will use
      the non static method so we use the instance name
      This is step 2. instantiate the delegate, of 3 steps
      */
      CalculatorDelegate myDelegate1 = new CalculatorDelegate(myCalculator.Add);

      /* 
      Now we Invoking The Delegates
      This is step 3. invoke the delegate, of 3 steps
      we could also just use myAddDelegate(8, 2); 
      */
      myDelegate1.Invoke(8, 2);


      /*
      Instantiate delegate by passing the name of the 
      target function as its argument. In this case we will use
      the static method so we use the class name not the instance
      This is step 2. instantiate the delegate, of 3 steps
      */
      CalculatorDelegate myDelegate2 = new CalculatorDelegate(Calculator.Subtract);

      /* 
      Now we Invoking The Delegates
      This is step 3. invoke the delegate, of 3 steps
      we could also just use myAddDelegate(8, 2); 
      */
      myDelegate2.Invoke(8, 2);

    }
  } // End of the class CalculatorApplication
} // End of namespace Labs.Chapter21
