﻿using System;

namespace Labs.Chapter21
{
  internal class CustomerAccount
  {
    static double currentBalance;

    /* 
    Define the methods we will use. Here we will use one
    non static methods
    */
    public double AddFunds(double amountIn)
    {
      return currentBalance += amountIn;
    } // End of AddFunds() method

    public double WithdrawFunds(double amountOut )
    {
      return currentBalance -= amountOut;
    } // End of WithdrawFunds() method


    /* 
    Define the delegates
    We have an access modifier, a return type and the 
    parameters of the delegate. This essentially defines the
    methods that can be associated with the delegate, the methods
    must have the same attributes
    
    A delegate can be declared in the class and therefore 
    it is available only to that class's members
    It can be declared in the namespace and therefore it is 
    available to all namespace classes and outside the namespace
    */

    /*
    This is step 1. define the delegate, of 3 steps
    */
    public delegate double AmendFundsDelegate(double amount);

    static void Main(string[] args)
    {
      /*
      The steps to use when dealing with delegates are
      1. define the delegate
      2. instantiate the delegate
      3. invoke the delegate
      */
      // Instantiate the CustomerAccount class
      CustomerAccount myCustomer = new CustomerAccount();

      /*
      Instantiate delegate by passing the name of the 
      target function as its argument. In this case we will use
      the non static methods so we use the instance name
      This is step 2. instantiate the delegate, of 3 steps
      */
      AmendFundsDelegate getBalance;
      getBalance = new AmendFundsDelegate(myCustomer.AddFunds);

      double transactionAmount = 100.00;

      /* 
      Now we Invoking The Delegates
      This is step 3. invoke the delegate, of 3 steps
      we could also just use getBalance(100); 
      */
      getBalance.Invoke(transactionAmount);

      Console.WriteLine($"The new balance is : {currentBalance}");

     // Console.WriteLine(getBalance.Invoke(transactionAmount + 1000));
    } // End of Main() method
  } // End of class CustomerAccount

} // End of namespace Labs.Chapter21
