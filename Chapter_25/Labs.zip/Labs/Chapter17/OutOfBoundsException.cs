﻿using System;
namespace Labs.Chapter17
{
  internal class OutOfBoundsException
  {
    public static void Main(string[] args)
    {
      int[] claimValues = { 1000, 9000, 0, 4000, 5000 };

      for (int i = 0; i < claimValues.Length; i++)
      {
        Console.WriteLine(claimValues[i]);
      }

      try
      {
        // Write a value which is outside the array upper limit
        Console.WriteLine(claimValues[5]);

      }
      catch (IndexOutOfRangeException theexception)
      {
       // Display the exception message received
       Console.WriteLine($"Exception is - {theexception.Message}");
      } 
    }// End of Main() method  
  } // End of OutOfBoundsException class

} //End of Labs.Chapter17 namespace