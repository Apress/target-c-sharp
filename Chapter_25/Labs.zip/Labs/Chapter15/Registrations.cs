﻿using System;

namespace Labs.Chapter15
{
  internal class Registrations
  {
    static String[] vehicleRegistrations = 
    {"ABC 1000", "FEA 2222", "QWA 4444","FAC 9098", "FEA 3344"};

    static void Main(string[] args)
    {
      // Call the method that will find the registration
      allRegistrationsBeginningWithSpecifiedLetter("F");
    } // End of Main() method   


    public static void allRegistrationsBeginningWithSpecifiedLetter(String letterInRegistration)
    {
    Console.WriteLine("Registrations beginning with F");
    // Iterate the array
    for (int counter = 0; counter < vehicleRegistrations.Length; counter++)
    {
      // Check if the current element starts with the letter
      if (vehicleRegistrations[counter].StartsWith(letterInRegistration))
      {
        Console.WriteLine(vehicleRegistrations[counter]);
      }
    }
  }//End of allRegistrationsBeginningWithSpecifiedLetter() method

  } // End of Registrations class
} //End of Labs.Chapter15 namespace 