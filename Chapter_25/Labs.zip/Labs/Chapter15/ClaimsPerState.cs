﻿using System;

namespace Labs.Chapter15
{
  internal class ClaimsPerState
  {
    static String[] claimsWithStateAbbreviation = 
    {"1000IL", "2000FL", "1500TX","1200CA", "2000NC", "0300FL"};

    static void Main(string[] args)
    {
      // Call the displayTheSortedClaims() method 
      Console.WriteLine("The sorted array elements are");

      displayTheSortedClaims();

      // Declare the state to be found
      String stateAbbreviationToFind = "FL";

      // Call the allClaimsInASpecificState() method
      // passing it the string to be found
      Console.WriteLine($"The claims for the state of" +
        $" {stateAbbreviationToFind} are \n");
      allClaimsInASpecificState(stateAbbreviationToFind);

      // Call the findTheTotalOfAllClaimValues() method
      double totalOfAllClaims = findTheTotalOfAllClaimValues();
      Console.WriteLine($"The total of the claim values is" +
      $" {totalOfAllClaims:0.00}");

    } // End of Main() method  

    public static void allClaimsInASpecificState(String stateAbbreviationToFind)
    {
      // Iterate the array
      for (int counter = 0; counter < claimsWithStateAbbreviation.Length; counter++)
      {
        // Check if the current element of the array ends with
        // the letter passed to the method
        if (claimsWithStateAbbreviation[counter].EndsWith(stateAbbreviationToFind))
        {
          Console.WriteLine(claimsWithStateAbbreviation[counter]);
        }
      }
    } // End of allClaimsInASpecificState() method
    public static void displayTheSortedClaims()
    {
      // Sort the claimsWithStateAbbreviation array
      Array.Sort(claimsWithStateAbbreviation);
      // Iterate the sorted array using the foreach construct
      foreach (String claim in claimsWithStateAbbreviation)
      {
        Console.WriteLine(claim);
      }
    } // End of displayTheSortedClaims() method
    public static double findTheTotalOfAllClaimValues()
    {
      double currentTotalValue = 0.00;
      double claimValue = 0.00;
      String firstFourCharacters;
      // Iterate the array
      for (int counter = 0; counter < claimsWithStateAbbreviation.Length; counter++)
      {
      /* 
      Read the first four characters of the array element, parse
      (convert) it to a double and add it to the current total
      */
        firstFourCharacters = 
          claimsWithStateAbbreviation[counter].Substring(0, 4);
        claimValue = Double.Parse(firstFourCharacters);
        currentTotalValue += claimValue;
      }
      return currentTotalValue;
    } // End of findTheTotalOfAllClaimValues() method

  } // End of ClaimsPerState class
} //End of Labs.Chapter15 namespace 