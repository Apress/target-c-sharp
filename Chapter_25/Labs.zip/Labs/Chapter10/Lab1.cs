﻿using System;

namespace Labs.Chapter10
{
  internal class Lab1
  {
    static void Main(string[] args)
    {
      // Create a variable to hold the dollar amount
      double dollarAmount;

      // Create a constant to hold the exchange rate
      const double dollarsPerPoundRate = 1.25;

      // Display a heading for the columns
      Console.WriteLine($"{"Pounds",-10} {"Dollars",-10}");

      // Iterate 10 times to convert the pounds to dollars
      for (int poundAmount = 1; poundAmount < 11; poundAmount++)
      {
        // Convert pounds to dollars at the rate assigned
        dollarAmount = poundAmount * dollarsPerPoundRate;
        Console.WriteLine($"{poundAmount,-10} {dollarAmount,-10:0.00}");
      }

    } // End of Main() method    
  } // End of Lab1 class
} //End of Labs.Chapter10 namespace 