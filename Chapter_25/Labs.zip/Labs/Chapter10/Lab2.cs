﻿using System;

namespace Labs.Chapter10
{
  internal class Lab2
  {
    static void Main(string[] args)
    {
      // Create a variable to hold the dollar amount
      double dollarAmount;

      // Create variables for the start and end values
      int startValue, endValue;

      // Create a constant to hold the exchange rate
      const double dollarsPerPoundRate = 1.40;

      // Ask the user to input the start value
      Console.WriteLine("What value do you wish to start at?");
      startValue = Convert.ToInt32(Console.ReadLine());

      // Ask the user to input the end value
      Console.WriteLine("What value do you wish to end at?");
      endValue = Convert.ToInt32(Console.ReadLine());

      // Display a heading for the columns
      Console.WriteLine($"{"Pounds",-10} {"Dollars",-10}");

      /*
      Iterate starting at the users start value and 
      stopping at the users end value
      */
      for (int poundAmount = startValue; poundAmount <= endValue; poundAmount++)
      {
        // Convert pounds to dollars at the rate assigned
        dollarAmount = poundAmount * dollarsPerPoundRate;

        Console.WriteLine($"{poundAmount,-10} {dollarAmount,-10:0.00}");
      } // End of for block   

    } // End of Main() method    
  } // End of Lab2 class
} //End of Labs.Chapter10 namespace