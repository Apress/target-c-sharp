﻿using System;

namespace Labs.Chapter10
{
  internal class Lab3
  {
    static void Main(string[] args)
    {
      // Create a variable to hold the user input
      String programmingLanguageInput = null;

      do
      {
        // Ask the user to input the programming language
        Console.WriteLine("What is the programming language?");
        programmingLanguageInput = Console.ReadLine().ToUpper();

        if (programmingLanguageInput.Equals("X"))
        {
          // Display an end message
          Console.WriteLine("Goodbye");
        }
        else
        {
          // Display a heading for the columns
          Console.WriteLine($"There are many programming " +
            $"languages including {programmingLanguageInput}\n");
        }
      } while (!"X".Equals(programmingLanguageInput));

    } // End of Main() method    
  } // End of Lab3 class
} //End of Labs.Chapter10 namespace