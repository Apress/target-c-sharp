﻿using System;

namespace Labs.Chapter10
{
  internal class Lab4
  {
    static void Main(string[] args)
    {
      // Create a variable to hold the number of entries
      int numberOfEntriesBeingMade, numberOfEntriesCompleted = 0;

      // Ask the user to input the number of entries being made
      Console.WriteLine("How many new vehicle registrations are you entering?");
      numberOfEntriesBeingMade = 
        Convert.ToInt32(Convert.ToInt32(Console.ReadLine()));

      while (numberOfEntriesBeingMade > numberOfEntriesCompleted)
      {
       // Ask the user to input the vehicle registration number
       Console.WriteLine("What is the vehicle registration number?");
       String vehicleRegistrationNumber = Console.ReadLine();

       // Display a message
       Console.WriteLine($"You have entered " +
        $"{numberOfEntriesCompleted + 1} vehicle registration " +
        $"number which was { vehicleRegistrationNumber}\n");
        numberOfEntriesCompleted++;
      }
      Console.WriteLine("Goodbye");

    } // End of Main() method    
  } // End of Lab4 class
} //End of Labs.Chapter10 namespace