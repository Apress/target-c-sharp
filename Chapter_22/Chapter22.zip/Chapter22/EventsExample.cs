﻿using System;

namespace Chapter22
{
  class EventsExample
  {
    static void Main(string[] args)
    {
      /* 
      Create a new instance of the Customer class
      i.e we have a new Customer.
      */
      Customer myNewCustomer = new Customer(123456, 
        "Gerry Byrne", false);

      /* 
      Create a new instance of the Policy class 
      i.e. a new Policy for the new Customer.
      */
      Policy myNewPolicy = new Policy(myNewCustomer);

      /* 
      Call the Customer method that will change the 
      status of the Customer account
      */
      myNewCustomer.toggleAccountStatus();
    } // End of Main() method

    // Customer class - the Publisher class
    class Customer
    {
      // Declare the members, fields
      public int accountNo;
      public String name;
      public bool status = false;

      // Create a constructor used to initialise all the members
      public Customer(int accountNo, string name, bool status)
      {
        this.accountNo = accountNo;
        this.name = name;
        this.status = status;
      }  // End of Customer constructor

    /* 
    Override the ToString() method of the class to 
    display details of the customer
    */
      public override string ToString()
      {
        return ($"The customer details are : \n\tAccount Number" +
         $" \t {this.accountNo} \n\tCustomer name \t " +
         $"{ this.name} \n\tAccount status \t { this.status}\n");
      } // End of ToString() method

      /* 
      Define the delegate. We name the delegate using the name
      of our event and add the phrase EventHandler. So here we 
      are saying the event will be called ActivatePolicy.
      */
      public delegate void ActivatePolicyEventHandler();

      /*
      Think of the event as being a restricted delegate and 
      classes can choose to subscribe or unsubscribe from 
      the event. The event is a member of the class.
      */
      public event ActivatePolicyEventHandler AccountStatusToggled;

      // Create the method to be called when the event is raised.
      public void toggleAccountStatus()
      {
        AccountStatusToggled();
      } // End of toggleAccountStatus()

    } // End of Customer class

    class Policy
    {
      // Create a Customer instance
      Customer myCustomer;

      public Policy(Customer customer)
      {
        /* 
         Inject a Customer object into the Policy 
        i.e. the Policy can reference the instance of Customer
        */
        myCustomer = customer;

      /* 
      We have the event and we will now add a reference to 
      the method that will be used when the event is raised. 
      So, we are chaining the new method onto the event, 
      even though presently there is only one method 
      associated with the event.
      */
        myCustomer.AccountStatusToggled += changeAccountStatus;
        myCustomer.AccountStatusToggled += emailNotification;

        // Remove an event using -= followed by the method name
        myCustomer.AccountStatusToggled -= emailNotification;

      } // End of Policy constructor

      /*
      Create the method that is referred to by the event when 
      it is raised. Here we change the Customer field to true 
      indicating that the account has been set up.
      */
      public void changeAccountStatus()
      {
        myCustomer.status = true;
        Console.WriteLine($"The account status was updated" +
            $" to {myCustomer.status}\n");
        Console.WriteLine(myCustomer.ToString());
      } // End of changeAccountStatus() method

      /*
      Create a second method that is referred to by the event 
      when it is raised. Here we 'emulate' an email being sent, 
      we write a message to the console.
      */
      public void emailNotification()
      {
        Console.WriteLine("email sent to accounts department");
      } // End of emailNotification() method

    } // End of Policy class



  } // End of EventsExample class
} // End of Chapter22 namespace