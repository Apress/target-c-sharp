﻿using System;

namespace Chapter14.Example3Interfaces
{
  internal class CountryOne : IEcommerceBilling, IEcommercePayment
  {
    public double TaxCalculation(double itemPrice)
    {
      return itemPrice * 0.2;
    } // End of taxCalculation() method

    public double PaymentMethod(String paymentType, double
    transactionAmount)
    {
      double cardFee;

      if (paymentType.Equals("Debit"))
      {
        cardFee = DebitCardPaymentFee(transactionAmount);
      } // End of if block
      else
      {
        cardFee = CreditCardPaymentFee(transactionAmount);
      }// End of else block

      return cardFee;
    } // End of PaymentMethod() method

    public double DebitCardPaymentFee(double debitAmount)
    {
      return debitAmount * 0.01; // 1%
    } // End of DebitCardPaymentFee() method

    public double CreditCardPaymentFee(double creditAmount)
    {
      return creditAmount * 0.02; // 2%
    } // End of CreditCardPaymentFee() method

  } // End of CountryOne class
} // End of Chapter14.Example3Interfaces namespace