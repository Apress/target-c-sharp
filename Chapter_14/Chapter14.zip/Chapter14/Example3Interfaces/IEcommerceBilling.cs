﻿using System;

namespace Chapter14.Example3Interfaces
{
  internal interface IEcommerceBilling
  {
    // Abstract method 
    double TaxCalculation(double itemPrice);

  } // End of IEcommerceBilling interface
} // End of Chapter14.Example3Interfaces namespace