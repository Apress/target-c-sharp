﻿using System;

namespace Chapter14.Example3Interfaces
{
  internal class EcommerceApplication
  {
    static void Main(string[] args)
    {
      double itemPrice = 100.00;
      double feeForUsingACard;

      CountryOne myCountryOne = new CountryOne();
      CountryTwo myCountryTwo = new CountryTwo();
      CountryThree myCountryThree = new CountryThree();

      Console.WriteLine();
      Console.WriteLine();

      Console.WriteLine();
      Console.WriteLine();


      Console.WriteLine($"The tax on an item of price " +
$"£{itemPrice} is £{ myCountryOne.TaxCalculation(itemPrice)}");

      Console.WriteLine($"The tax on an item of price " +
$"£{itemPrice} is £{ myCountryTwo.TaxCalculation(itemPrice)}");

      Console.WriteLine($"The tax on an item of price " +
      $"£{itemPrice} is £{ myCountryThree.TaxCalculation(itemPrice)}");

      feeForUsingACard = myCountryOne.PaymentMethod("Credit", 200);

      Console.WriteLine($"The fee for using this card with this " +
       $"transaction amount is £{ feeForUsingACard: 0.00}");

      feeForUsingACard = myCountryTwo.PaymentMethod("Debit", 200);

      Console.WriteLine($"The fee for using this card with this " +
        $"transaction amount is £{ feeForUsingACard: 0.00}");

      feeForUsingACard = myCountryThree.PaymentMethod("Credit", 200);

      Console.WriteLine($"The fee for using this card with this " +
        $"transaction amount is £{ feeForUsingACard: 0.00}");

    } // End of Main() method

  } // End of EcommerceApplication class
} // End of Chapter14.Example3Interfaces namespace