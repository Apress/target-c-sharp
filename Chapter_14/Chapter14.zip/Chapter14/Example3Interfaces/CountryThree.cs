﻿using System;

namespace Chapter14.Example3Interfaces
{
  internal class CountryThree : IEcommerceBilling, IEcommercePayment
  {
    public double TaxCalculation(double itemPrice)
    {
      return itemPrice * 0.10;
    } // End of TaxCalculation() method

    public double PaymentMethod(String paymentType, double transactionAmount)
    {
      double cardFee;

      if (paymentType.Equals("Debit"))
      {
        cardFee = DebitCardPaymentFee(transactionAmount);
      } // End of if block
      else
      {
        cardFee = CreditCardPaymentFee(transactionAmount);
      }// End of else block

      return cardFee;
    } // End of PaymentMethod() method

    public double DebitCardPaymentFee(double debitAmount)
    {
      return debitAmount * 0.02; // 2%
    } // End of DebitCardPaymentFee() method

    public double CreditCardPaymentFee(double creditAmount)
    {
      return creditAmount * 0.03; // 3%
    } // End of CreditCardPaymentFee() method

  } // End of CountryThree class
} // End of Chapter14.Example3Interfaces namespace