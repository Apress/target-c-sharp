﻿using System;

namespace Chapter14.Example3Interfaces
{
  internal class CountryTwo : IEcommerceBilling, IEcommercePayment
  {
    public double TaxCalculation(double itemPrice)
    {
      return itemPrice * 0.15;
    } // End of TaxCalculation() method

    public double PaymentMethod(String paymentType, double transactionAmount)
    {
      double cardFee=0;

      if (paymentType.Equals("Debit"))
      {
        cardFee = DebitCardPaymentFee(transactionAmount);
      } // End of if block
      else
      {
        cardFee = CreditCardPaymentFee(transactionAmount);
      }// End of else block

      return cardFee;
    } // End of PaymentMethod() method

    public double DebitCardPaymentFee(double debitAmount)
    {
      return debitAmount * 0.015; // 1.5%
    } // End of DebitCardPaymentFee() method

    public double CreditCardPaymentFee(double creditAmount)
    {
      return creditAmount * 0.025; // 2.5%
    } // End of CreditCardPaymentFee() method


  } // End of CountryTwo class
} // End of Chapter14.Example3Interfaces namespace