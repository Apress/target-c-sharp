﻿using System;

namespace Chapter14.Example3Interfaces
{
  internal interface IEcommercePayment
  {
    // Abstract methods
    double PaymentMethod(String paymentType, 
      double transactionAmount);
    double DebitCardPaymentFee(double debitAmount);
    double CreditCardPaymentFee(double creditAmount);

  } // End of IEcommercePayment interface
} // End of Chapter14.Example3Interfaces namespace