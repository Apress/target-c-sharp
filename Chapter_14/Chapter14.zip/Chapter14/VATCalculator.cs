﻿using System;

namespace Chapter14
{
  internal class VATCalculator
  {
    static void Main(string[] args)
    {
      VATCalculations myCalculations = new VATCalculations(100);

      double vatAmount = myCalculations.CalculateVAT();

      Console.WriteLine($"{"VAT due on the item is",-30} " +
        $"{"£"}{vatAmount}");

      Console.WriteLine($"{"The total item cost is",-30}" +
        $" {"£"}{ myCalculations.CalculateTotalPrice()}\n");

      Console.WriteLine($"{"The discounted amount is  ",-30} " +
   $"{ "£"} { myCalculations.calculateDiscountedAmount()}\n");

    } // End of Main() method

  } // End of VATCalculator class
} // End of Chapter14 namespace