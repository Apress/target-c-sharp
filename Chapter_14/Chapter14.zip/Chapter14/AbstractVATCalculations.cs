﻿using System;

namespace Chapter14
{
  internal abstract class AbstractVATCalculations
  {
    public static double discountRate = 0.10;

    private double itemPrice;
    private double vatAmount;

    /* 
    Declare two incomplete methods which will be detailed in 
    the inherited class. Each is an abstract method - a method 
    signature and an access modifier
    */
    public abstract double CalculateVAT();

    public abstract double CalculateTotalPrice();


  } // End of AbstractVATCalculations class
} // End of Chapter14 namespace