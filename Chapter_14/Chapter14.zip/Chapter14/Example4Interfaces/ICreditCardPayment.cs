﻿using System;

namespace Chapter14.Example4Interfaces
{
  internal interface ICreditCardPayment
  {
    // Abstract method
    double CreditCardPaymentFee(double creditAmount);

  } // End of ICreditCardPayment interface
} // End of Chapter14.Example4Interfaces namespace