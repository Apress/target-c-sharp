﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter14.Example4Interfaces
{
  internal class CountryTwo : IEcommerceBilling,
    IPaymentMethod, IDebitCardPayment
  { 
  public double TaxCalculation(double itemPrice)
  {
    return itemPrice * 0.15;
  } // End of TaxCalculation() method

  public double PaymentMethod(String paymentType,
                                  double transactionAmount)
  {
    double cardFee;

    cardFee = DebitCardPaymentFee(transactionAmount);

    return cardFee;
  } // End of PaymentMethod() method

  public double DebitCardPaymentFee(double debitAmount)
  {
    return debitAmount * 0.02; // 2%
  } // End of DebitCardPaymentFee() method

} // End of CountryTwo class

} // End of Chapter14.Example4Interfaces namespace

