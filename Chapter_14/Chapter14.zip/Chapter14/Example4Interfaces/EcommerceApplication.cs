﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chapter14.Example4Interfaces
{
  internal class EcommerceApplication
  {
    static void Main(string[] args)
    {
      double itemPrice = 100.00;
      double feeForUsingACard;

      CountryTwo myCountryTwo = new CountryTwo();

      Console.WriteLine($"The tax on an item of price " +
      $"£{itemPrice} is " +
      $"£{myCountryTwo.TaxCalculation(itemPrice)}");

    feeForUsingACard = myCountryTwo.PaymentMethod("Debit", 200);

      Console.WriteLine($"The fee for using this card with" +
      $" this transaction amount is £{ feeForUsingACard: 0.00}");
    } // End of Main() method

  } // End of EcommerceApplication class
} // End of Chapter14.Example4Interfaces namespace