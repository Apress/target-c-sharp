﻿using System;

namespace Chapter14.Example4Interfaces
{
  internal interface IDebitCardPayment
  {
    // Abstract methods
    double DebitCardPaymentFee(double debitAmount);

  } // End of IDebitCardPayment interface
} // End of Chapter14.Example4Interfaces namespace
