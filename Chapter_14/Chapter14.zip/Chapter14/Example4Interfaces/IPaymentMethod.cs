﻿using System;

namespace Chapter14.Example4Interfaces
{
  internal interface IPaymentMethod
  {
    // Abstract methods
    double PaymentMethod(String paymentType, double transactionAmount);
  } // End of IPaymentMethod interface
} // End of Chapter14.Example4Interfaces namespace
