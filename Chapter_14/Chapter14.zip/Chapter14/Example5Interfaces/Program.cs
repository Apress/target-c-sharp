﻿using System;

namespace Chapter14.Example5Interfaces
{
  internal class Program
  {
    public static void Main()
    {
      Console.WriteLine("C# 8 default methods in an Interface");

      // Instantiate the PolicyManager class
      //IPolicy myPolicyManager = new PolicyManager();

      // Instantiate the PolicyManager class
      PolicyManager myPolicyManager = new PolicyManager();

      // Call the CreateAPolicy method from the PolicyManager instance
      myPolicyManager.CreateAPolicy();

      // Increment the static policyCounter by 1
      IPolicy.policyCounter = IPolicy.policyCounter + 1;
      Console.WriteLine("Policy created - there is now "
        + IPolicy.policyCounter + " policies");

      // Call the CloseAPolicy method from the PolicyManager instance
      myPolicyManager.CloseAPolicy();

      // Decrement the static policyCounter by 1
      IPolicy.policyCounter = IPolicy.policyCounter - 1;
      Console.WriteLine("Policy closed - there is now "
        + IPolicy.policyCounter + " policies");

      // Call the default method from the PolicyManager instance
      ((IPolicy)myPolicyManager).Print("Auto");

    } // End of Main() method

  } // End of Program class
} // End of Chapter14.Example5Interfaces class