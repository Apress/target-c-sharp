﻿using System;

namespace Chapter14.Example5Interfaces
{
  internal interface IPolicy
  {
    /* 
    C# 8 allows us to have static members. Here we use a 
    static field.
    Remember that static means belonging to the class or 
    interface not the instance of the class or interface.
    We can therefore call the methods and members of the 
    interface directly.
    */
    static int policyCounter;

    // abstract methods, method signature and return type
    void CreateAPolicy();
    void CloseAPolicy();

    // C# 8 allows us to have concrete methods, method with code
    public void Print(string policyName)
    {
      Console.WriteLine($"The policy type created by the " +
        $"default interface method is {policyName}");
    }
  } // End of IPolicy interface

} // End of Chapter14.Example5Interfaces namespace