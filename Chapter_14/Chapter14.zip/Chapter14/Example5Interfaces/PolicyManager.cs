﻿using System;

namespace Chapter14.Example5Interfaces
{
	internal class PolicyManager : IPolicy
	{
		// Implement the abstract method, make it a concrete method
		public void CreateAPolicy()
		{
			Console.WriteLine("Policy created");
		}  // End of CreateAPolicy() concrete method

		// Implement the abstract method, make it a concrete method
		public void CloseAPolicy()
		{
			Console.WriteLine("Policy closed");
		} // End of CloseAPolicy() concrete method

		/* 
		C# 8 allows us to have concrete methods and we 
		can override them in our code
		*/
		public void Print(string policyName)
		{
			Console.WriteLine($"The policy type created by the " +
			$"overridden default interface method is { policyName }");
		}

	}//End of PolicyManager class that implements IPolicy interface

} // End of Chapter14.Example5Interfaces