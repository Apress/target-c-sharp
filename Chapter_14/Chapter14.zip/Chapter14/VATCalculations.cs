﻿using System;

namespace Chapter14
{
  internal class VATCalculations : AbstractVATCalculations
  {
    private double itemPrice;

    public VATCalculations(double itemPrice)
    {
      this.itemPrice = itemPrice;
    } // End of VATCalculations constructor

    public override double CalculateVAT()
    {
      return this.itemPrice * 0.20;
    } // End of CalculateVAT() method

    public override double CalculateTotalPrice()
    {
      return itemPrice + CalculateVAT();
    } // End of CalculateTotalPrice() method

    public double calculateDiscountedAmount()
    {
      return CalculateTotalPrice() *
        AbstractVATCalculations.discountRate;
    } // End of CalculateTotalPrice() method

  } // End of VATCalculations class
} // End of Chapter14 namespace 