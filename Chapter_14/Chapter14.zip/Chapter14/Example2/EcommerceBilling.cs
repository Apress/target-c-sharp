﻿using System;

namespace Chapter14.Example2
{
  // Abstract class
  internal abstract class EcommerceBilling
  {
    // Abstract method 
    public abstract double TaxCalculation(double itemPrice);


  } // End of EcommerceBilling class
} // End of Chapter14 namespace