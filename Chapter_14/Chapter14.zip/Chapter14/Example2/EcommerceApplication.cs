﻿using System;

namespace Chapter14.Example2
{
  internal class EcommerceApplication
  {
    static void Main(string[] args)
    {
      double itemPrice = 100.00;

      CountryOne myCountryOne = new CountryOne();
      CountryTwo myCountryTwo = new CountryTwo();
      CountryThree myCountryThree = new CountryThree();


      Console.WriteLine($"The tax on an item of price " +
    $"£{itemPrice} is " +
    $"£{ myCountryOne.TaxCalculation(itemPrice)}");

    Console.WriteLine($"The tax on an item of price " +
    $"£{itemPrice} is" +
    $" £{ myCountryTwo.TaxCalculation(itemPrice)}");

    Console.WriteLine($"The tax on an item of price " +
    $"£{itemPrice} is " +
    $"£{ myCountryThree.TaxCalculation(itemPrice)}");

    } // End of Main() method

  } // End of EcommerceApplication class
} // End of Chapter14.Example2 namespace
