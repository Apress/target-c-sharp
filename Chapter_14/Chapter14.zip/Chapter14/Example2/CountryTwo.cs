﻿using System;

namespace Chapter14.Example2
{
  internal class CountryTwo : EcommerceBilling
  {
    public override double TaxCalculation(double itemPrice)
    {
      return itemPrice * 0.15;
    } // End of TaxCalculation() method

  } // End of CountryTwo class
} // End of Chapter14.Example2 namespace