﻿using System;

namespace Chapter14.Example2
{
  internal class CountryThree : EcommerceBilling
  {
    public override double TaxCalculation(double itemPrice)
    {
      return itemPrice * 0.10;
    } // End of TaxCalculation() method

  } // End of CountryThree class
} // End of Chapter14.Example2 namespace