﻿using System;

namespace Chapter14.Example2
{
  internal class CountryOne : EcommerceBilling
  {
    public override double TaxCalculation(double itemPrice)
    {
      return itemPrice * 0.2;
    } // End of TaxCalculation() method
  } // End of CountryOne class
} // End of Chapter14.Example2 namespace