﻿using System;
using System.Text.Json.Serialization;

namespace Chapter18
{
  public class CustomerJSON
  {
    /***********************************************************
    The [JsonIgnore] attribute is a 'modifier' which can be 
    used in JSON serialization to ensure the member (type) will 
    not be serialized.
    ***********************************************************/
    public int customerAccountNumber { get; set; }

    [JsonIgnore]
    public int customerAge { get; set; }

    public String customerName { get; set; }
    public String customerAddress { get; set; }
    public int customerYearsWithCompany { get; set; }


    /**********************************************************
    Create a constructor for the Customer class. 
    The constructor will over-write the default constructor. 
    The constructor is used to accept the value passed into it
    from the code used to instantiate the class. 
    The values passed into the constructor are used to 
    initialise the values of fields (members, variables!). 
    The keyword this is used in front of the field names.
    **********************************************************/
    public CustomerJSON(int customerAccountNumber, 
      int customerAge, String customerName, 
      String customerAddress, int customerYearsWithCompany)
    {
      this.customerAccountNumber = customerAccountNumber;
      this.customerAge = customerAge;
      this.customerName = customerName;
      this.customerAddress = customerAddress;
      this.customerYearsWithCompany = customerYearsWithCompany;
    } // End of Customer constructor

  } // End of CustomerJSON class
} // End of Chapter18 namespace