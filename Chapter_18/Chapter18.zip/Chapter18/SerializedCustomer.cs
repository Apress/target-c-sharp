﻿using System;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Binary;

namespace Chapter18
{
  internal class SerializedCustomer
  {
    /*
    Serialization is a process to convert an object into a stream 
    of bytes so that the bytes can be written into a file. 
    We will normally do this so the  serialized data can be used to 
    store the data in a database or for sending it across a network 
    e.g. to a message queue to form part of a transaction process. 
    The byte stream created is platform independent,it is an object 
    serialized on one platform that can be de serialized on a 
    different platform. 
    */

    static void Main(string[] args)
    {
      /*********************************************************
      Create an instance of the Customer class passing in the 
      initial values that will be used to set the values of the  
      members (fields) in the Customer object being created.
      As a matter of good practice we will use a .ser extension
      for the file name.       
      *********************************************************/
      Customer myCustomerObject =
      new Customer(123456, 45, "Gerry", "1 Any Street, " +
      "Belfast, BT1 ANY", 10);

      IFormatter formatterForTheClass = new BinaryFormatter();

      Stream streamToHoldTheData =
  new FileStream("CustomerSerializedData.ser",
  FileMode.Create, FileAccess.Write);

      formatterForTheClass.Serialize(streamToHoldTheData,
        myCustomerObject);

      streamToHoldTheData.Close();

    }//End of Main() method 
  } //End of SerializedCustomer class 
} //End of Chapter18 namespace