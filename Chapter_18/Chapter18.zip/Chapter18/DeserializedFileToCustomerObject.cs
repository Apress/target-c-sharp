﻿using System;
using System.Runtime.Serialization.Formatters.Binary;


namespace Chapter18
{
  internal class DeserializedFileToCustomerObject
  {
    /*
    De-serialization is the process of taking the  serialized data
    (file) and returning it to an object as defined by the class. 

    When we serialized, there may be some values we do not want to 
    save to the file. These values may contain sensitive data or
    data that can be calculated again. Adding the attribute 
    [NonSerialized] means that during the serialization process
    the relevant member (field) will not be  serialized and as 
    such the data will be ignored and no data for the field 
    will be written.
    */

    static void Main(string[] args)
    {
      Customer myCustomer = null;

      BinaryFormatter binaryFormatterForTheClass =
  new BinaryFormatter();

      FileStream fileStreamToHoldTheData =
  new FileStream("CustomerSerializedData.ser",
  FileMode.Open, FileAccess.Read);

      try
      {
        using (fileStreamToHoldTheData)
        {
          myCustomer = (Customer)binaryFormatterForTheClass.Deserialize(fileStreamToHoldTheData);

          Console.WriteLine("Customer Details");
          Console.WriteLine("Customer Name: " + myCustomer.CustomerName);
          Console.WriteLine("Customer Age: " + myCustomer.CustomerAge);
          Console.WriteLine("Customer Account No:" +
                  myCustomer.CustomerAccountNumber);
          Console.WriteLine("Customer Address:" +
                  myCustomer.CustomerAddress);
          Console.WriteLine("Customer Years a Customer:  " +
                  myCustomer.CustomerYearsWithCompany);

        } // End of the using block
      } // End of the try block
      catch
      {
        Console.WriteLine("Error creating the Customer" +
          " from the  serialized file");

      }// End of the catch block


    }//End of Main() method 

  } //End of DeserializedFileToCustomerObject class 

} //End of Chapter18 namespace