﻿using System;
using System.Text.Json;

namespace Chapter18
{
  internal class JSONSerialisation
  {
    /* 
    Create JSON as a string

    Writing JSON to a string or to a file we need to call
    the JsonSerializer.Serialize method.

    The JSON output will be minified which means the removal of
    the whitespace, indentation and new line characters
    */
    public static void Main()
    {

      CustomerJSON myCustomer =
              new CustomerJSON(123456, 45, "Gerry",
              "1 Any Street, Belfast, BT1 ANY", 10);

      //Serialize
      string jsonString =
        JsonSerializer.Serialize<CustomerJSON>(myCustomer);

      Console.WriteLine(jsonString);

      CreateJSON(myCustomer);

      ReadJSON();


    } // End of Main() method

    public static async Task CreateJSON(CustomerJSON myCustomer)
    {
      string fileName = "Customer.json";
      using FileStream createStream = File.Create(fileName);
      await JsonSerializer.SerializeAsync(createStream, myCustomer);
      await createStream.DisposeAsync();

      Console.WriteLine(File.ReadAllText(fileName));
    } // End of CreateJSON() method

    public static void ReadJSON()
    {
      string fileName = "Customer.json";
      using FileStream myStream = File.OpenRead(fileName);
      CustomerJSON myCustomer 
        = JsonSerializer.Deserialize<CustomerJSON>(myStream);

      Console.WriteLine("Customer Details");
      Console.WriteLine("Customer Name: " + myCustomer.customerName);
      Console.WriteLine("Customer Age: " + myCustomer.customerAge);
      Console.WriteLine("Customer Account No:" +
              myCustomer.customerAccountNumber);
      Console.WriteLine("Customer Address:" +
              myCustomer.customerAddress);
      Console.WriteLine("Customer Years a Customer:  " +
              myCustomer.customerYearsWithCompany);

    } // End of CreateJSON() method


  } // End of JSONSerialisation class
} // End of Chapter18 namespace
