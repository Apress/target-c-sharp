﻿using System;

namespace Chapter18
{
    [Serializable]
    public class CustomerXML
    {
      /***********************************************************
      The fields are public because in XML serialization only the
      public fields will be serialized
      ***********************************************************/
      public int customerAccountNumber;
      public int customerAge;
      public String customerName;
      public String customerAddress;
      public int customerYearsWithCompany;

    public CustomerXML()
    {

    }

    /**********************************************************
    Create a constructor for the Customer class. 
    The constructor will over-write the default constructor. 
    The constructor is used to accept the value passed into it
    from the code used to instantiate the class. 
    The values passed into the constructor are used to 
    initialise the values of fields (members, variables!). 
    The keyword this is used in front of the field names.
    **********************************************************/
    public CustomerXML(int accountNumberPassedIn, int agePassedIn,
    String namePassedIn, String addressPassedIn, int yearsPassedIn)
    {
      this.customerAccountNumber = accountNumberPassedIn;
      this.customerAge = agePassedIn;
      this.customerName = namePassedIn;
      this.customerAddress = addressPassedIn;
      this.customerYearsWithCompany = yearsPassedIn;
    } // End of Customer constructor

  } // End of Customer class
} // End of Chapter18 namespace