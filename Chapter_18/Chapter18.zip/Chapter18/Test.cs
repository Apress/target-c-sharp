﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace Chapter18
{
  public class Forecast
  {
    public DateTime Date { get; set; }

    public int TemperatureC { get; set; }

    [JsonIgnore]
    public string? Summary { get; set; }
  };

  public class Test
  {
    public static void Main()
    {
      Forecast forecast = new()
      {
        Date = default,
        Summary = null,
        TemperatureC = default
      };


      string forecastJson =
          JsonSerializer.Serialize<Forecast>(forecast);

      Console.WriteLine(forecastJson);
    }
  }
}