﻿using System;
using System.Xml.Serialization;


namespace Chapter18
{
  internal class XMLDeserialisation
  {
    static void Main(string[] args)
    {
      /*
      De-serialisation is the process of taking the serialized data
      (file) and returning it to an object as defined by the class. 
      */


      // Create an instance of the Customer class
      CustomerXML myCustomer = null;

      // Create an instance of the XmlSerializer
      XmlSerializer mySerialser = new XmlSerializer(typeof(CustomerXML));

      // Create an instance of the StreamReader using the xml file
      StreamReader myStreamReader = new StreamReader("CustomerSerialisedData.xml");

      try
      {
        myCustomer = (CustomerXML)mySerialser.Deserialize(myStreamReader);

        Console.WriteLine("Deserialize completed"); ;

        Console.WriteLine("Customer Details");
        Console.WriteLine("Customer Name: " + myCustomer.customerName);
        Console.WriteLine("Customer Age: " + myCustomer.customerAge);
        Console.WriteLine("Customer Account No:" +
                myCustomer.customerAccountNumber);
        Console.WriteLine("Customer Address:" +
                myCustomer.customerAddress);
        Console.WriteLine("Customer Years a Customer:  " +
                myCustomer.customerYearsWithCompany);
      } // End of the try block
      catch
      {
        Console.WriteLine("Error creating the Customer" +
          " from the serialised file");
      }// End of the catch block
      myStreamReader.Close();
    } // End of Main() method

  } // End of XMLDeserialisation class
} // End of Chapter18 namespace