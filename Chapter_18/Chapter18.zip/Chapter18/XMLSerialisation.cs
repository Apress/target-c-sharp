﻿using System;
using System.Xml.Serialization;

namespace Chapter18
{
  internal class XMLSerialisation
  {
    static void Main(string[] args)
    {
      /*********************************************************
      Create an instance of the Customer class passing in the 
      initial values that will be used to set the values of the  
      members (fields) in the Customer object being created.
      As a matter of good practice we will use a .ser extension
      for the file name.       
      *********************************************************/
      CustomerXML myCustomerObject =
          new CustomerXML(123456, 45, "Gerry", "1 Any Street, " +
          "Belfast, BT1 ANY", 10);



      // Create an instance of the XmlSerializer
      XmlSerializer myXMLSerialiser = new
                     XmlSerializer(typeof(CustomerXML));

      //Create an instance of the StreamWriter using the xml file
      StreamWriter myStreamWriter = new
                     StreamWriter("CustomerSerialisedData.xml");

      // Serialize the object using the StreamWriter
      myXMLSerialiser.Serialize(myStreamWriter, myCustomerObject);

      // Close the StreamWriter
     // myStreamWriter.Close();

    } // End of Main() method

  } // End of XMLSerialisation class
} // End of Chapter18 namespace