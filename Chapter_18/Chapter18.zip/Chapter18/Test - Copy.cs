﻿using System.Text.Json;
using System.Text.Json.Serialization;

namespace Chapter18
{
  public class CustomerJSONNew
  {
  
    public int customerAccountNumber { get; set; }
    [JsonIgnore]
    public int customerAge { get; set; }

    public String customerName { get; set; }
    public String customerAddress { get; set; }
    public int customerYearsWithCompany { get; set; }

    public CustomerJSONNew(int customerAccountNumber, int customerAge, string customerName, string customerAddress, int customerYearsWithCompany)
    {
      this.customerAccountNumber = customerAccountNumber;
      this.customerAge = customerAge;
      this.customerName = customerName;
      this.customerAddress = customerAddress;
      this.customerYearsWithCompany = customerYearsWithCompany;
    }

  }
  public class Test1
  {
    public static void Main()
    {
      CustomerJSONNew myCustomer = new CustomerJSONNew(123456, 45, "Gerry", "1 Any Street, Belfast, BT1 ANY", 10);


      string forecastJson =
          JsonSerializer.Serialize<CustomerJSONNew>(myCustomer);

      Console.WriteLine(forecastJson);
    }
  }
}