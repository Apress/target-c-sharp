﻿using System;

namespace Chapter18
{
    [Serializable]
    internal class Customer
    {
      /***********************************************************
      The [NonSeriazable] attribute is a 'modifier' which can be 
      used in serialization. When we serialized, there may be some 
      values we do not want to save to the file. 
      These values may contain sensitive data or data that can be 
      calculated again. 
      Adding the attribute [NonSerialized] means that during the 
      serialization process the relevant member (type) will not be
      serialized and no 'real' data will be written for the member.

      The [NonSeriazable] attribute  assists us with the important 
      role of meeting security constraints e.g. when we do not 
      want to save private data in a file. 
      ***********************************************************/
      private int customerAccountNumber;
     [NonSerialized] private int customerAge;
      private String customerName;
      private String customerAddress;
      private int customerYearsWithCompany;

    /**********************************************************
    Create a constructor for the Customer class. 
    The constructor will over-write the default constructor. 
    The constructor is used to accept the value passed into it
    from the code used to instantiate the class. 
    The values passed into the constructor are used to 
    initialise the values of fields (members, variables!). 
    The keyword this is used in front of the field names.
    **********************************************************/
    public Customer(int accountNumberPassedIn, int agePassedIn,
    String namePassedIn, String addressPassedIn, int yearsPassedIn)
    {
      this.customerAccountNumber = accountNumberPassedIn;
      this.customerAge = agePassedIn;
      this.customerName = namePassedIn;
      this.customerAddress = addressPassedIn;
      this.customerYearsWithCompany = yearsPassedIn;
    } // End of Customer constructor

    // Property for each member/field
    public int CustomerAccountNumber
    {
      get { return customerAccountNumber; }
      set { customerAccountNumber = value; }
    }// End of CustomerAccountNumber property
    public int CustomerAge
    {
      get { return customerAge; }
      set { customerAge = value; }
    }// End of CustomerAge property
    public string CustomerName
    {
      get { return customerName; }
      set { customerName = value; }
    }// End of CustomerName property
    public string CustomerAddress
    {
      get { return customerAddress; }
      set { customerAddress = value; }
    }// End of CustomerAddress property
    public int CustomerYearsWithCompany
    {
      get { return customerYearsWithCompany; }
      set { customerYearsWithCompany = value; }
    }// End of CustomerYearsWithCompany property

  } // End of Customer class
} // End of Chapter18 namespace