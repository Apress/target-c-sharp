﻿using System;

namespace Chapter21
{
  /* 
  A delegate is a type used to represent a method with a 
  return type and method signature.
  Here the delegate is called Calculation and the return type 
  is double and the parameter is a double
  */
  delegate double Calculation(double itemPrice);

  internal class Delegates
  {
    // Create the variables we need
    static double totalofallclaims;

    static void Main(string[] args)
    {
      // Instantiate the delegate
      Calculation myCalculationDelegate, myAccumulateDelegate, 
        myMultipleDelegate;

      /* 
      Point the delegate object myCalculationDelegate to 
      the method CalculateVATAmount
      We are making a reference to the method
      */
      myCalculationDelegate = CalculateVATAmount;

      /* 
      Point the delegate object myAccumulateDelegate to the
      method accumulateClaimAmount
      We are making a reference to the method
      */
      myAccumulateDelegate = AccumulateClaimAmount;

      /* 
      The two delegates, mydelegate1 and mydelegate2, are 
      combined into form myMultipleDelegate
      */
      myMultipleDelegate = 
        myCalculationDelegate + myAccumulateDelegate;


      /* 
      Invoke the delegate - in other words the delegate 
      points to the method that accepts a double data type,
      performs its business logic and then returns a double. 
      So here we invoke our myCalculationDelegate delegate
      passing it the value 100.00
      */
      Console.WriteLine("Invoking myCalculationDelegate \n");
      Console.WriteLine($"Invoked delegate returned VAT " +
        $"of ${myCalculationDelegate(120.00)}");

      Console.WriteLine("-------------------------------");
      Console.WriteLine("Invoking myAccumulateDelegate:");
      myMultipleDelegate(1500);

    } // End of Main() method

    /*
    Create the  method that will be the target of the 
    delegate, this was Method 13
    */
    public static double CalculateVATAmount(double
            totalvalueofclaimspassedin)
    {
      double vatamount =
                      totalvalueofclaimspassedin -
                         (totalvalueofclaimspassedin / 1.20);

      Console.WriteLine($"The CalculateVATAmount method " +
        $"is executing using the parameter " +
        $"{totalvalueofclaimspassedin} \nand the output " +
        $"produced is ${vatamount} which represents the " +
        $"VAT amount\n");
      return vatamount;
    } // End of CalculateVATAmount method

    /* 
    Create the method that will be the target of the 
    delegate, this was Method 12
    */
    public static double AccumulateClaimAmount(double
                                            claimamountpassedin)
    {
      totalofallclaims = totalofallclaims + claimamountpassedin;
      Console.WriteLine($"The accumulateClaimAmount method is " +
        $"executing using the parameter {claimamountpassedin} " +
        $"\nand the output produced is ${totalofallclaims}" +
        $" which represents the total claims\n");

      return totalofallclaims;
    } // End of AccumulateClaimAmount method

  } // End of Delegates class
} // End of Chapter21 namespace