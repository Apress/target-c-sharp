﻿using System;

namespace Chapter21
{
  internal class Policy
  {
    private int policy_number;
    private String policyType;
    private double monthlyPremium;
    private String policyEndDate;

    // Constructor for the Policy class
    public Policy(int policy_number, string policyType,
      double monthlyPremium, string policyEndDate)
    {
      this.policy_number = policy_number;
      this.policyType = policyType;
      this.monthlyPremium = monthlyPremium;
      this.policyEndDate = policyEndDate;
    } // End of user constructor

    // Properties used to get and set the members
    public int Policy_number
    {
      get => policy_number;
      set => policy_number = value;
    } // End of Policy_number property accessor
    public string PolicyType
    {
      get => policyType;
      set => policyType = value;
    } // End of PolicyType property accessor
    public double MonthlyPremium
    {
      get => monthlyPremium;
      set => monthlyPremium = value;
    } // End of MonthlyPremium property accessor
    public string PolicyEndDate
    {
      get => policyEndDate;
      set => policyEndDate = value;
    } // End of PolicyEndDate property accessor
  } // End of Policy class
} // End of Chapter21 namespace