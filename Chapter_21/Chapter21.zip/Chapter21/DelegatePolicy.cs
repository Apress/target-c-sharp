﻿using System;
using System.Collections.Generic;

namespace Chapter21
{
  internal class DelegatePolicy
  {
    /*
    Declare the delegate we will use.
    In this case we have a return type of bool and the method
    signature states that the method must accept a Policy object
    */
    public delegate bool FindByDelegate(Policy policy);

    static void Main(string[] args)
    {
    /* 
    Create 6 objects of type Policy - Policy is a separate class
    The Policy class has 4 members - policy_number, policyType
    monthlyPremium and the policyEndDate;
    */

      // Laptops
      Policy myPolicyOne =
             new Policy(123456, "Laptop", 19.99, "31/12/2022");
      Policy myPolicyFive =
             new Policy(156790, "Laptop", 18.99, "30/12/2022");
      Policy myPolicySix =
             new Policy(123456, "Laptop", 15.99, "15/12/2022");

      // Need renewed
      Policy myPolicyTwo =
             new Policy(267890, "Printer", 15.99, "01/11/2022");
      Policy myPolicyThree =
           new Policy(345908, "Small_Screen", 9.99, "01/10/2022");
      // Monthly premium greater than $20
      Policy myPolicyFour =
          new Policy(455666, "Large_Screen", 29.99, "01/12/2022");

    /* 
    Create a strongly typed List to hold the six Policy objects.
    The List of policies will be iterated later  
    */
      List<Policy> policies = new List<Policy>()
      { myPolicyOne, myPolicyTwo, myPolicyThree,
        myPolicyFour, myPolicyFive, myPolicySix
      };

      /*
      Call the FindPolicesByGivenDelegate method passing
      it the delegate to be used 
      */
      FindPolicesByGivenDelegate("The list of Laptops" +
                    " policies are", policies, HardwareType);

      FindPolicesByGivenDelegate("The list of policies" +
        " due for renewal are", policies, PolicyIsDueForRenewal);

      FindPolicesByGivenDelegate("The list of policies " +
        "with a premium greater than $20.00 are",
        policies, PremiumGreaterThanTwenty);

    } // End of Main() method

    /*
    In this method we use the delegate, FindByDelegate to 
    invoke the method it is pointing to.
    The delegate method name is passed to this method.
    */
    static void FindPolicesByGivenDelegate(string title,
      List<Policy> policies, FindByDelegate filterMethodToBeUsed)
    {
      Console.WriteLine(title);
      Console.WriteLine(filterMethodToBeUsed);

      foreach (Policy policy in policies)
      {
        if (filterMethodToBeUsed(policy))
        {
          Console.WriteLine($"\t{policy.PolicyType} policy " +
           $"number {policy.Policy_number} is due for renewal " +
           $"on { policy.PolicyEndDate} and the current " +
           $"premium is { policy.MonthlyPremium }");
        } // End of if construct

      } // End of foreach iteration

      // Separate the three filters for display purposes
      Console.WriteLine("----------------------------");
    } // End of FindPolicesByGivenDelegate

    /*********************************************************
    *    Methods that will be pointed to by the delegate     *
    *********************************************************/
    //Check if the policy type is a laptop and return true or false
    static bool HardwareType(Policy policyPassedIn)
    {
      return policyPassedIn.PolicyType.Equals("Laptop");
    } // End of HardwareType method

    // Check if policy is due for renewal and return true or false
    // Here we have, for simplicity hard coded a date
    static bool PolicyIsDueForRenewal(Policy policyPassedIn)
    {
      String today = "30/11/2022";
      return DateTime.Parse(policyPassedIn.PolicyEndDate)
                                 <= DateTime.Parse(today);
    } // End of PolicyIsDueForRenewal method

    /* 
    Check if the monthly premium is greater than $20 
    and return true or false
    */
    static bool PremiumGreaterThanTwenty(Policy policyPassedIn)
    {
      return policyPassedIn.MonthlyPremium > 20.00;
    } // End of PremiumGreaterThanTwenty method


  } // End of DelegatePolicy class

} // End of Chapter21 namespace